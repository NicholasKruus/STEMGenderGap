# UPDATE this working directory to the folder named "Code." It must be this folder because it
# contains the files "UniversityRanks.csv", "0209degrees.csv", "1015degrees.csv", 
# and "1621degrees.csv".
setwd("ENTER WORKING DIRECTORY")

# Load necessary packages
library(tidyverse)
library(tidyr)
library(dplyr)
library(ggplot2)
library(reshape2)
library(plotly)
library(carData)
library(gapminder)
library(babynames)
library(ggpubr)
library(lmtest)

# Read data from CSV files and dispose of unnecessary columnns
rr <- read_csv("1015degrees.csv")
rr2 <- read_csv("1621degrees.csv")
rr2 <- rr2[,1:7]

# Calculate totals  and percentages for 2010 to 2015
totals1015 <- rr %>%
  group_by(Institution,DegreeDisciplineName) %>%
  summarize(total = sum(Total,na.rm=T))
tempdf <- rr %>%
  group_by(Institution,DegreeDisciplineName) %>%
  summarize(totalfemale = sum(TotalFemale,na.rm=T))
totals1015 <- cbind(totals1015, tempdf[,3])
rm(tempdf)
totals1015 <- totals1015 %>%
  mutate(percentfemale = round(totalfemale/total*100, 0)) %>%
  mutate(percentmale = 100-percentfemale)

# Filter out unwanted institutions from rr2
rr2 <- rr2 %>% filter(rr2$Institution!="National(NCES)", rr2$Institution!="PepperdineUniversity",
                      rr2$Institution!="UC-Davis", rr2$Institution!="UC-Irvine", rr2$Institution!="UC-Merced",
                      rr2$Institution!="UC-Riverside", rr2$Institution!="UC-SantaBarbara",
                      rr2$Institution!="UC-SantaCruz", rr2$Institution!="UniversityofSouthernCalifornia")
# Rename columns in rr2
colnames(rr2) <- c("Institution", "DegreeDisciplineName", "Total", "TotalFemale", "PercentFemale", "PercentMale", "AcademicYear")

# Calculate totals  and percentages for 2016 to 2021
totals1621 <- rr2 %>%
  group_by(Institution,DegreeDisciplineName) %>%
  summarize(total = sum(Total,na.rm=T))

tempdf <- rr2 %>%
  group_by(Institution,DegreeDisciplineName) %>%
  summarize(totalfemale = sum(TotalFemale,na.rm=T))
totals1621 <- cbind(totals1621, tempdf[,3])
rm(tempdf)
totals1621 <- totals1621 %>%
  mutate(percentfemale = round(totalfemale/total*100, 0)) %>%
  mutate(percentmale = 100-percentfemale)

# Read data from "0209degrees.csv"
rr3 <- read_csv("0209degrees.csv")

# Calculate totals and percentages for 2002 to 2009
totals0209 <- rr3 %>%
  group_by(Institution, DegreeDiscipline) %>%
  summarize(Total = sum(Total,na.rm=T))
tempdf <- rr3 %>%
  group_by(Institution, DegreeDiscipline) %>%
  summarize(TotalFemale = sum(TotalFemale,na.rm=T))
totals0209 <- cbind(totals0209, tempdf[,3])
rm(tempdf)
totals0209 <- totals0209 %>%
  mutate(PercentFemale = round((TotalFemale/Total)*100, 0)) %>%
  mutate(PercentMale = 100-PercentFemale)

# Add AcademicYear column to totals0209
totals0209 <- cbind(totals0209, "2002-2009")

# Filter out rows with NaN values in PercentFemale
colnames(totals0209) <- c("Institution", "DegreeDisciplineName","Total","TotalFemale","PercentFemale","PercentMale","AcademicYear")
totals0209 <- totals0209 %>%
  filter(!is.nan(PercentFemale))

# Clean up DegreeDisciplineName column
totals0209$DegreeDisciplineName <- gsub("  Bachelor's degree)", "", totals0209$DegreeDisciplineName)
totals0209$DegreeDisciplineName <- gsub(" ", "", totals0209$DegreeDisciplineName)
totals0209$DegreeDisciplineName <- gsub("\\.", "", totals0209$DegreeDisciplineName)

# Add AcademicYear to totals1621 and totals1015
totals1621 <- cbind(totals1621,"2016-2021")
colnames(totals1621) <- c("Institution","DegreeDisciplineName","Total","TotalFemale","PercentFemale","PercentMale","AcademicYear")

totals1015 <- cbind(totals1015,"2010-2015")
colnames(totals1015) <- c("Institution","DegreeDisciplineName","Total","TotalFemale","PercentFemale","PercentMale","AcademicYear")

# Combine all three datasets
totals0221 <- rbind(totals0209,totals1015,totals1621)
colnames(totals0221) <- c("Institution","DegreeDisciplineName","Total","TotalFemale","PercentFemale","PercentMale","AcademicYear")

# Create a backup of the dataset
testtotals0221 <- totals0221

# Replace NA values in Institution with Error as a placeholder value
testtotals0221$Institution <- ifelse(is.na(testtotals0221$Institution), testtotals0221$Error, testtotals0221$Institution)

# Assign the modified dataset back to totals0221 and remove it
totals0221 <- testtotals0221
rm(testtotals0221)

# Clean up Institution names
totals0221$Institution <- gsub("Mass", "", totals0221$Institution)
totals0221$Institution <- gsub("achussetsInstituteofTechnology", "", totals0221$Institution)
totals0221$Institution <- gsub("\\(", "", totals0221$Institution)
totals0221$Institution <- gsub("\\)", "", totals0221$Institution)
totals0221$Institution <- gsub("CaliforniaInstituteofTechnologyCaltech", "Caltech", totals0221$Institution)
totals0221$Institution <- gsub("University", "", totals0221$Institution)
totals0221$Institution <- gsub("College", "", totals0221$Institution)
totals0221$Institution <- gsub("NewYork", "", totals0221$Institution)
totals0221$Institution <- gsub("ofChicago", "UChicago", totals0221$Institution)
totals0221$Institution <- gsub("ofNotreDame", "UNotreDame", totals0221$Institution)
totals0221$Institution <- gsub("ofPennsylvania", "UPenn", totals0221$Institution)
totals0221$Institution <- gsub("Berkeley", "B", totals0221$Institution)
totals0221$Institution <- gsub("LosAngeles", "LA", totals0221$Institution)
totals0221$Institution <- gsub("SanDiego", "SD", totals0221$Institution)
totals0221$Institution <- gsub("Uchicago", "UChicago", totals0221$Institution)
totals0221$Institution <- gsub("UWinSt.Louis", "UW-St.Louis", totals0221$Institution)
totals0221$Institution <- gsub("ofMichigan-AnnArbor", "UM-AnnArbor", totals0221$Institution)

# Create a copy of totals0221
df <- totals0221

# Subset the dataframe to include only rows where DegreeDisciplineName is 'economics' 
# or 'socialsciences'
subset_df <- df[tolower(df$DegreeDisciplineName) %in% c('economics', 'socialsciences'), ]

# Pivot the subset dataframe to wide format
pivot_df <- dcast(subset_df, Institution + AcademicYear ~ DegreeDisciplineName, value.var = 'Total')

# Calculate the difference between 'Socialsciences' and 'Economics' 
# (because the original NCES IPEDS data included the economics values in
# the Socialsciences aggregate, this must be done to isolate the other social sciences degrees)
pivot_df$Socialsciences <- pivot_df$Socialsciences - pivot_df$Economics

# Group the dataframe by Institution and whether DegreeDisciplineName is 'economics'
df <- df %>% group_by(Institution, tolower(DegreeDisciplineName)=="economics") %>%
  mutate(TotalEcon = Total)

# Create a new dataframe with modified column names and a long format
df_new <- df %>%
  rename(Total_Male = Total, Total_Female = TotalFemale) %>%
  pivot_longer(cols = c(Total_Male, Total_Female),
               names_to = c("Gender", ".value"),
               names_sep = "_") %>%
  select(-PercentFemale, -PercentMale) %>%
  arrange(Institution, DegreeDisciplineName, Gender, AcademicYear)

# Remove columns at indices 8 and 9
df <- df[,-c(8,9)]

# Create a new dataframe with modified column names and a long format
df_new <- df %>%
  rename(FullTotal = Total, Total_Female = TotalFemale) %>%
  pivot_longer(cols = c(FullTotal, Total_Female),
               names_to = c(".value", "Gender"),
               names_sep = "_",
               names_repair = "unique") %>%
  select(-PercentFemale, -PercentMale) %>%
  arrange(Institution, DegreeDisciplineName, AcademicYear)

# Replace missing Gender values with 'Total'
df_new <- df_new %>%
  mutate(Gender = replace_na(Gender, "Total"))

# Replace missing Total values with FullTotal
df_new <- df_new %>%
  mutate(Total = coalesce(Total, FullTotal))

# Clean up df_new by removing the column at index 5
df_new <- df_new[,-5]

# Rename df_new to be more descriptive
df_longer <- df_new
rm(df_new)

# Clean up DegreeDisciplineName column (convert to lowercase)
df$DegreeDisciplineName <- tolower(df$DegreeDisciplineName)
df_longer$DegreeDisciplineName <- tolower(df_longer$DegreeDisciplineName)

# Pivot the long format dataframe to a wide format and subtract economics from 
# socialsciences
df_wide <- df_longer %>%
  pivot_wider(
    id_cols = c("Institution", "Gender", "AcademicYear"),
    names_from = DegreeDisciplineName,
    values_from = Total
  ) %>%
  mutate(
    socialsciences = as.numeric(`socialsciences`),
    economics = as.numeric(`economics`),
    subtraction_result = socialsciences - economics
  )

# Swap the aggregate socialsciences values, which include economics, with the
# subtracted values, which do not include economics.
df_wide$socialsciences <- df_wide$subtraction_result

# Rename columns (remove parentheses)
colnames(df_wide) <- gsub("\\(|\\)", "", colnames(df_wide))

# Create a test dataframe with modified column names
df_test <- df_wide %>%
  mutate(cleanothersocialsciencessociologygeneralsocialpolitical = coalesce(socialsciences, othersocialsciencessociologygeneralsocialpolitical))

# Remove columns with names 'subtraction_result', 'othersocialsciencessociologygeneralsocialpolitical', and 'socialsciences'
df_test <- df_test[, !colnames(df_test) %in% "subtraction_result"]
df_test <- df_test[, !colnames(df_test) %in% "othersocialsciencessociologygeneralsocialpolitical"]
df_test <- df_test[, !colnames(df_test) %in% "socialsciences"]

# Perform numeric conversions and calculate addition_result (to be removed from the 
# physicalsciences aggregate to isolate the other physical sciences degrees)
df_test <- df_test %>%
  mutate(
    physicalsciences = as.numeric(`physicalsciences`),
    chemistry = as.numeric(`chemistry`),
    physics = as.numeric(`physics`),
    addition_result = chemistry + physics
  )

# Update physicalsciences column by removing addition_result
df_test <- df_test %>%
  mutate(
    physicalsciences = as.numeric(`physicalsciences`),
    subtraction_result = physicalsciences - addition_result
  )
df_test$physicalsciences <- df_test$subtraction_result

# Create a new test dataframe with modified columns
df_test <- df_test %>%
  mutate(cleanotherphysicalsciencesastronomygeologicalearthgeneralphysical = coalesce(physicalsciences, otherphysicalsciencesastronomygeologicalearthgeneralphysical))

# Remove columns with names 'subtraction_result', 'addition_result', 
# 'otherphysicalsciencesastronomygeologicalearthgeneralphysical', and 'physicalsciences'
df_test <- df_test[, !colnames(df_test) %in% "subtraction_result"]
df_test <- df_test[, !colnames(df_test) %in% "addition_result"]
df_test <- df_test[, !colnames(df_test) %in% "otherphysicalsciencesastronomygeologicalearthgeneralphysical"]
df_test <- df_test[, !colnames(df_test) %in% "physicalsciences"]

# Rename df_test to be more descriptive
df_wide <- df_test
rm(df_test)

# Pivot the wide format dataframe 'df_wide' to long format
df_long <- df_wide %>%
  pivot_longer(
    cols = -c(Institution, Gender, AcademicYear),
    names_to = "DegreeDisciplineName",
    values_to = "Value"
  )

# Separate 'Value' column into 'Total' and 'TotalFemale' columns using dots as separators
df_long <- df_long %>%
  separate(
    col = "Value",
    into = c("Total", "TotalFemale"),
    sep = "\\."
  )

# Pivot the dataframe 'df_long' to wide format, grouping by Institution, 
# DegreeDisciplineName, and AcademicYear
df_long <- df_long %>%
  pivot_wider(names_from = Gender,
              values_from = Total,
              names_prefix = "Total_",
              names_glue = "{.value}_{Gender}") %>%
  select(Institution, DegreeDisciplineName, starts_with("Total"), AcademicYear)

# Clean 'df_long' by removing rows with missing 'Total_Total' values, removing column 3,
# and renaming columnns
df_cleaned <- df_long[!is.na(df_long$Total_Total),]
df_long <- df_cleaned
rm(df_cleaned)
df_long <- df_long[,-3]
colnames(df_long) <- c("Institution", "DegreeDisciplineName", "Total", "TotalFemale", "AcademicYear")

# Reorder columns of df_long and calculate 'PercentFemale'
df_long <- df_long %>%
  select(Institution, AcademicYear, DegreeDisciplineName, Total, TotalFemale)
df_long <- df_long %>%
  mutate(PercentFemale = round((as.numeric(TotalFemale) / as.numeric(Total))*100,0))

# Write the resulting dataframe to a CSV file named 'df_long.csv'
write.csv(df_long, "df_long.csv")

# Sum the 'Total' values for each DegreeDisciplineName
allyearstotal <- totals0221 %>% group_by(DegreeDisciplineName) %>%
  summarize(Total0221 = sum(Total))

# Sum the 'TotalFemale' values for each DegreeDisciplineName
allyearsfemale <- totals0221 %>% group_by(DegreeDisciplineName) %>%
  summarize(TotalFemale0221 = sum(TotalFemale))

# Combine the total and total female data, and calculate the 'PercentFemale0221'
allyearstotals <- cbind(allyearstotal, allyearsfemale[,2])
allyearstotals <- allyearstotals %>% group_by(DegreeDisciplineName) %>%
  mutate(PercentFemale0221 = round((TotalFemale0221/Total0221)*100,0))

# Filter 'totals0221' for specific DegreeDisciplineNames and perform data transformations
lowfemaleover1000 <- totals0221[tolower(totals0221$DegreeDisciplineName) %in% c("computerengineeringgeneral",
  "computerengineering","engineeringphysics","computerandinformationsciencesandsupportservices",
  "electricalelectronicsandcommunicationsengineering","aerospaceaeronauticalandastronauticalengineering",
  "mechanicalengineering","physics","engineeringgeneral",
  "mathematicsandstatistics", "engineeringother"),]

# Modify 'DegreeDisciplineName' for graph readability
lowfemaleover1000$DegreeDisciplineName <- tolower(lowfemaleover1000$DegreeDisciplineName)
lowfemaleover1000$DegreeDisciplineName <- gsub("general", "", lowfemaleover1000$DegreeDisciplineName)
lowfemaleover1000$DegreeDisciplineName <- gsub("aerospaceaeronauticalandastronauticalengineering", "Aerospace, Aeronautical, and Astronautical Engineering", lowfemaleover1000$DegreeDisciplineName)
lowfemaleover1000$DegreeDisciplineName <- gsub("computerengineering", "Computer Engineering", lowfemaleover1000$DegreeDisciplineName)
lowfemaleover1000$DegreeDisciplineName <- gsub("engineeringphysics", "Engineering Physics", lowfemaleover1000$DegreeDisciplineName)
lowfemaleover1000$DegreeDisciplineName <- gsub("computerandinformationsciencesandsupportservices", "Computer and Information Sciences and Support Services", lowfemaleover1000$DegreeDisciplineName)
lowfemaleover1000$DegreeDisciplineName <- gsub("engineering", "Engineering", lowfemaleover1000$DegreeDisciplineName)
lowfemaleover1000$DegreeDisciplineName <- gsub("electricalelectronicsandcommunicationsEngineering", "Electrical, Electronics, and Communications Engineering", lowfemaleover1000$DegreeDisciplineName)
lowfemaleover1000$DegreeDisciplineName <- gsub("navalarchitectureandmarineengineering", "Naval, Architecture, and Marine Engineering", lowfemaleover1000$DegreeDisciplineName)
lowfemaleover1000$DegreeDisciplineName <- gsub("physics", "Physics", lowfemaleover1000$DegreeDisciplineName)
lowfemaleover1000$DegreeDisciplineName <- gsub("mathematicsandstatistics", "Mathematics and Statistics", lowfemaleover1000$DegreeDisciplineName)
lowfemaleover1000$DegreeDisciplineName <- gsub("mechanicalEngineering", "Mechanical Engineering", lowfemaleover1000$DegreeDisciplineName)
lowfemaleover1000$DegreeDisciplineName <- gsub("Engineeringother", "Engineering, Other", lowfemaleover1000$DegreeDisciplineName)

# Group 'lowfemaleover1000' by 'DegreeDisciplineName' and 'AcademicYear' and 
# gather the sums of Total and TotalFemale and their female/male ratio (in %)
lowfemaleover1000 <- lowfemaleover1000 %>% group_by(DegreeDisciplineName, AcademicYear) %>%
  mutate(sumTotal = sum(Total)) %>% mutate(sumTotalFemale = sum(TotalFemale)) %>%
  mutate(sumPercentFemale = round(sumTotalFemale/sumTotal*100))

# Create a scatter plot of the Female Share of the Most Male-Dominated Degrees 
# over the Year Ranges
ggplot(data=lowfemaleover1000, aes(x=AcademicYear,y=sumPercentFemale,group=DegreeDisciplineName)) + 
  geom_point(aes(color=DegreeDisciplineName)) + 
  geom_line(aes(color=DegreeDisciplineName)) + 
  xlab("Year Range") + ylab("Percentage Female") + 
  ggtitle("Female Share of the Most Male-Dominated Degrees \nBetween Year Ranges at Top 20 US Universities")

# Convert 'DegreeDisciplineName' to lowercase in 'totals0221'
totals0221$DegreeDisciplineName <- tolower(totals0221$DegreeDisciplineName)

# Filter specific DegreeDisciplineNames and assign them to respective variables
# then join them together
compsci <- totals0221 %>% filter(DegreeDisciplineName=="computerandinformationsciencesandsupportservices")
electrical <- totals0221 %>% filter(DegreeDisciplineName=="electricalelectronicsandcommunicationsengineering")
math <- totals0221 %>% filter(DegreeDisciplineName=="mathematicsandstatistics")
mechanical <- totals0221 %>%   filter(DegreeDisciplineName=="mechanicalengineering")
physics <- totals0221 %>%   filter(DegreeDisciplineName=="physics")
selecteddegrees <- rbind(compsci,electrical,math,mechanical,physics)

# Modify 'Institution' names for consistency
selecteddegrees$Institution <- gsub("University", "", selecteddegrees$Institution)
totals0221$Institution <- gsub("University", "", totals0221$Institution)

# Filter the top three and bottom three percentage female in the relevant discipline 
# during 2016-2021 institutions and assign them to respective variables then join them together
eng <- totals0221 %>% filter(DegreeDisciplineName=="engineeringgeneral")
jhopkins <- totals0221 %>% filter(Institution=="JohnsHopkins")
umannarbor <- totals0221 %>% filter(Institution=="UM-AnnArbor")
stanford <- totals0221 %>% filter(Institution=="Stanford")
northwestern <- totals0221 %>% filter(Institution=="Northwestern")
caltech <- totals0221 %>% filter(Institution=="Caltech")
carnegiemellon <- totals0221 %>% filter(Institution=="CarnegieMellon")
totals0221$Institution <- gsub("UC-LA", "UCLA", totals0221$Institution)
ucla <- totals0221 %>% filter(Institution=="UCLA")
cornell <- totals0221 %>% filter(Institution=="Cornell")
vanderbilt <- totals0221 %>% filter(Institution=="Vanderbilt")
nyu <- totals0221 %>% filter(Institution=="NYU")
rice <- totals0221 %>% filter(Institution=="Rice")
totals0221$Institution <- gsub("UC-B", "UC-Berkeley", totals0221$Institution)
ucb <- totals0221 %>% filter(Institution=="UC-Berkeley")
yale <- totals0221 %>% filter(Institution=="Yale")
princeton <- totals0221 %>% filter(Institution=="Princeton")
uchicago <- totals0221 %>% filter(Institution=="UChicago")
mit <- totals0221 %>% filter(Institution=="MIT")
wustlouis <- totals0221 %>% filter(Institution=="WU-St.Louis")
brown <- totals0221 %>% filter(Institution=="Brown")
unotredame <- totals0221 %>% filter(Institution=="UNotreDame")
harvard <- totals0221 %>% filter(Institution=="Harvard")
columbia <- totals0221 %>% filter(Institution=="Columbia")

# Create scatter plots to show the Percentage Female in Selected
# Universities Between Year Ranges

# General Engineering
top3bottom3 <- rbind(jhopkins,stanford,umannarbor,northwestern,caltech,carnegiemellon)
ggplot(data=top3bottom3[top3bottom3$DegreeDisciplineName=="engineeringgeneral",], 
       aes(x=AcademicYear, y=PercentFemale,group=Institution)) + 
  geom_point(aes(color=Institution)) +
  geom_line(aes(color=Institution)) + 
  xlab("Year Range") + ylab("Percentage Female") +
  theme(text = element_text(size = 20))

# Computer Science
top3bottom3 <- rbind(vanderbilt,stanford,ucla,northwestern,cornell,carnegiemellon)
ggplot(data=top3bottom3[top3bottom3$DegreeDisciplineName=="computerandinformationsciencesandsupportservices",], 
       aes(x=AcademicYear, y=PercentFemale,group=Institution)) + 
  geom_point(aes(color=Institution)) +
  geom_line(aes(color=Institution)) + 
  xlab("Year Range") + ylab("Percentage Female") +
  theme(text = element_text(size = 20))

# Electrical Engineering
top3bottom3 <- rbind(caltech,nyu,rice,ucb,cornell,yale)
ggplot(data=top3bottom3[top3bottom3$DegreeDisciplineName=="electricalelectronicsandcommunicationsengineering",], 
       aes(x=AcademicYear, y=PercentFemale,group=Institution)) + 
  geom_point(aes(color=Institution)) +
  geom_line(aes(color=Institution)) + 
  xlab("Year Range") + ylab("Percentage Female") +
  theme(text = element_text(size = 20))

# Mathematics and Statistics
top3bottom3 <- rbind(carnegiemellon,nyu,princeton,ucla,stanford,uchicago)
ggplot(data=top3bottom3[top3bottom3$DegreeDisciplineName=="mathematicsandstatistics",], 
       aes(x=AcademicYear, y=PercentFemale,group=Institution)) + 
  geom_point(aes(color=Institution)) +
  geom_line(aes(color=Institution)) + 
  xlab("Year Range") + ylab("Percentage Female") +
  theme(text = element_text(size = 20))

# Mechanical Engineering
top3bottom3 <- rbind(caltech,mit,ucb,ucla,stanford,wustlouis)
ggplot(data=top3bottom3[top3bottom3$DegreeDisciplineName=="mechanicalengineering",], 
       aes(x=AcademicYear, y=PercentFemale,group=Institution)) + 
  geom_point(aes(color=Institution)) +
  geom_line(aes(color=Institution)) + 
  xlab("Year Range") + ylab("Percentage Female") +
  theme(text = element_text(size = 20))

# Physics
top3bottom3 <- rbind(brown,caltech,cornell,princeton,rice,unotredame)
ggplot(data=top3bottom3[top3bottom3$DegreeDisciplineName=="physics",], 
       aes(x=AcademicYear, y=PercentFemale,group=Institution)) + 
  geom_point(aes(color=Institution)) +
  geom_line(aes(color=Institution)) + 
  xlab("Year Range") + ylab("Percentage Female") +
  theme(text = element_text(size = 20))

# Graph the top 5 ranked universities with the bottom 5 ranked universities in computer science
# and the top 7 ranked universities in computer science
top5bottom5 <- rbind(mit,carnegiemellon,stanford,ucb,harvard,
                     northwestern,wustlouis,vanderbilt,unotredame,rice)
ggplot(data=top5bottom5[top5bottom5$DegreeDisciplineName=="computerandinformationsciencesandsupportservices",], 
       aes(x=AcademicYear, y=PercentFemale,group=Institution)) + 
  geom_point(aes(color=Institution)) +
  geom_line(aes(color=Institution)) + 
  xlab("Year Range") + ylab("Percentage Female")

top10compsci <- rbind(mit,carnegiemellon,stanford,ucb,harvard,princeton,cornell,ucla,columbia,nyu)
ggplot(data=top10compsci[top10compsci$DegreeDisciplineName=="computerandinformationsciencesandsupportservices",], 
       aes(x=AcademicYear, y=PercentFemale,group=Institution)) + 
  geom_point(aes(color=Institution)) +
  geom_line(aes(color=Institution)) + 
  xlab("Year Range") + ylab("Percentage Female")

# Data manipulation to assess correlation
# Update 'Institution' names for consistency
totals0221$Institution <- ifelse(totals0221$Institution == "Upenn", "UPenn", totals0221$Institution)
totals0221$Institution <- ifelse(totals0221$Institution == "UW-St.Louis", "WU-St.Louis", totals0221$Institution)

# Filter specific DegreeDisciplineNames and assign them to respective variables 
# then join them together
aerospace <- totals0221 %>%   filter(DegreeDisciplineName=="aerospaceaeronauticalandastronauticalengineering")
compeng <- totals0221 %>%   filter(DegreeDisciplineName=="computerengineering")
eng <- totals0221 %>%   filter(DegreeDisciplineName=="engineeringgeneral")
engphys <- totals0221 %>%   filter(DegreeDisciplineName=="engineeringphysics")
engother <- totals0221 %>%   filter(DegreeDisciplineName=="engineeringother")
selecteddegrees <- rbind(selecteddegrees, aerospace, compeng, eng, engphys, engother)
selecteddegrees <- distinct(selecteddegrees, .keep_all = TRUE)

# Modify 'Institution' names for consistency and readability
selecteddegrees$Institution <- gsub("UC-LA", "UCLA", selecteddegrees$Institution)
selecteddegrees$Institution <- gsub("UC-B", "UC-Berkeley", selecteddegrees$Institution)
selecteddegrees$Institution <- gsub("UC-SD", "UCSD", selecteddegrees$Institution)
selecteddegrees$Institution <- gsub("Upenn", "UPenn", selecteddegrees$Institution)
selecteddegrees$Institution <- gsub("UW-St.Louis", "WU-St.Louis", selecteddegrees$Institution)

# Reorder columns, pivot selectedpercentages to be wider, and rename its columns
selectedpercentages <- selecteddegrees %>%
  select(Institution, DegreeDisciplineName, PercentFemale, AcademicYear) %>% 
  pivot_wider(names_from = AcademicYear, values_from = PercentFemale, names_prefix = "PercentFemale_")
colnames(selectedpercentages) <- c("Institution", "DegreeDisciplineName", "PercentFemale0209", "PercentFemale1015", "PercentFemale1621")

# Calculate change over time and restructure the data
selectedpercentages <- selectedpercentages %>%
  mutate(ChangeOverTime = ifelse(
    !is.na(PercentFemale0209), 
    PercentFemale1621 - PercentFemale0209, 
    NA
  )) %>%
  select(Institution, DegreeDisciplineName, PercentFemale1621, ChangeOverTime) %>%
  pivot_wider(
    names_from = DegreeDisciplineName,
    values_from = c(PercentFemale1621, ChangeOverTime)
  )

# Read UniversityRanks.csv, merge it with selectedpercentages, 
# update column names for readability, and reorder columns
UniversityRanks <- read.csv("UniversityRanks.csv")
selectedpercentages <- merge(selectedpercentages, UniversityRanks, by = "Institution", all = TRUE)
selectedpercentages <- selectedpercentages[-1, ]
colnames(selectedpercentages) <- c("Institution","PercentComputerScience",
  "PercentElectricalEngineering","PercentMathematicsandStatistics","PercentMechanicalEngineering",
  "PercentPhysics","PercentAerospaceEngineering","PercentComputerEngineering",
  "PercentEngineeringGeneral","PercentEngineeringPhysics","PercentEngineeringOther",
  "ChangeComputerScience","ChangeElectricalEngineering","ChangeMathematicsandStatistics",
  "ChangeMechanicalEngineering","ChangePhysics","ChangeAerospaceEngineering",
  "ChangeComputerEngineering","ChangeEngineeringGeneral","ChangeEngineeringPhysics",
  "ChangeEngineeringOther","RankAerospaceEngineering","RankComputerScience",
  "RankComputerEngineering","RankElectricalEngineering","RankEngineeringGeneral",
  "RankEngineeringPhysics","RankMathematicsandStatistics","RankMechanicalEngineering",
  "RankPhysics","RankEngineeringandTechnologyAggregate")
selectedpercentages <- selectedpercentages[c("Institution", "PercentComputerScience", 
  "ChangeComputerScience", "RankComputerScience", "PercentElectricalEngineering",
  "ChangeElectricalEngineering", "RankElectricalEngineering", "PercentMathematicsandStatistics", 
  "ChangeMathematicsandStatistics", "RankMathematicsandStatistics", "PercentMechanicalEngineering",
  "ChangeMechanicalEngineering", "RankMechanicalEngineering", "PercentPhysics", "ChangePhysics", 
  "RankPhysics", "PercentAerospaceEngineering", "ChangeAerospaceEngineering", "RankAerospaceEngineering",
  "PercentComputerEngineering", "ChangeComputerEngineering", "RankComputerEngineering",
  "PercentEngineeringGeneral", "ChangeEngineeringGeneral","RankEngineeringGeneral",
  "PercentEngineeringPhysics", "ChangeEngineeringPhysics", "RankEngineeringPhysics",
  "PercentEngineeringOther", "ChangeEngineeringOther", "RankEngineeringandTechnologyAggregate")]

# Define pairs of columns to analyze correlations
rankpairs <- list(
  c("PercentComputerScience", "RankComputerScience"),
  c("PercentElectricalEngineering", "RankElectricalEngineering"),
  c("PercentMathematicsandStatistics", "RankMathematicsandStatistics"),
  c("PercentMechanicalEngineering", "RankMechanicalEngineering"),
  c("PercentPhysics", "RankPhysics"),
  c("PercentAerospaceEngineering", "RankEngineeringandTechnologyAggregate"),
  c("PercentComputerEngineering", "RankEngineeringandTechnologyAggregate"),
  c("PercentEngineeringGeneral", "RankEngineeringandTechnologyAggregate"),
  c("PercentEngineeringPhysics", "RankEngineeringandTechnologyAggregate"),
  c("PercentEngineeringOther", "RankEngineeringandTechnologyAggregate"),
  c("ChangeComputerScience", "RankComputerScience"),
  c("ChangeElectricalEngineering", "RankElectricalEngineering"),
  c("ChangeMathematicsandStatistics", "RankMathematicsandStatistics"),
  c("ChangeMechanicalEngineering", "RankMechanicalEngineering"),
  c("ChangePhysics", "RankPhysics"),
  c("ChangeAerospaceEngineering", "RankEngineeringandTechnologyAggregate"),
  c("ChangeComputerEngineering", "RankEngineeringandTechnologyAggregate"),
  c("ChangeEngineeringGeneral", "RankEngineeringandTechnologyAggregate"),
  c("ChangeEngineeringPhysics", "RankEngineeringandTechnologyAggregate"),
  c("ChangeEngineeringOther", "RankEngineeringandTechnologyAggregate")
)

# Create empty results list
results <- list()

# Convert Rank columns to numeric for correlation analysis
selectedpercentages$RankAerospaceEngineering <- as.numeric(selectedpercentages$RankAerospaceEngineering)
selectedpercentages$RankComputerEngineering <- as.numeric(selectedpercentages$RankComputerEngineering)
selectedpercentages$RankEngineeringGeneral <- as.numeric(selectedpercentages$RankEngineeringGeneral)
selectedpercentages$RankEngineeringPhysics <- as.numeric(selectedpercentages$RankEngineeringPhysics)

# Loop through rankpairs to calculate correlations
for (pair in rankpairs) {
  tryCatch({
  # Calculate Pearson correlation and associated p-value
  pearson_test <- cor.test(selectedpercentages[[pair[1]]], selectedpercentages[[pair[2]]], 
                           method = "pearson")
  pearson_corr <- pearson_test$estimate
  pearson_p_value <- pearson_test$p.value
  pearson_p_value_rounded <- round(pearson_p_value, digits = 3)
  
  # Calculate Kendall correlation and associated p-value
  kendall_test <- cor.test(selectedpercentages[[pair[1]]], selectedpercentages[[pair[2]]],
                           method = "kendall")
  kendall_corr <- kendall_test$estimate
  kendall_p_value <- kendall_test$p.value
  kendall_p_value_rounded <- round(kendall_p_value, digits = 3)
  
  # Calculate Spearman correlation and associated p-value
  spearman_test <- cor.test(selectedpercentages[[pair[1]]], selectedpercentages[[pair[2]]],
                            method = "spearman")
  spearman_corr <- spearman_test$estimate
  spearman_p_value <- spearman_test$p.value
  spearman_p_value_rounded <- round(spearman_p_value, digits = 3)
  
  results <- c(results, list(list(Pair = paste(pair, collapse = "-"), 
                                  Pearson_Correlation = pearson_corr, 
                                  Pearson_p_value = pearson_p_value_rounded, 
                                  Kendall_Correlation = kendall_corr, 
                                  Kendall_p_value = kendall_p_value_rounded, 
                                  Spearman_Correlation = spearman_corr, 
                                  Spearman_p_value = spearman_p_value_rounded)))
  }, error = function(e) {
    # If an error occurs, store NA values for correlation and p-values
    results <- c(results, list(list(Pair = paste(pair, collapse = "-"), 
                                    Pearson_Correlation = NA, 
                                    Pearson_p_value = NA, 
                                    Kendall_Correlation = NA, 
                                    Kendall_p_value = NA, 
                                    Spearman_Correlation = NA, 
                                    Spearman_p_value = NA)))
  })
}

# Convert the list of results into a tibble
correlation_table <- do.call(rbind, results)
correlation_table <- as_tibble(correlation_table)

# Keep the results that are statistically significant
significantlist <- c('PercentComputerScience-RankComputerScience',
                     'PercentMechanicalEngineering-RankMechanicalEngineering')
significant <- correlation_table %>% filter(Pair %in% significantlist)

# Relationship graph between Rank and Percentage Female for the significant findings
ggscatter(selectedpercentages, x = "RankComputerScience", y = "PercentComputerScience", 
          add = "reg.line", conf.int = TRUE, 
          cor.coef = TRUE, cor.method = "spearman",
          xlab = "Computer Science Rank", ylab = "Percentage Female in Computer Science")

ggscatter(selectedpercentages, x = "RankMechanicalEngineering", y = "PercentMechanicalEngineering", 
          add = "reg.line", conf.int = TRUE, 
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Mechanical Engineering Rank", ylab = "Percentage Female in Mechanical Engineering")

# Creating convergence graphs

# Computer science
# Subset data for the relevant DegreeDisciplineName
subset_data <- totals0221[totals0221$DegreeDisciplineName == "computerandinformationsciencesandsupportservices", ]
subset_data$AcademicYear <- as.factor(subset_data$AcademicYear)
subset_data$AcademicYear <- as.numeric(subset_data$AcademicYear)

# Convert AcademicYear to numerical values (necessary to create linear regression lines)
subset_data$AcademicYear <- ifelse(subset_data$AcademicYear == 1, "Value1",
                          ifelse(subset_data$AcademicYear == 2, "Value2",
                                 ifelse(subset_data$AcademicYear == 3, "Value3",
                                        as.character(subset_data$AcademicYear))))
subset_data$AcademicYear <- as.factor(subset_data$AcademicYear)
subset_data$AcademicYear <- gsub("Value","",subset_data$AcademicYear)
subset_data$AcademicYear <- as.numeric(subset_data$AcademicYear)

# Create a scatter plot with regression line for the disciplinary percentage female over time
ggplot(subset_data, aes(x = AcademicYear, y = PercentFemale)) +
  geom_point() +
  geom_smooth(method = "lm", se = TRUE) +
  xlab("Academic Year") +
  ylab("Percentage Female") +
  scale_x_continuous(breaks = c(1, 2, 3), labels = c("2002-2009", "2010-2015", "2016-2021")) +
  theme(text = element_text(size = 20, hjust = 0.62))

# Calculate coefficient of variation in percentage female over time
coevariation_comp <- subset_data %>%
  group_by(AcademicYear) %>%
  summarise(CV = (sd(PercentFemale) / mean(PercentFemale)) * 100)
coevariation_comp$DegreeDisciplineName <- "Computer Science"

# Electrical Engineering
# Subset data for the relevant DegreeDisciplineName
subset_data <- totals0221[totals0221$DegreeDisciplineName == "electricalelectronicsandcommunicationsengineering", ]
subset_data$AcademicYear <- as.factor(subset_data$AcademicYear)
subset_data$AcademicYear <- as.numeric(subset_data$AcademicYear)

# Convert AcademicYear to numerical values (necessary to create linear regression lines)
subset_data$AcademicYear <- ifelse(subset_data$AcademicYear == 1, "Value1",
                                   ifelse(subset_data$AcademicYear == 2, "Value2",
                                          ifelse(subset_data$AcademicYear == 3, "Value3",
                                                 as.character(subset_data$AcademicYear))))
subset_data$AcademicYear <- as.factor(subset_data$AcademicYear)
subset_data$AcademicYear <- gsub("Value","",subset_data$AcademicYear)
subset_data$AcademicYear <- as.numeric(subset_data$AcademicYear)

# Create a scatter plot with regression line for the disciplinary percentage female over time
ggplot(subset_data, aes(x = AcademicYear, y = PercentFemale)) +
  geom_point() +
  geom_smooth(method = "lm", se = TRUE) +
  xlab("Academic Year") +
  ylab("Percentage Female") +
  scale_x_continuous(breaks = c(1, 2, 3), labels = c("2002-2009", "2010-2015", "2016-2021")) +
  theme(text = element_text(size = 20, hjust = 0.62))

# Calculate coefficient of variation in percentage female over time
coevariation_elec <- subset_data %>%
  group_by(AcademicYear) %>%
  summarise(CV = (sd(PercentFemale) / mean(PercentFemale)) * 100)
coevariation_elec$DegreeDisciplineName <- "Electrical Engineering"

# Mechanical Engineering
# Subset data for the relevant DegreeDisciplineName
subset_data <- totals0221[totals0221$DegreeDisciplineName == "mechanicalengineering", ]
subset_data$AcademicYear <- as.factor(subset_data$AcademicYear)
subset_data$AcademicYear <- as.numeric(subset_data$AcademicYear)

# Convert AcademicYear to numerical values (necessary to create linear regression lines)
subset_data$AcademicYear <- ifelse(subset_data$AcademicYear == 1, "Value1",
                                   ifelse(subset_data$AcademicYear == 2, "Value2",
                                          ifelse(subset_data$AcademicYear == 3, "Value3",
                                                 as.character(subset_data$AcademicYear))))
subset_data$AcademicYear <- as.factor(subset_data$AcademicYear)
subset_data$AcademicYear <- gsub("Value","",subset_data$AcademicYear)
subset_data$AcademicYear <- as.numeric(subset_data$AcademicYear)

# Create a scatter plot with regression line for the disciplinary percentage female over time
ggplot(subset_data, aes(x = AcademicYear, y = PercentFemale)) +
  geom_point() +
  geom_smooth(method = "lm", se = TRUE) +
  xlab("Academic Year") +
  ylab("Percentage Female") +
  scale_x_continuous(breaks = c(1, 2, 3), labels = c("2002-2009", "2010-2015", "2016-2021")) +
  theme(text = element_text(size = 20, hjust = 0.62))

# Calculate coefficient of variation in percentage female over time
coevariation_mech <- subset_data %>%
  group_by(AcademicYear) %>%
  summarise(CV = (sd(PercentFemale) / mean(PercentFemale)) * 100)
coevariation_mech$DegreeDisciplineName <- "Mechanical Engineering"

# Mathematics and Statistics
# Subset data for the relevant DegreeDisciplineName
subset_data <- totals0221[totals0221$DegreeDisciplineName == "mathematicsandstatistics", ]
subset_data$AcademicYear <- as.factor(subset_data$AcademicYear)
subset_data$AcademicYear <- as.numeric(subset_data$AcademicYear)

# Convert AcademicYear to numerical values (necessary to create linear regression lines)
subset_data$AcademicYear <- ifelse(subset_data$AcademicYear == 1, "Value1",
                                   ifelse(subset_data$AcademicYear == 2, "Value2",
                                          ifelse(subset_data$AcademicYear == 3, "Value3",
                                                 as.character(subset_data$AcademicYear))))
subset_data$AcademicYear <- as.factor(subset_data$AcademicYear)
subset_data$AcademicYear <- gsub("Value","",subset_data$AcademicYear)
subset_data$AcademicYear <- as.numeric(subset_data$AcademicYear)

# Create a scatter plot with regression line for the disciplinary percentage female over time
ggplot(subset_data, aes(x = AcademicYear, y = PercentFemale)) +
  geom_point() +
  geom_smooth(method = "lm", se = TRUE) +
  xlab("Academic Year") +
  ylab("Percentage Female") +
  scale_x_continuous(breaks = c(1, 2, 3), labels = c("2002-2009", "2010-2015", "2016-2021")) +
  theme(text = element_text(size = 20, hjust = 0.62))

# Calculate coefficient of variation in percentage female over time
coevariation_math <- subset_data %>%
  group_by(AcademicYear) %>%
  summarise(CV = (sd(PercentFemale) / mean(PercentFemale)) * 100)
coevariation_math$DegreeDisciplineName <- "Mathematics and Statistics"

# Physics
# Subset data for the relevant DegreeDisciplineName
subset_data <- totals0221[totals0221$DegreeDisciplineName == "physics", ]
subset_data$AcademicYear <- as.factor(subset_data$AcademicYear)
subset_data$AcademicYear <- as.numeric(subset_data$AcademicYear)

# Convert AcademicYear to numerical values (necessary to create linear regression lines)
subset_data$AcademicYear <- ifelse(subset_data$AcademicYear == 1, "Value1",
                                   ifelse(subset_data$AcademicYear == 2, "Value2",
                                          ifelse(subset_data$AcademicYear == 3, "Value3",
                                                 as.character(subset_data$AcademicYear))))
subset_data$AcademicYear <- as.factor(subset_data$AcademicYear)
subset_data$AcademicYear <- gsub("Value","",subset_data$AcademicYear)
subset_data$AcademicYear <- as.numeric(subset_data$AcademicYear)

# Create a scatter plot with regression line for the disciplinary percentage female over time
ggplot(subset_data, aes(x = AcademicYear, y = PercentFemale)) +
  geom_point() +
  geom_smooth(method = "lm", se = TRUE) +
  xlab("Academic Year") +
  ylab("Percentage Female") +
  scale_x_continuous(breaks = c(1, 2, 3), labels = c("2002-2009", "2010-2015", "2016-2021")) +
  theme(text = element_text(size = 20, hjust = 0.62))

# Calculate coefficient of variation in percentage female over time
coevariation_phys <- subset_data %>%
  group_by(AcademicYear) %>%
  summarise(CV = (sd(PercentFemale) / mean(PercentFemale)) * 100)
coevariation_phys$DegreeDisciplineName <- "Physics"

# General Engineering
# Subset data for the relevant DegreeDisciplineName
subset_data <- totals0221[totals0221$DegreeDisciplineName == "engineeringgeneral", ]
subset_data$AcademicYear <- as.factor(subset_data$AcademicYear)
subset_data$AcademicYear <- as.numeric(subset_data$AcademicYear)

# Convert AcademicYear to numerical values (necessary to create linear regression lines)
subset_data$AcademicYear <- ifelse(subset_data$AcademicYear == 1, "Value1",
                                   ifelse(subset_data$AcademicYear == 2, "Value2",
                                          ifelse(subset_data$AcademicYear == 3, "Value3",
                                                 as.character(subset_data$AcademicYear))))
subset_data$AcademicYear <- as.factor(subset_data$AcademicYear)
subset_data$AcademicYear <- gsub("Value","",subset_data$AcademicYear)
subset_data$AcademicYear <- as.numeric(subset_data$AcademicYear)

# Create a scatter plot with regression line for the disciplinary percentage female over time
ggplot(subset_data, aes(x = AcademicYear, y = PercentFemale)) +
  geom_point() +
  geom_smooth(method = "lm", se = TRUE) +
  xlab("Academic Year") +
  ylab("Percentage Female") +
  scale_x_continuous(breaks = c(1, 2, 3), labels = c("2002-2009", "2010-2015", "2016-2021")) +
  theme(text = element_text(size = 20, hjust = 0.62))

# Calculate coefficient of variation in percentage female over time
coevariation_eng <- subset_data %>%
  group_by(AcademicYear) %>%
  summarise(CV = (sd(PercentFemale) / mean(PercentFemale)) * 100)
coevariation_eng$DegreeDisciplineName <- "General Engineering"

# Calculate coefficient of variation in percentage female over time for the remaining
# three most male-dominated disciplines
coevariation_aero <- totals0221[totals0221$DegreeDisciplineName == "aerospaceaeronauticalandastronauticalengineering", ] %>%
  group_by(AcademicYear) %>%
  summarise(CV = (sd(PercentFemale) / mean(PercentFemale)) * 100)
coevariation_aero$DegreeDisciplineName <- "Aerospace Engineering"

coevariation_compeng <- totals0221[totals0221$DegreeDisciplineName == "computerengineering", ] %>%
  group_by(AcademicYear) %>%
  summarise(CV = (sd(PercentFemale) / mean(PercentFemale)) * 100)
coevariation_compeng$DegreeDisciplineName <- "Computer Engineering"

coevariation_engphys <- totals0221[totals0221$DegreeDisciplineName == "engineeringphysics", ] %>%
  group_by(AcademicYear) %>%
  summarise(CV = (sd(PercentFemale) / mean(PercentFemale)) * 100)
coevariation_engphys$DegreeDisciplineName <- "Engineering Physics"

# Put coevariation dataframes together
coevariation <- rbind(coevariation_comp,coevariation_elec,coevariation_mech,coevariation_math,
                      coevariation_phys,coevariation_eng,coevariation_aero,coevariation_compeng,
                      coevariation_engphys)
coevariation$AcademicYear <- ifelse(coevariation$AcademicYear == 1, "2002-2009",
                          ifelse(coevariation$AcademicYear == 2, "2010-2015",
                                 ifelse(coevariation$AcademicYear == 3, "2016-2021", coevariation$AcademicYear)))
coevariation <- coevariation %>% select("DegreeDisciplineName", "CV", "AcademicYear")

# Calculate the change in coefficient of variation over time
cvchange <- coevariation %>%
  filter(AcademicYear %in% c("2002-2009", "2016-2021")) %>%
  group_by(DegreeDisciplineName) %>%
  summarise(ChangeCV = CV[AcademicYear == "2016-2021"] - CV[AcademicYear == "2002-2009"])
