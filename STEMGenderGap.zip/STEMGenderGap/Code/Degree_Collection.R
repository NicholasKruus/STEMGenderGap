# UPDATE this working directory to the folder named "R Imports" inside of the 
# "R Imports" .zip file.
#
# IF you are using your own data, you should ensure the working directory is the folder where 
# you have collected your raw NCES IPEDS data and properly named it
# (see README for naming instructions).
setwd("ENTER WORKING DIRECTORY")
library(tidyverse)
library(dplyr)
library(readr)
library(tidyr)

# Read the data from RawHarvard1.csv into a data frame and transpose it.
rawharvard1 <- t(read_csv("RawHarvard1.csv"))

# Add row names as the first column of the data frame.
rawharvard1 <- cbind(rownames(rawharvard1), rawharvard1)

# Remove row names to make the data frame cleaner.
rownames(rawharvard1) <- NULL

# Convert the data frame into a new data frame with a column named 'DegreeDiscipline'.
rawharvard1 <- data.frame(DegreeDiscipline = rawharvard1)

# Rename the columns of the data frame as 'DegreeDiscipline' and 'Total'.
colnames(rawharvard1) <- c("DegreeDiscipline", "Total")

# Clean up the 'DegreeDiscipline' column by removing certain strings using regex.
rawharvard1$DegreeDiscipline <- gsub("\\(C2008_A", "", rawharvard1$DegreeDiscipline)
rawharvard1$DegreeDiscipline <- gsub("\\First major", "", rawharvard1$DegreeDiscipline)
rawharvard1$DegreeDiscipline <- gsub("\\Second major", "", rawharvard1$DegreeDiscipline)

# Convert the 'Total' column to numeric, group the data by 'DegreeDiscipline', and 
# calculate the sum of 'Total' for each group.
rawharvard1 <- rawharvard1 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

# Repeat the same processing for every RawHarvard file (2-7)
rawharvard2 <- t(read_csv("RawHarvard2.csv"))
rawharvard2 <- cbind(rownames(rawharvard2), rawharvard2)
rownames(rawharvard2) <- NULL
rawharvard2 <- data.frame(DegreeDiscipline = rawharvard2)
colnames(rawharvard2) <- c("DegreeDiscipline","Total")
rawharvard2$DegreeDiscipline <- gsub("\\(C2007_A", "", rawharvard2$DegreeDiscipline)
rawharvard2$DegreeDiscipline <- gsub("\\First major", "", rawharvard2$DegreeDiscipline)
rawharvard2$DegreeDiscipline <- gsub("\\Second major", "", rawharvard2$DegreeDiscipline)

rawharvard2 <- rawharvard2 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawharvard3 <- t(read_csv("RawHarvard3.csv"))
rawharvard3 <- cbind(rownames(rawharvard3), rawharvard3)
rownames(rawharvard3) <- NULL
rawharvard3 <- data.frame(DegreeDiscipline = rawharvard3)
colnames(rawharvard3) <- c("DegreeDiscipline","Total")
rawharvard3$DegreeDiscipline <- gsub("\\(C2006_A", "", rawharvard3$DegreeDiscipline)
rawharvard3$DegreeDiscipline <- gsub("\\First major", "", rawharvard3$DegreeDiscipline)
rawharvard3$DegreeDiscipline <- gsub("\\Second major", "", rawharvard3$DegreeDiscipline)

rawharvard3 <- rawharvard3 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))


rawharvard4 <- t(read_csv("RawHarvard4.csv"))
rawharvard4 <- cbind(rownames(rawharvard4), rawharvard4)
rownames(rawharvard4) <- NULL
rawharvard4 <- data.frame(DegreeDiscipline = rawharvard4)
colnames(rawharvard4) <- c("DegreeDiscipline","Total")
rawharvard4$DegreeDiscipline <- gsub("\\(C2005_A", "", rawharvard4$DegreeDiscipline)
rawharvard4$DegreeDiscipline <- gsub("\\First major", "", rawharvard4$DegreeDiscipline)
rawharvard4$DegreeDiscipline <- gsub("\\Second major", "", rawharvard4$DegreeDiscipline)

rawharvard4 <- rawharvard4 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawharvard5 <- t(read_csv("RawHarvard5.csv"))
rawharvard5 <- cbind(rownames(rawharvard5), rawharvard5)
rownames(rawharvard5) <- NULL
rawharvard5 <- data.frame(DegreeDiscipline = rawharvard5)
colnames(rawharvard5) <- c("DegreeDiscipline","Total")
rawharvard5$DegreeDiscipline <- gsub("\\(C2004_A", "", rawharvard5$DegreeDiscipline)
rawharvard5$DegreeDiscipline <- gsub("\\First major", "", rawharvard5$DegreeDiscipline)
rawharvard5$DegreeDiscipline <- gsub("\\Second major", "", rawharvard5$DegreeDiscipline)

rawharvard5 <- rawharvard5 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawharvard6 <- t(read_csv("RawHarvard6.csv"))
rawharvard6 <- cbind(rownames(rawharvard6), rawharvard6)
rownames(rawharvard6) <- NULL
rawharvard6 <- data.frame(DegreeDiscipline = rawharvard6)
colnames(rawharvard6) <- c("DegreeDiscipline","Total")
rawharvard6$DegreeDiscipline <- gsub("\\(C2003_A", "", rawharvard6$DegreeDiscipline)
rawharvard6$DegreeDiscipline <- gsub("\\First major", "", rawharvard6$DegreeDiscipline)
rawharvard6$DegreeDiscipline <- gsub("\\Second major", "", rawharvard6$DegreeDiscipline)

rawharvard6 <- rawharvard6 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawharvard7 <- t(read_csv("RawHarvard7.csv"))
rawharvard7 <- cbind(rownames(rawharvard7), rawharvard7)
rownames(rawharvard7) <- NULL
rawharvard7 <- data.frame(DegreeDiscipline = rawharvard7)
colnames(rawharvard7) <- c("DegreeDiscipline","Total")
rawharvard7$DegreeDiscipline <- gsub("\\(C2009_A", "", rawharvard7$DegreeDiscipline)
rawharvard7$DegreeDiscipline <- gsub("\\First major", "", rawharvard7$DegreeDiscipline)
rawharvard7$DegreeDiscipline <- gsub("\\Second major", "", rawharvard7$DegreeDiscipline)

rawharvard7 <- rawharvard7 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

# Join the rawharvard dataframes together, matching by the DegreeDiscipline
rawharvard <- left_join(rawharvard1, rawharvard2, by = "DegreeDiscipline") %>%
  left_join(rawharvard3, by = "DegreeDiscipline") %>%
  left_join(rawharvard4, by = "DegreeDiscipline") %>%
  left_join(rawharvard5, by = "DegreeDiscipline") %>%
  left_join(rawharvard6, by = "DegreeDiscipline") %>%
  left_join(rawharvard7, by = "DegreeDiscipline")

# Rename the column names of the data frame 'rawharvard' to be more descriptive
colnames(rawharvard) <- c("DegreeDiscipline", "Yr1", "Yr2", "Yr3", "Yr4", "Yr5", "Yr6", "Yr7")

# Convert the columns Yr1 to Yr7 to numeric by removing non-numeric characters and changing any commas to decimal points.
rawharvard <- rawharvard %>%
  mutate(across(Yr1:Yr7, ~ parse_number(as.character(.x))))

# For each row, calculate the total of Yr1 to Yr7 and store it in a new column 
# called 'Total'.
rawharvard <- rawharvard %>%
  rowwise() %>%
  mutate(Total = sum(c_across(Yr1:Yr7), na.rm = TRUE)) %>%
  ungroup()

# Remove the invalid data at row index 109.
rawharvard <- rawharvard[-109,]

# Clean up the workspace by removing unnecessary objects from memory.
rm(rawharvard1)
rm(rawharvard2)
rm(rawharvard3)
rm(rawharvard4)
rm(rawharvard5)
rm(rawharvard6)
rm(rawharvard7)

# Repeat the exact same process for every other university...
# CONTINUES UNTIL LINE 3068

rawbrown1 <- t(read_csv("RawBrown1.csv"))
rawbrown1 <- cbind(rownames(rawbrown1), rawbrown1)
rownames(rawbrown1) <- NULL
rawbrown1 <- data.frame(DegreeDiscipline = rawbrown1)
colnames(rawbrown1) <- c("DegreeDiscipline","Total")
rawbrown1$DegreeDiscipline <- gsub("\\(C2009_A", "", rawbrown1$DegreeDiscipline)
rawbrown1$DegreeDiscipline <- gsub("\\First major", "", rawbrown1$DegreeDiscipline)
rawbrown1$DegreeDiscipline <- gsub("\\Second major", "", rawbrown1$DegreeDiscipline)

rawbrown1 <- rawbrown1 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawbrown2 <- t(read_csv("RawBrown2.csv"))
rawbrown2 <- cbind(rownames(rawbrown2), rawbrown2)
rownames(rawbrown2) <- NULL
rawbrown2 <- data.frame(DegreeDiscipline = rawbrown2)
colnames(rawbrown2) <- c("DegreeDiscipline","Total")
rawbrown2$DegreeDiscipline <- gsub("\\(C2008_A", "", rawbrown2$DegreeDiscipline)
rawbrown2$DegreeDiscipline <- gsub("\\First major", "", rawbrown2$DegreeDiscipline)
rawbrown2$DegreeDiscipline <- gsub("\\Second major", "", rawbrown2$DegreeDiscipline)

rawbrown2 <- rawbrown2 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawbrown3 <- t(read_csv("RawBrown3.csv"))
rawbrown3 <- cbind(rownames(rawbrown3), rawbrown3)
rownames(rawbrown3) <- NULL
rawbrown3 <- data.frame(DegreeDiscipline = rawbrown3)
colnames(rawbrown3) <- c("DegreeDiscipline","Total")
rawbrown3$DegreeDiscipline <- gsub("\\(C2007_A", "", rawbrown3$DegreeDiscipline)
rawbrown3$DegreeDiscipline <- gsub("\\First major", "", rawbrown3$DegreeDiscipline)
rawbrown3$DegreeDiscipline <- gsub("\\Second major", "", rawbrown3$DegreeDiscipline)

rawbrown3 <- rawbrown3 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawbrown4 <- t(read_csv("RawBrown4.csv"))
rawbrown4 <- cbind(rownames(rawbrown4), rawbrown4)
rownames(rawbrown4) <- NULL
rawbrown4 <- data.frame(DegreeDiscipline = rawbrown4)
colnames(rawbrown4) <- c("DegreeDiscipline","Total")
rawbrown4$DegreeDiscipline <- gsub("\\(C2006_A", "", rawbrown4$DegreeDiscipline)
rawbrown4$DegreeDiscipline <- gsub("\\First major", "", rawbrown4$DegreeDiscipline)
rawbrown4$DegreeDiscipline <- gsub("\\Second major", "", rawbrown4$DegreeDiscipline)

rawbrown4 <- rawbrown4 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawbrown5 <- t(read_csv("RawBrown5.csv"))
rawbrown5 <- cbind(rownames(rawbrown5), rawbrown5)
rownames(rawbrown5) <- NULL
rawbrown5 <- data.frame(DegreeDiscipline = rawbrown5)
colnames(rawbrown5) <- c("DegreeDiscipline","Total")
rawbrown5$DegreeDiscipline <- gsub("\\(C2005_A", "", rawbrown5$DegreeDiscipline)
rawbrown5$DegreeDiscipline <- gsub("\\First major", "", rawbrown5$DegreeDiscipline)
rawbrown5$DegreeDiscipline <- gsub("\\Second major", "", rawbrown5$DegreeDiscipline)

rawbrown5 <- rawbrown5 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawbrown6 <- t(read_csv("RawBrown6.csv"))
rawbrown6 <- cbind(rownames(rawbrown6), rawbrown6)
rownames(rawbrown6) <- NULL
rawbrown6 <- data.frame(DegreeDiscipline = rawbrown6)
colnames(rawbrown6) <- c("DegreeDiscipline","Total")
rawbrown6$DegreeDiscipline <- gsub("\\(C2004_A", "", rawbrown6$DegreeDiscipline)
rawbrown6$DegreeDiscipline <- gsub("\\First major", "", rawbrown6$DegreeDiscipline)
rawbrown6$DegreeDiscipline <- gsub("\\Second major", "", rawbrown6$DegreeDiscipline)

rawbrown6 <- rawbrown6 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawbrown7 <- t(read_csv("RawBrown7.csv"))
rawbrown7 <- cbind(rownames(rawbrown7), rawbrown7)
rownames(rawbrown7) <- NULL
rawbrown7 <- data.frame(DegreeDiscipline = rawbrown7)
colnames(rawbrown7) <- c("DegreeDiscipline","Total")
rawbrown7$DegreeDiscipline <- gsub("\\(C2003_A", "", rawbrown7$DegreeDiscipline)
rawbrown7$DegreeDiscipline <- gsub("\\First major", "", rawbrown7$DegreeDiscipline)
rawbrown7$DegreeDiscipline <- gsub("\\Second major", "", rawbrown7$DegreeDiscipline)

rawbrown7 <- rawbrown7 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawbrown <- left_join(rawbrown1, rawbrown2, by = "DegreeDiscipline") %>%
  left_join(rawbrown3, by = "DegreeDiscipline") %>%
  left_join(rawbrown4, by = "DegreeDiscipline") %>%
  left_join(rawbrown5, by = "DegreeDiscipline") %>%
  left_join(rawbrown6, by = "DegreeDiscipline") %>%
  left_join(rawbrown7, by = "DegreeDiscipline")

colnames(rawbrown) <- c("DegreeDiscipline", "Yr1", "Yr2", "Yr3", "Yr4", "Yr5", "Yr6", "Yr7")
rawbrown <- rawbrown %>%
  mutate(across(Yr1:Yr7, ~ parse_number(as.character(.x)))) %>%
  rowwise() %>%
  mutate(Total = sum(c_across(Yr1:Yr7), na.rm = TRUE)) %>%
  ungroup()
rawbrown <- rawbrown[-109,]

rm(rawbrown1)
rm(rawbrown2)
rm(rawbrown3)
rm(rawbrown4)
rm(rawbrown5)
rm(rawbrown6)
rm(rawbrown7)

rawcaltech1 <- t(read_csv("RawCaltech1.csv"))
rawcaltech1 <- cbind(rownames(rawcaltech1), rawcaltech1)
rownames(rawcaltech1) <- NULL
rawcaltech1 <- data.frame(DegreeDiscipline = rawcaltech1)
colnames(rawcaltech1) <- c("DegreeDiscipline","Total")
rawcaltech1$DegreeDiscipline <- gsub("\\(C2009_A", "", rawcaltech1$DegreeDiscipline)
rawcaltech1$DegreeDiscipline <- gsub("\\First major", "", rawcaltech1$DegreeDiscipline)
rawcaltech1$DegreeDiscipline <- gsub("\\Second major", "", rawcaltech1$DegreeDiscipline)

rawcaltech1 <- rawcaltech1 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawcaltech2 <- t(read_csv("RawCaltech2.csv"))
rawcaltech2 <- cbind(rownames(rawcaltech2), rawcaltech2)
rownames(rawcaltech2) <- NULL
rawcaltech2 <- data.frame(DegreeDiscipline = rawcaltech2)
colnames(rawcaltech2) <- c("DegreeDiscipline","Total")
rawcaltech2$DegreeDiscipline <- gsub("\\(C2008_A", "", rawcaltech2$DegreeDiscipline)
rawcaltech2$DegreeDiscipline <- gsub("\\First major", "", rawcaltech2$DegreeDiscipline)
rawcaltech2$DegreeDiscipline <- gsub("\\Second major", "", rawcaltech2$DegreeDiscipline)

rawcaltech2 <- rawcaltech2 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawcaltech3 <- t(read_csv("RawCaltech3.csv"))
rawcaltech3 <- cbind(rownames(rawcaltech3), rawcaltech3)
rownames(rawcaltech3) <- NULL
rawcaltech3 <- data.frame(DegreeDiscipline = rawcaltech3)
colnames(rawcaltech3) <- c("DegreeDiscipline","Total")
rawcaltech3$DegreeDiscipline <- gsub("\\(C2007_A", "", rawcaltech3$DegreeDiscipline)
rawcaltech3$DegreeDiscipline <- gsub("\\First major", "", rawcaltech3$DegreeDiscipline)
rawcaltech3$DegreeDiscipline <- gsub("\\Second major", "", rawcaltech3$DegreeDiscipline)

rawcaltech3 <- rawcaltech3 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawcaltech4 <- t(read_csv("RawCaltech4.csv"))
rawcaltech4 <- cbind(rownames(rawcaltech4), rawcaltech4)
rownames(rawcaltech4) <- NULL
rawcaltech4 <- data.frame(DegreeDiscipline = rawcaltech4)
colnames(rawcaltech4) <- c("DegreeDiscipline","Total")
rawcaltech4$DegreeDiscipline <- gsub("\\(C2006_A", "", rawcaltech4$DegreeDiscipline)
rawcaltech4$DegreeDiscipline <- gsub("\\First major", "", rawcaltech4$DegreeDiscipline)
rawcaltech4$DegreeDiscipline <- gsub("\\Second major", "", rawcaltech4$DegreeDiscipline)

rawcaltech4 <- rawcaltech4 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawcaltech5 <- t(read_csv("RawCaltech5.csv"))
rawcaltech5 <- cbind(rownames(rawcaltech5), rawcaltech5)
rownames(rawcaltech5) <- NULL
rawcaltech5 <- data.frame(DegreeDiscipline = rawcaltech5)
colnames(rawcaltech5) <- c("DegreeDiscipline","Total")
rawcaltech5$DegreeDiscipline <- gsub("\\(C2005_A", "", rawcaltech5$DegreeDiscipline)
rawcaltech5$DegreeDiscipline <- gsub("\\First major", "", rawcaltech5$DegreeDiscipline)
rawcaltech5$DegreeDiscipline <- gsub("\\Second major", "", rawcaltech5$DegreeDiscipline)

rawcaltech5 <- rawcaltech5 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawcaltech6 <- t(read_csv("RawCaltech6.csv"))
rawcaltech6 <- cbind(rownames(rawcaltech6), rawcaltech6)
rownames(rawcaltech6) <- NULL
rawcaltech6 <- data.frame(DegreeDiscipline = rawcaltech6)
colnames(rawcaltech6) <- c("DegreeDiscipline","Total")
rawcaltech6$DegreeDiscipline <- gsub("\\(C2004_A", "", rawcaltech6$DegreeDiscipline)
rawcaltech6$DegreeDiscipline <- gsub("\\First major", "", rawcaltech6$DegreeDiscipline)
rawcaltech6$DegreeDiscipline <- gsub("\\Second major", "", rawcaltech6$DegreeDiscipline)

rawcaltech6 <- rawcaltech6 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawcaltech7 <- t(read_csv("RawCaltech7.csv"))
rawcaltech7 <- cbind(rownames(rawcaltech7), rawcaltech7)
rownames(rawcaltech7) <- NULL
rawcaltech7 <- data.frame(DegreeDiscipline = rawcaltech7)
colnames(rawcaltech7) <- c("DegreeDiscipline","Total")
rawcaltech7$DegreeDiscipline <- gsub("\\(C2003_A", "", rawcaltech7$DegreeDiscipline)
rawcaltech7$DegreeDiscipline <- gsub("\\First major", "", rawcaltech7$DegreeDiscipline)
rawcaltech7$DegreeDiscipline <- gsub("\\Second major", "", rawcaltech7$DegreeDiscipline)

rawcaltech7 <- rawcaltech7 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawcaltech <- left_join(rawcaltech1, rawcaltech2, by = "DegreeDiscipline") %>%
  left_join(rawcaltech3, by = "DegreeDiscipline") %>%
  left_join(rawcaltech4, by = "DegreeDiscipline") %>%
  left_join(rawcaltech5, by = "DegreeDiscipline") %>%
  left_join(rawcaltech6, by = "DegreeDiscipline") %>%
  left_join(rawcaltech7, by = "DegreeDiscipline")

colnames(rawcaltech) <- c("DegreeDiscipline", "Yr1", "Yr2", "Yr3", "Yr4", "Yr5", "Yr6", "Yr7")
rawcaltech <- rawcaltech %>%
  mutate(across(Yr1:Yr7, ~ parse_number(as.character(.x)))) %>%
  rowwise() %>%
  mutate(Total = sum(c_across(Yr1:Yr7), na.rm = TRUE)) %>%
  ungroup()
rawcaltech <- rawcaltech[-109,]

rm(rawcaltech1)
rm(rawcaltech2)
rm(rawcaltech3)
rm(rawcaltech4)
rm(rawcaltech5)
rm(rawcaltech6)
rm(rawcaltech7)

rawcarnegiemellon1 <- t(read_csv("RawCarnegiemellon1.csv"))
rawcarnegiemellon1 <- cbind(rownames(rawcarnegiemellon1), rawcarnegiemellon1)
rownames(rawcarnegiemellon1) <- NULL
rawcarnegiemellon1 <- data.frame(DegreeDiscipline = rawcarnegiemellon1)
colnames(rawcarnegiemellon1) <- c("DegreeDiscipline","Total")
rawcarnegiemellon1$DegreeDiscipline <- gsub("\\(C2008_A", "", rawcarnegiemellon1$DegreeDiscipline)
rawcarnegiemellon1$DegreeDiscipline <- gsub("\\First major", "", rawcarnegiemellon1$DegreeDiscipline)
rawcarnegiemellon1$DegreeDiscipline <- gsub("\\Second major", "", rawcarnegiemellon1$DegreeDiscipline)

rawcarnegiemellon1 <- rawcarnegiemellon1 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawcarnegiemellon2 <- t(read_csv("RawCarnegiemellon2.csv"))
rawcarnegiemellon2 <- cbind(rownames(rawcarnegiemellon2), rawcarnegiemellon2)
rownames(rawcarnegiemellon2) <- NULL
rawcarnegiemellon2 <- data.frame(DegreeDiscipline = rawcarnegiemellon2)
colnames(rawcarnegiemellon2) <- c("DegreeDiscipline","Total")
rawcarnegiemellon2$DegreeDiscipline <- gsub("\\(C2007_A", "", rawcarnegiemellon2$DegreeDiscipline)
rawcarnegiemellon2$DegreeDiscipline <- gsub("\\First major", "", rawcarnegiemellon2$DegreeDiscipline)
rawcarnegiemellon2$DegreeDiscipline <- gsub("\\Second major", "", rawcarnegiemellon2$DegreeDiscipline)

rawcarnegiemellon2 <- rawcarnegiemellon2 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawcarnegiemellon3 <- t(read_csv("RawCarnegiemellon3.csv"))
rawcarnegiemellon3 <- cbind(rownames(rawcarnegiemellon3), rawcarnegiemellon3)
rownames(rawcarnegiemellon3) <- NULL
rawcarnegiemellon3 <- data.frame(DegreeDiscipline = rawcarnegiemellon3)
colnames(rawcarnegiemellon3) <- c("DegreeDiscipline","Total")
rawcarnegiemellon3$DegreeDiscipline <- gsub("\\(C2006_A", "", rawcarnegiemellon3$DegreeDiscipline)
rawcarnegiemellon3$DegreeDiscipline <- gsub("\\First major", "", rawcarnegiemellon3$DegreeDiscipline)
rawcarnegiemellon3$DegreeDiscipline <- gsub("\\Second major", "", rawcarnegiemellon3$DegreeDiscipline)

rawcarnegiemellon3 <- rawcarnegiemellon3 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawcarnegiemellon4 <- t(read_csv("RawCarnegiemellon4.csv"))
rawcarnegiemellon4 <- cbind(rownames(rawcarnegiemellon4), rawcarnegiemellon4)
rownames(rawcarnegiemellon4) <- NULL
rawcarnegiemellon4 <- data.frame(DegreeDiscipline = rawcarnegiemellon4)
colnames(rawcarnegiemellon4) <- c("DegreeDiscipline","Total")
rawcarnegiemellon4$DegreeDiscipline <- gsub("\\(C2005_A", "", rawcarnegiemellon4$DegreeDiscipline)
rawcarnegiemellon4$DegreeDiscipline <- gsub("\\First major", "", rawcarnegiemellon4$DegreeDiscipline)
rawcarnegiemellon4$DegreeDiscipline <- gsub("\\Second major", "", rawcarnegiemellon4$DegreeDiscipline)

rawcarnegiemellon4 <- rawcarnegiemellon4 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawcarnegiemellon5 <- t(read_csv("RawCarnegiemellon5.csv"))
rawcarnegiemellon5 <- cbind(rownames(rawcarnegiemellon5), rawcarnegiemellon5)
rownames(rawcarnegiemellon5) <- NULL
rawcarnegiemellon5 <- data.frame(DegreeDiscipline = rawcarnegiemellon5)
colnames(rawcarnegiemellon5) <- c("DegreeDiscipline","Total")
rawcarnegiemellon5$DegreeDiscipline <- gsub("\\(C2004_A", "", rawcarnegiemellon5$DegreeDiscipline)
rawcarnegiemellon5$DegreeDiscipline <- gsub("\\First major", "", rawcarnegiemellon5$DegreeDiscipline)
rawcarnegiemellon5$DegreeDiscipline <- gsub("\\Second major", "", rawcarnegiemellon5$DegreeDiscipline)

rawcarnegiemellon5 <- rawcarnegiemellon5 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawcarnegiemellon6 <- t(read_csv("RawCarnegiemellon6.csv"))
rawcarnegiemellon6 <- cbind(rownames(rawcarnegiemellon6), rawcarnegiemellon6)
rownames(rawcarnegiemellon6) <- NULL
rawcarnegiemellon6 <- data.frame(DegreeDiscipline = rawcarnegiemellon6)
colnames(rawcarnegiemellon6) <- c("DegreeDiscipline","Total")
rawcarnegiemellon6$DegreeDiscipline <- gsub("\\(C2003_A", "", rawcarnegiemellon6$DegreeDiscipline)
rawcarnegiemellon6$DegreeDiscipline <- gsub("\\First major", "", rawcarnegiemellon6$DegreeDiscipline)
rawcarnegiemellon6$DegreeDiscipline <- gsub("\\Second major", "", rawcarnegiemellon6$DegreeDiscipline)

rawcarnegiemellon6 <- rawcarnegiemellon6 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawcarnegiemellon7 <- t(read_csv("RawCarnegiemellon7.csv"))
rawcarnegiemellon7 <- cbind(rownames(rawcarnegiemellon7), rawcarnegiemellon7)
rownames(rawcarnegiemellon7) <- NULL
rawcarnegiemellon7 <- data.frame(DegreeDiscipline = rawcarnegiemellon7)
colnames(rawcarnegiemellon7) <- c("DegreeDiscipline","Total")
rawcarnegiemellon7$DegreeDiscipline <- gsub("\\(C2009_A", "", rawcarnegiemellon7$DegreeDiscipline)
rawcarnegiemellon7$DegreeDiscipline <- gsub("\\First major", "", rawcarnegiemellon7$DegreeDiscipline)
rawcarnegiemellon7$DegreeDiscipline <- gsub("\\Second major", "", rawcarnegiemellon7$DegreeDiscipline)

rawcarnegiemellon7 <- rawcarnegiemellon7 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawcarnegiemellon <- left_join(rawcarnegiemellon1, rawcarnegiemellon2, by = "DegreeDiscipline") %>%
  left_join(rawcarnegiemellon3, by = "DegreeDiscipline") %>%
  left_join(rawcarnegiemellon4, by = "DegreeDiscipline") %>%
  left_join(rawcarnegiemellon5, by = "DegreeDiscipline") %>%
  left_join(rawcarnegiemellon6, by = "DegreeDiscipline") %>%
  left_join(rawcarnegiemellon7, by = "DegreeDiscipline")

colnames(rawcarnegiemellon) <- c("DegreeDiscipline", "Yr1", "Yr2", "Yr3", "Yr4", "Yr5", "Yr6", "Yr7")
rawcarnegiemellon <- rawcarnegiemellon %>%
  mutate(across(Yr1:Yr7, ~ parse_number(as.character(.x)))) %>%
  rowwise() %>%
  mutate(Total = sum(c_across(Yr1:Yr7), na.rm = TRUE)) %>%
  ungroup()
rawcarnegiemellon <- rawcarnegiemellon[-109,]

rm(rawcarnegiemellon1)
rm(rawcarnegiemellon2)
rm(rawcarnegiemellon3)
rm(rawcarnegiemellon4)
rm(rawcarnegiemellon5)
rm(rawcarnegiemellon6)
rm(rawcarnegiemellon7)

rawcolumbia1 <- t(read_csv("RawColumbia1.csv"))
rawcolumbia1 <- cbind(rownames(rawcolumbia1), rawcolumbia1)
rownames(rawcolumbia1) <- NULL
rawcolumbia1 <- data.frame(DegreeDiscipline = rawcolumbia1)
colnames(rawcolumbia1) <- c("DegreeDiscipline","Total")
rawcolumbia1$DegreeDiscipline <- gsub("\\(C2009_A", "", rawcolumbia1$DegreeDiscipline)
rawcolumbia1$DegreeDiscipline <- gsub("\\First major", "", rawcolumbia1$DegreeDiscipline)
rawcolumbia1$DegreeDiscipline <- gsub("\\Second major", "", rawcolumbia1$DegreeDiscipline)

rawcolumbia1 <- rawcolumbia1 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawcolumbia2 <- t(read_csv("RawColumbia2.csv"))
rawcolumbia2 <- cbind(rownames(rawcolumbia2), rawcolumbia2)
rownames(rawcolumbia2) <- NULL
rawcolumbia2 <- data.frame(DegreeDiscipline = rawcolumbia2)
colnames(rawcolumbia2) <- c("DegreeDiscipline","Total")
rawcolumbia2$DegreeDiscipline <- gsub("\\(C2008_A", "", rawcolumbia2$DegreeDiscipline)
rawcolumbia2$DegreeDiscipline <- gsub("\\First major", "", rawcolumbia2$DegreeDiscipline)
rawcolumbia2$DegreeDiscipline <- gsub("\\Second major", "", rawcolumbia2$DegreeDiscipline)

rawcolumbia2 <- rawcolumbia2 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawcolumbia3 <- t(read_csv("RawColumbia3.csv"))
rawcolumbia3 <- cbind(rownames(rawcolumbia3), rawcolumbia3)
rownames(rawcolumbia3) <- NULL
rawcolumbia3 <- data.frame(DegreeDiscipline = rawcolumbia3)
colnames(rawcolumbia3) <- c("DegreeDiscipline","Total")
rawcolumbia3$DegreeDiscipline <- gsub("\\(C2007_A", "", rawcolumbia3$DegreeDiscipline)
rawcolumbia3$DegreeDiscipline <- gsub("\\First major", "", rawcolumbia3$DegreeDiscipline)
rawcolumbia3$DegreeDiscipline <- gsub("\\Second major", "", rawcolumbia3$DegreeDiscipline)

rawcolumbia3 <- rawcolumbia3 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawcolumbia4 <- t(read_csv("RawColumbia4.csv"))
rawcolumbia4 <- cbind(rownames(rawcolumbia4), rawcolumbia4)
rownames(rawcolumbia4) <- NULL
rawcolumbia4 <- data.frame(DegreeDiscipline = rawcolumbia4)
colnames(rawcolumbia4) <- c("DegreeDiscipline","Total")
rawcolumbia4$DegreeDiscipline <- gsub("\\(C2006_A", "", rawcolumbia4$DegreeDiscipline)
rawcolumbia4$DegreeDiscipline <- gsub("\\First major", "", rawcolumbia4$DegreeDiscipline)
rawcolumbia4$DegreeDiscipline <- gsub("\\Second major", "", rawcolumbia4$DegreeDiscipline)

rawcolumbia4 <- rawcolumbia4 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawcolumbia5 <- t(read_csv("RawColumbia5.csv"))
rawcolumbia5 <- cbind(rownames(rawcolumbia5), rawcolumbia5)
rownames(rawcolumbia5) <- NULL
rawcolumbia5 <- data.frame(DegreeDiscipline = rawcolumbia5)
colnames(rawcolumbia5) <- c("DegreeDiscipline","Total")
rawcolumbia5$DegreeDiscipline <- gsub("\\(C2005_A", "", rawcolumbia5$DegreeDiscipline)
rawcolumbia5$DegreeDiscipline <- gsub("\\First major", "", rawcolumbia5$DegreeDiscipline)
rawcolumbia5$DegreeDiscipline <- gsub("\\Second major", "", rawcolumbia5$DegreeDiscipline)

rawcolumbia5 <- rawcolumbia5 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawcolumbia6 <- t(read_csv("RawColumbia6.csv"))
rawcolumbia6 <- cbind(rownames(rawcolumbia6), rawcolumbia6)
rownames(rawcolumbia6) <- NULL
rawcolumbia6 <- data.frame(DegreeDiscipline = rawcolumbia6)
colnames(rawcolumbia6) <- c("DegreeDiscipline","Total")
rawcolumbia6$DegreeDiscipline <- gsub("\\(C2004_A", "", rawcolumbia6$DegreeDiscipline)
rawcolumbia6$DegreeDiscipline <- gsub("\\First major", "", rawcolumbia6$DegreeDiscipline)
rawcolumbia6$DegreeDiscipline <- gsub("\\Second major", "", rawcolumbia6$DegreeDiscipline)

rawcolumbia6 <- rawcolumbia6 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawcolumbia7 <- t(read_csv("RawColumbia7.csv"))
rawcolumbia7 <- cbind(rownames(rawcolumbia7), rawcolumbia7)
rownames(rawcolumbia7) <- NULL
rawcolumbia7 <- data.frame(DegreeDiscipline = rawcolumbia7)
colnames(rawcolumbia7) <- c("DegreeDiscipline","Total")
rawcolumbia7$DegreeDiscipline <- gsub("\\(C2003_A", "", rawcolumbia7$DegreeDiscipline)
rawcolumbia7$DegreeDiscipline <- gsub("\\First major", "", rawcolumbia7$DegreeDiscipline)
rawcolumbia7$DegreeDiscipline <- gsub("\\Second major", "", rawcolumbia7$DegreeDiscipline)

rawcolumbia7 <- rawcolumbia7 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawcolumbia <- left_join(rawcolumbia1, rawcolumbia2, by = "DegreeDiscipline") %>%
  left_join(rawcolumbia3, by = "DegreeDiscipline") %>%
  left_join(rawcolumbia4, by = "DegreeDiscipline") %>%
  left_join(rawcolumbia5, by = "DegreeDiscipline") %>%
  left_join(rawcolumbia6, by = "DegreeDiscipline") %>%
  left_join(rawcolumbia7, by = "DegreeDiscipline")

colnames(rawcolumbia) <- c("DegreeDiscipline", "Yr1", "Yr2", "Yr3", "Yr4", "Yr5", "Yr6", "Yr7")
rawcolumbia <- rawcolumbia %>%
  mutate(across(Yr1:Yr7, ~ parse_number(as.character(.x)))) %>%
  rowwise() %>%
  mutate(Total = sum(c_across(Yr1:Yr7), na.rm = TRUE)) %>%
  ungroup()
rawcolumbia <- rawcolumbia[-109,]

rm(rawcolumbia1)
rm(rawcolumbia2)
rm(rawcolumbia3)
rm(rawcolumbia4)
rm(rawcolumbia5)
rm(rawcolumbia6)
rm(rawcolumbia7)

rawcornell1 <- t(read_csv("RawCornell1.csv"))
rawcornell1 <- cbind(rownames(rawcornell1), rawcornell1)
rownames(rawcornell1) <- NULL
rawcornell1 <- data.frame(DegreeDiscipline = rawcornell1)
colnames(rawcornell1) <- c("DegreeDiscipline","Total")
rawcornell1$DegreeDiscipline <- gsub("\\(C2009_A", "", rawcornell1$DegreeDiscipline)
rawcornell1$DegreeDiscipline <- gsub("\\First major", "", rawcornell1$DegreeDiscipline)
rawcornell1$DegreeDiscipline <- gsub("\\Second major", "", rawcornell1$DegreeDiscipline)

rawcornell1 <- rawcornell1 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawcornell2 <- t(read_csv("RawCornell2.csv"))
rawcornell2 <- cbind(rownames(rawcornell2), rawcornell2)
rownames(rawcornell2) <- NULL
rawcornell2 <- data.frame(DegreeDiscipline = rawcornell2)
colnames(rawcornell2) <- c("DegreeDiscipline","Total")
rawcornell2$DegreeDiscipline <- gsub("\\(C2008_A", "", rawcornell2$DegreeDiscipline)
rawcornell2$DegreeDiscipline <- gsub("\\First major", "", rawcornell2$DegreeDiscipline)
rawcornell2$DegreeDiscipline <- gsub("\\Second major", "", rawcornell2$DegreeDiscipline)

rawcornell2 <- rawcornell2 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawcornell3 <- t(read_csv("RawCornell3.csv"))
rawcornell3 <- cbind(rownames(rawcornell3), rawcornell3)
rownames(rawcornell3) <- NULL
rawcornell3 <- data.frame(DegreeDiscipline = rawcornell3)
colnames(rawcornell3) <- c("DegreeDiscipline","Total")
rawcornell3$DegreeDiscipline <- gsub("\\(C2007_A", "", rawcornell3$DegreeDiscipline)
rawcornell3$DegreeDiscipline <- gsub("\\First major", "", rawcornell3$DegreeDiscipline)
rawcornell3$DegreeDiscipline <- gsub("\\Second major", "", rawcornell3$DegreeDiscipline)

rawcornell3 <- rawcornell3 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawcornell4 <- t(read_csv("RawCornell4.csv"))
rawcornell4 <- cbind(rownames(rawcornell4), rawcornell4)
rownames(rawcornell4) <- NULL
rawcornell4 <- data.frame(DegreeDiscipline = rawcornell4)
colnames(rawcornell4) <- c("DegreeDiscipline","Total")
rawcornell4$DegreeDiscipline <- gsub("\\(C2006_A", "", rawcornell4$DegreeDiscipline)
rawcornell4$DegreeDiscipline <- gsub("\\First major", "", rawcornell4$DegreeDiscipline)
rawcornell4$DegreeDiscipline <- gsub("\\Second major", "", rawcornell4$DegreeDiscipline)

rawcornell4 <- rawcornell4 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawcornell5 <- t(read_csv("RawCornell5.csv"))
rawcornell5 <- cbind(rownames(rawcornell5), rawcornell5)
rownames(rawcornell5) <- NULL
rawcornell5 <- data.frame(DegreeDiscipline = rawcornell5)
colnames(rawcornell5) <- c("DegreeDiscipline","Total")
rawcornell5$DegreeDiscipline <- gsub("\\(C2005_A", "", rawcornell5$DegreeDiscipline)
rawcornell5$DegreeDiscipline <- gsub("\\First major", "", rawcornell5$DegreeDiscipline)
rawcornell5$DegreeDiscipline <- gsub("\\Second major", "", rawcornell5$DegreeDiscipline)

rawcornell5 <- rawcornell5 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawcornell6 <- t(read_csv("RawCornell6.csv"))
rawcornell6 <- cbind(rownames(rawcornell6), rawcornell6)
rownames(rawcornell6) <- NULL
rawcornell6 <- data.frame(DegreeDiscipline = rawcornell6)
colnames(rawcornell6) <- c("DegreeDiscipline","Total")
rawcornell6$DegreeDiscipline <- gsub("\\(C2004_A", "", rawcornell6$DegreeDiscipline)
rawcornell6$DegreeDiscipline <- gsub("\\First major", "", rawcornell6$DegreeDiscipline)
rawcornell6$DegreeDiscipline <- gsub("\\Second major", "", rawcornell6$DegreeDiscipline)

rawcornell6 <- rawcornell6 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawcornell7 <- t(read_csv("RawCornell7.csv"))
rawcornell7 <- cbind(rownames(rawcornell7), rawcornell7)
rownames(rawcornell7) <- NULL
rawcornell7 <- data.frame(DegreeDiscipline = rawcornell7)
colnames(rawcornell7) <- c("DegreeDiscipline","Total")
rawcornell7$DegreeDiscipline <- gsub("\\(C2003_A", "", rawcornell7$DegreeDiscipline)
rawcornell7$DegreeDiscipline <- gsub("\\First major", "", rawcornell7$DegreeDiscipline)
rawcornell7$DegreeDiscipline <- gsub("\\Second major", "", rawcornell7$DegreeDiscipline)

rawcornell7 <- rawcornell7 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawcornell <- left_join(rawcornell1, rawcornell2, by = "DegreeDiscipline") %>%
  left_join(rawcornell3, by = "DegreeDiscipline") %>%
  left_join(rawcornell4, by = "DegreeDiscipline") %>%
  left_join(rawcornell5, by = "DegreeDiscipline") %>%
  left_join(rawcornell6, by = "DegreeDiscipline") %>%
  left_join(rawcornell7, by = "DegreeDiscipline")

colnames(rawcornell) <- c("DegreeDiscipline", "Yr1", "Yr2", "Yr3", "Yr4", "Yr5", "Yr6", "Yr7")
rawcornell <- rawcornell %>%
  mutate(across(Yr1:Yr7, ~ parse_number(as.character(.x)))) %>%
  rowwise() %>%
  mutate(Total = sum(c_across(Yr1:Yr7), na.rm = TRUE)) %>%
  ungroup()
rawcornell <- rawcornell[-109,]

rm(rawcornell1)
rm(rawcornell2)
rm(rawcornell3)
rm(rawcornell4)
rm(rawcornell5)
rm(rawcornell6)
rm(rawcornell7)

rawdartmouth1 <- t(read_csv("RawDartmouth1.csv"))
rawdartmouth1 <- cbind(rownames(rawdartmouth1), rawdartmouth1)
rownames(rawdartmouth1) <- NULL
rawdartmouth1 <- data.frame(DegreeDiscipline = rawdartmouth1)
colnames(rawdartmouth1) <- c("DegreeDiscipline","Total")
rawdartmouth1$DegreeDiscipline <- gsub("\\(C2009_A", "", rawdartmouth1$DegreeDiscipline)
rawdartmouth1$DegreeDiscipline <- gsub("\\First major", "", rawdartmouth1$DegreeDiscipline)
rawdartmouth1$DegreeDiscipline <- gsub("\\Second major", "", rawdartmouth1$DegreeDiscipline)

rawdartmouth1 <- rawdartmouth1 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawdartmouth2 <- t(read_csv("RawDartmouth2.csv"))
rawdartmouth2 <- cbind(rownames(rawdartmouth2), rawdartmouth2)
rownames(rawdartmouth2) <- NULL
rawdartmouth2 <- data.frame(DegreeDiscipline = rawdartmouth2)
colnames(rawdartmouth2) <- c("DegreeDiscipline","Total")
rawdartmouth2$DegreeDiscipline <- gsub("\\(C2008_A", "", rawdartmouth2$DegreeDiscipline)
rawdartmouth2$DegreeDiscipline <- gsub("\\First major", "", rawdartmouth2$DegreeDiscipline)
rawdartmouth2$DegreeDiscipline <- gsub("\\Second major", "", rawdartmouth2$DegreeDiscipline)

rawdartmouth2 <- rawdartmouth2 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawdartmouth3 <- t(read_csv("RawDartmouth3.csv"))
rawdartmouth3 <- cbind(rownames(rawdartmouth3), rawdartmouth3)
rownames(rawdartmouth3) <- NULL
rawdartmouth3 <- data.frame(DegreeDiscipline = rawdartmouth3)
colnames(rawdartmouth3) <- c("DegreeDiscipline","Total")
rawdartmouth3$DegreeDiscipline <- gsub("\\(C2007_A", "", rawdartmouth3$DegreeDiscipline)
rawdartmouth3$DegreeDiscipline <- gsub("\\First major", "", rawdartmouth3$DegreeDiscipline)
rawdartmouth3$DegreeDiscipline <- gsub("\\Second major", "", rawdartmouth3$DegreeDiscipline)

rawdartmouth3 <- rawdartmouth3 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawdartmouth4 <- t(read_csv("RawDartmouth4.csv"))
rawdartmouth4 <- cbind(rownames(rawdartmouth4), rawdartmouth4)
rownames(rawdartmouth4) <- NULL
rawdartmouth4 <- data.frame(DegreeDiscipline = rawdartmouth4)
colnames(rawdartmouth4) <- c("DegreeDiscipline","Total")
rawdartmouth4$DegreeDiscipline <- gsub("\\(C2006_A", "", rawdartmouth4$DegreeDiscipline)
rawdartmouth4$DegreeDiscipline <- gsub("\\First major", "", rawdartmouth4$DegreeDiscipline)
rawdartmouth4$DegreeDiscipline <- gsub("\\Second major", "", rawdartmouth4$DegreeDiscipline)

rawdartmouth4 <- rawdartmouth4 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawdartmouth5 <- t(read_csv("RawDartmouth5.csv"))
rawdartmouth5 <- cbind(rownames(rawdartmouth5), rawdartmouth5)
rownames(rawdartmouth5) <- NULL
rawdartmouth5 <- data.frame(DegreeDiscipline = rawdartmouth5)
colnames(rawdartmouth5) <- c("DegreeDiscipline","Total")
rawdartmouth5$DegreeDiscipline <- gsub("\\(C2005_A", "", rawdartmouth5$DegreeDiscipline)
rawdartmouth5$DegreeDiscipline <- gsub("\\First major", "", rawdartmouth5$DegreeDiscipline)
rawdartmouth5$DegreeDiscipline <- gsub("\\Second major", "", rawdartmouth5$DegreeDiscipline)

rawdartmouth5 <- rawdartmouth5 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawdartmouth6 <- t(read_csv("RawDartmouth6.csv"))
rawdartmouth6 <- cbind(rownames(rawdartmouth6), rawdartmouth6)
rownames(rawdartmouth6) <- NULL
rawdartmouth6 <- data.frame(DegreeDiscipline = rawdartmouth6)
colnames(rawdartmouth6) <- c("DegreeDiscipline","Total")
rawdartmouth6$DegreeDiscipline <- gsub("\\(C2004_A", "", rawdartmouth6$DegreeDiscipline)
rawdartmouth6$DegreeDiscipline <- gsub("\\First major", "", rawdartmouth6$DegreeDiscipline)
rawdartmouth6$DegreeDiscipline <- gsub("\\Second major", "", rawdartmouth6$DegreeDiscipline)

rawdartmouth6 <- rawdartmouth6 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawdartmouth7 <- t(read_csv("RawDartmouth7.csv"))
rawdartmouth7 <- cbind(rownames(rawdartmouth7), rawdartmouth7)
rownames(rawdartmouth7) <- NULL
rawdartmouth7 <- data.frame(DegreeDiscipline = rawdartmouth7)
colnames(rawdartmouth7) <- c("DegreeDiscipline","Total")
rawdartmouth7$DegreeDiscipline <- gsub("\\(C2003_A", "", rawdartmouth7$DegreeDiscipline)
rawdartmouth7$DegreeDiscipline <- gsub("\\First major", "", rawdartmouth7$DegreeDiscipline)
rawdartmouth7$DegreeDiscipline <- gsub("\\Second major", "", rawdartmouth7$DegreeDiscipline)

rawdartmouth7 <- rawdartmouth7 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawdartmouth <- left_join(rawdartmouth1, rawdartmouth2, by = "DegreeDiscipline") %>%
  left_join(rawdartmouth3, by = "DegreeDiscipline") %>%
  left_join(rawdartmouth4, by = "DegreeDiscipline") %>%
  left_join(rawdartmouth5, by = "DegreeDiscipline") %>%
  left_join(rawdartmouth6, by = "DegreeDiscipline") %>%
  left_join(rawdartmouth7, by = "DegreeDiscipline")

colnames(rawdartmouth) <- c("DegreeDiscipline", "Yr1", "Yr2", "Yr3", "Yr4", "Yr5", "Yr6", "Yr7")
rawdartmouth <- rawdartmouth %>%
  mutate(across(Yr1:Yr7, ~ parse_number(as.character(.x)))) %>%
  rowwise() %>%
  mutate(Total = sum(c_across(Yr1:Yr7), na.rm = TRUE)) %>%
  ungroup()
rawdartmouth <- rawdartmouth[-109,]

rm(rawdartmouth1)
rm(rawdartmouth2)
rm(rawdartmouth3)
rm(rawdartmouth4)
rm(rawdartmouth5)
rm(rawdartmouth6)
rm(rawdartmouth7)

rawduke1 <- t(read_csv("RawDuke1.csv"))
rawduke1 <- cbind(rownames(rawduke1), rawduke1)
rownames(rawduke1) <- NULL
rawduke1 <- data.frame(DegreeDiscipline = rawduke1)
colnames(rawduke1) <- c("DegreeDiscipline","Total")
rawduke1$DegreeDiscipline <- gsub("\\(C2009_A", "", rawduke1$DegreeDiscipline)
rawduke1$DegreeDiscipline <- gsub("\\First major", "", rawduke1$DegreeDiscipline)
rawduke1$DegreeDiscipline <- gsub("\\Second major", "", rawduke1$DegreeDiscipline)

rawduke1 <- rawduke1 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawduke2 <- t(read_csv("RawDuke2.csv"))
rawduke2 <- cbind(rownames(rawduke2), rawduke2)
rownames(rawduke2) <- NULL
rawduke2 <- data.frame(DegreeDiscipline = rawduke2)
colnames(rawduke2) <- c("DegreeDiscipline","Total")
rawduke2$DegreeDiscipline <- gsub("\\(C2008_A", "", rawduke2$DegreeDiscipline)
rawduke2$DegreeDiscipline <- gsub("\\First major", "", rawduke2$DegreeDiscipline)
rawduke2$DegreeDiscipline <- gsub("\\Second major", "", rawduke2$DegreeDiscipline)

rawduke2 <- rawduke2 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawduke3 <- t(read_csv("RawDuke3.csv"))
rawduke3 <- cbind(rownames(rawduke3), rawduke3)
rownames(rawduke3) <- NULL
rawduke3 <- data.frame(DegreeDiscipline = rawduke3)
colnames(rawduke3) <- c("DegreeDiscipline","Total")
rawduke3$DegreeDiscipline <- gsub("\\(C2007_A", "", rawduke3$DegreeDiscipline)
rawduke3$DegreeDiscipline <- gsub("\\First major", "", rawduke3$DegreeDiscipline)
rawduke3$DegreeDiscipline <- gsub("\\Second major", "", rawduke3$DegreeDiscipline)

rawduke3 <- rawduke3 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawduke4 <- t(read_csv("RawDuke4.csv"))
rawduke4 <- cbind(rownames(rawduke4), rawduke4)
rownames(rawduke4) <- NULL
rawduke4 <- data.frame(DegreeDiscipline = rawduke4)
colnames(rawduke4) <- c("DegreeDiscipline","Total")
rawduke4$DegreeDiscipline <- gsub("\\(C2006_A", "", rawduke4$DegreeDiscipline)
rawduke4$DegreeDiscipline <- gsub("\\First major", "", rawduke4$DegreeDiscipline)
rawduke4$DegreeDiscipline <- gsub("\\Second major", "", rawduke4$DegreeDiscipline)

rawduke4 <- rawduke4 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawduke5 <- t(read_csv("RawDuke5.csv"))
rawduke5 <- cbind(rownames(rawduke5), rawduke5)
rownames(rawduke5) <- NULL
rawduke5 <- data.frame(DegreeDiscipline = rawduke5)
colnames(rawduke5) <- c("DegreeDiscipline","Total")
rawduke5$DegreeDiscipline <- gsub("\\(C2005_A", "", rawduke5$DegreeDiscipline)
rawduke5$DegreeDiscipline <- gsub("\\First major", "", rawduke5$DegreeDiscipline)
rawduke5$DegreeDiscipline <- gsub("\\Second major", "", rawduke5$DegreeDiscipline)

rawduke5 <- rawduke5 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawduke6 <- t(read_csv("RawDuke6.csv"))
rawduke6 <- cbind(rownames(rawduke6), rawduke6)
rownames(rawduke6) <- NULL
rawduke6 <- data.frame(DegreeDiscipline = rawduke6)
colnames(rawduke6) <- c("DegreeDiscipline","Total")
rawduke6$DegreeDiscipline <- gsub("\\(C2004_A", "", rawduke6$DegreeDiscipline)
rawduke6$DegreeDiscipline <- gsub("\\First major", "", rawduke6$DegreeDiscipline)
rawduke6$DegreeDiscipline <- gsub("\\Second major", "", rawduke6$DegreeDiscipline)

rawduke6 <- rawduke6 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawduke7 <- t(read_csv("RawDuke7.csv"))
rawduke7 <- cbind(rownames(rawduke7), rawduke7)
rownames(rawduke7) <- NULL
rawduke7 <- data.frame(DegreeDiscipline = rawduke7)
colnames(rawduke7) <- c("DegreeDiscipline","Total")
rawduke7$DegreeDiscipline <- gsub("\\(C2003_A", "", rawduke7$DegreeDiscipline)
rawduke7$DegreeDiscipline <- gsub("\\First major", "", rawduke7$DegreeDiscipline)
rawduke7$DegreeDiscipline <- gsub("\\Second major", "", rawduke7$DegreeDiscipline)

rawduke7 <- rawduke7 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawduke <- left_join(rawduke1, rawduke2, by = "DegreeDiscipline") %>%
  left_join(rawduke3, by = "DegreeDiscipline") %>%
  left_join(rawduke4, by = "DegreeDiscipline") %>%
  left_join(rawduke5, by = "DegreeDiscipline") %>%
  left_join(rawduke6, by = "DegreeDiscipline") %>%
  left_join(rawduke7, by = "DegreeDiscipline")

colnames(rawduke) <- c("DegreeDiscipline", "Yr1", "Yr2", "Yr3", "Yr4", "Yr5", "Yr6", "Yr7")
rawduke <- rawduke %>%
  mutate(across(Yr1:Yr7, ~ parse_number(as.character(.x)))) %>%
  rowwise() %>%
  mutate(Total = sum(c_across(Yr1:Yr7), na.rm = TRUE)) %>%
  ungroup()
rawduke <- rawduke[-109,]

rm(rawduke1)
rm(rawduke2)
rm(rawduke3)
rm(rawduke4)
rm(rawduke5)
rm(rawduke6)
rm(rawduke7)

rawjohnshopkins1 <- t(read_csv("RawJohnshopkins1.csv"))
rawjohnshopkins1 <- cbind(rownames(rawjohnshopkins1), rawjohnshopkins1)
rownames(rawjohnshopkins1) <- NULL
rawjohnshopkins1 <- data.frame(DegreeDiscipline = rawjohnshopkins1)
colnames(rawjohnshopkins1) <- c("DegreeDiscipline","Total")
rawjohnshopkins1$DegreeDiscipline <- gsub("\\(C2009_A", "", rawjohnshopkins1$DegreeDiscipline)
rawjohnshopkins1$DegreeDiscipline <- gsub("\\First major", "", rawjohnshopkins1$DegreeDiscipline)
rawjohnshopkins1$DegreeDiscipline <- gsub("\\Second major", "", rawjohnshopkins1$DegreeDiscipline)

rawjohnshopkins1 <- rawjohnshopkins1 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawjohnshopkins2 <- t(read_csv("RawJohnshopkins2.csv"))
rawjohnshopkins2 <- cbind(rownames(rawjohnshopkins2), rawjohnshopkins2)
rownames(rawjohnshopkins2) <- NULL
rawjohnshopkins2 <- data.frame(DegreeDiscipline = rawjohnshopkins2)
colnames(rawjohnshopkins2) <- c("DegreeDiscipline","Total")
rawjohnshopkins2$DegreeDiscipline <- gsub("\\(C2008_A", "", rawjohnshopkins2$DegreeDiscipline)
rawjohnshopkins2$DegreeDiscipline <- gsub("\\First major", "", rawjohnshopkins2$DegreeDiscipline)
rawjohnshopkins2$DegreeDiscipline <- gsub("\\Second major", "", rawjohnshopkins2$DegreeDiscipline)

rawjohnshopkins2 <- rawjohnshopkins2 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawjohnshopkins3 <- t(read_csv("RawJohnshopkins3.csv"))
rawjohnshopkins3 <- cbind(rownames(rawjohnshopkins3), rawjohnshopkins3)
rownames(rawjohnshopkins3) <- NULL
rawjohnshopkins3 <- data.frame(DegreeDiscipline = rawjohnshopkins3)
colnames(rawjohnshopkins3) <- c("DegreeDiscipline","Total")
rawjohnshopkins3$DegreeDiscipline <- gsub("\\(C2007_A", "", rawjohnshopkins3$DegreeDiscipline)
rawjohnshopkins3$DegreeDiscipline <- gsub("\\First major", "", rawjohnshopkins3$DegreeDiscipline)
rawjohnshopkins3$DegreeDiscipline <- gsub("\\Second major", "", rawjohnshopkins3$DegreeDiscipline)

rawjohnshopkins3 <- rawjohnshopkins3 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawjohnshopkins4 <- t(read_csv("RawJohnshopkins4.csv"))
rawjohnshopkins4 <- cbind(rownames(rawjohnshopkins4), rawjohnshopkins4)
rownames(rawjohnshopkins4) <- NULL
rawjohnshopkins4 <- data.frame(DegreeDiscipline = rawjohnshopkins4)
colnames(rawjohnshopkins4) <- c("DegreeDiscipline","Total")
rawjohnshopkins4$DegreeDiscipline <- gsub("\\(C2006_A", "", rawjohnshopkins4$DegreeDiscipline)
rawjohnshopkins4$DegreeDiscipline <- gsub("\\First major", "", rawjohnshopkins4$DegreeDiscipline)
rawjohnshopkins4$DegreeDiscipline <- gsub("\\Second major", "", rawjohnshopkins4$DegreeDiscipline)

rawjohnshopkins4 <- rawjohnshopkins4 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawjohnshopkins5 <- t(read_csv("RawJohnshopkins5.csv"))
rawjohnshopkins5 <- cbind(rownames(rawjohnshopkins5), rawjohnshopkins5)
rownames(rawjohnshopkins5) <- NULL
rawjohnshopkins5 <- data.frame(DegreeDiscipline = rawjohnshopkins5)
colnames(rawjohnshopkins5) <- c("DegreeDiscipline","Total")
rawjohnshopkins5$DegreeDiscipline <- gsub("\\(C2005_A", "", rawjohnshopkins5$DegreeDiscipline)
rawjohnshopkins5$DegreeDiscipline <- gsub("\\First major", "", rawjohnshopkins5$DegreeDiscipline)
rawjohnshopkins5$DegreeDiscipline <- gsub("\\Second major", "", rawjohnshopkins5$DegreeDiscipline)

rawjohnshopkins5 <- rawjohnshopkins5 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawjohnshopkins6 <- t(read_csv("RawJohnshopkins6.csv"))
rawjohnshopkins6 <- cbind(rownames(rawjohnshopkins6), rawjohnshopkins6)
rownames(rawjohnshopkins6) <- NULL
rawjohnshopkins6 <- data.frame(DegreeDiscipline = rawjohnshopkins6)
colnames(rawjohnshopkins6) <- c("DegreeDiscipline","Total")
rawjohnshopkins6$DegreeDiscipline <- gsub("\\(C2004_A", "", rawjohnshopkins6$DegreeDiscipline)
rawjohnshopkins6$DegreeDiscipline <- gsub("\\First major", "", rawjohnshopkins6$DegreeDiscipline)
rawjohnshopkins6$DegreeDiscipline <- gsub("\\Second major", "", rawjohnshopkins6$DegreeDiscipline)

rawjohnshopkins6 <- rawjohnshopkins6 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawjohnshopkins7 <- t(read_csv("RawJohnshopkins7.csv"))
rawjohnshopkins7 <- cbind(rownames(rawjohnshopkins7), rawjohnshopkins7)
rownames(rawjohnshopkins7) <- NULL
rawjohnshopkins7 <- data.frame(DegreeDiscipline = rawjohnshopkins7)
colnames(rawjohnshopkins7) <- c("DegreeDiscipline","Total")
rawjohnshopkins7$DegreeDiscipline <- gsub("\\(C2003_A", "", rawjohnshopkins7$DegreeDiscipline)
rawjohnshopkins7$DegreeDiscipline <- gsub("\\First major", "", rawjohnshopkins7$DegreeDiscipline)
rawjohnshopkins7$DegreeDiscipline <- gsub("\\Second major", "", rawjohnshopkins7$DegreeDiscipline)

rawjohnshopkins7 <- rawjohnshopkins7 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawjohnshopkins <- left_join(rawjohnshopkins1, rawjohnshopkins2, by = "DegreeDiscipline") %>%
  left_join(rawjohnshopkins3, by = "DegreeDiscipline") %>%
  left_join(rawjohnshopkins4, by = "DegreeDiscipline") %>%
  left_join(rawjohnshopkins5, by = "DegreeDiscipline") %>%
  left_join(rawjohnshopkins6, by = "DegreeDiscipline") %>%
  left_join(rawjohnshopkins7, by = "DegreeDiscipline")

colnames(rawjohnshopkins) <- c("DegreeDiscipline", "Yr1", "Yr2", "Yr3", "Yr4", "Yr5", "Yr6", "Yr7")
rawjohnshopkins <- rawjohnshopkins %>%
  mutate(across(Yr1:Yr7, ~ parse_number(as.character(.x)))) %>%
  rowwise() %>%
  mutate(Total = sum(c_across(Yr1:Yr7), na.rm = TRUE)) %>%
  ungroup()
rawjohnshopkins <- rawjohnshopkins[-109,]

rm(rawjohnshopkins1)
rm(rawjohnshopkins2)
rm(rawjohnshopkins3)
rm(rawjohnshopkins4)
rm(rawjohnshopkins5)
rm(rawjohnshopkins6)
rm(rawjohnshopkins7)

rawmit1 <- t(read_csv("RawMit1.csv"))
rawmit1 <- cbind(rownames(rawmit1), rawmit1)
rownames(rawmit1) <- NULL
rawmit1 <- data.frame(DegreeDiscipline = rawmit1)
colnames(rawmit1) <- c("DegreeDiscipline","Total")
rawmit1$DegreeDiscipline <- gsub("\\(C2009_A", "", rawmit1$DegreeDiscipline)
rawmit1$DegreeDiscipline <- gsub("\\First major", "", rawmit1$DegreeDiscipline)
rawmit1$DegreeDiscipline <- gsub("\\Second major", "", rawmit1$DegreeDiscipline)

rawmit1 <- rawmit1 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawmit2 <- t(read_csv("RawMit2.csv"))
rawmit2 <- cbind(rownames(rawmit2), rawmit2)
rownames(rawmit2) <- NULL
rawmit2 <- data.frame(DegreeDiscipline = rawmit2)
colnames(rawmit2) <- c("DegreeDiscipline","Total")
rawmit2$DegreeDiscipline <- gsub("\\(C2008_A", "", rawmit2$DegreeDiscipline)
rawmit2$DegreeDiscipline <- gsub("\\First major", "", rawmit2$DegreeDiscipline)
rawmit2$DegreeDiscipline <- gsub("\\Second major", "", rawmit2$DegreeDiscipline)

rawmit2 <- rawmit2 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawmit3 <- t(read_csv("RawMit3.csv"))
rawmit3 <- cbind(rownames(rawmit3), rawmit3)
rownames(rawmit3) <- NULL
rawmit3 <- data.frame(DegreeDiscipline = rawmit3)
colnames(rawmit3) <- c("DegreeDiscipline","Total")
rawmit3$DegreeDiscipline <- gsub("\\(C2007_A", "", rawmit3$DegreeDiscipline)
rawmit3$DegreeDiscipline <- gsub("\\First major", "", rawmit3$DegreeDiscipline)
rawmit3$DegreeDiscipline <- gsub("\\Second major", "", rawmit3$DegreeDiscipline)

rawmit3 <- rawmit3 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawmit4 <- t(read_csv("RawMit4.csv"))
rawmit4 <- cbind(rownames(rawmit4), rawmit4)
rownames(rawmit4) <- NULL
rawmit4 <- data.frame(DegreeDiscipline = rawmit4)
colnames(rawmit4) <- c("DegreeDiscipline","Total")
rawmit4$DegreeDiscipline <- gsub("\\(C2006_A", "", rawmit4$DegreeDiscipline)
rawmit4$DegreeDiscipline <- gsub("\\First major", "", rawmit4$DegreeDiscipline)
rawmit4$DegreeDiscipline <- gsub("\\Second major", "", rawmit4$DegreeDiscipline)

rawmit4 <- rawmit4 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawmit5 <- t(read_csv("RawMit5.csv"))
rawmit5 <- cbind(rownames(rawmit5), rawmit5)
rownames(rawmit5) <- NULL
rawmit5 <- data.frame(DegreeDiscipline = rawmit5)
colnames(rawmit5) <- c("DegreeDiscipline","Total")
rawmit5$DegreeDiscipline <- gsub("\\(C2005_A", "", rawmit5$DegreeDiscipline)
rawmit5$DegreeDiscipline <- gsub("\\First major", "", rawmit5$DegreeDiscipline)
rawmit5$DegreeDiscipline <- gsub("\\Second major", "", rawmit5$DegreeDiscipline)

rawmit5 <- rawmit5 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawmit6 <- t(read_csv("RawMit6.csv"))
rawmit6 <- cbind(rownames(rawmit6), rawmit6)
rownames(rawmit6) <- NULL
rawmit6 <- data.frame(DegreeDiscipline = rawmit6)
colnames(rawmit6) <- c("DegreeDiscipline","Total")
rawmit6$DegreeDiscipline <- gsub("\\(C2004_A", "", rawmit6$DegreeDiscipline)
rawmit6$DegreeDiscipline <- gsub("\\First major", "", rawmit6$DegreeDiscipline)
rawmit6$DegreeDiscipline <- gsub("\\Second major", "", rawmit6$DegreeDiscipline)

rawmit6 <- rawmit6 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawmit7 <- t(read_csv("RawMit7.csv"))
rawmit7 <- cbind(rownames(rawmit7), rawmit7)
rownames(rawmit7) <- NULL
rawmit7 <- data.frame(DegreeDiscipline = rawmit7)
colnames(rawmit7) <- c("DegreeDiscipline","Total")
rawmit7$DegreeDiscipline <- gsub("\\(C2003_A", "", rawmit7$DegreeDiscipline)
rawmit7$DegreeDiscipline <- gsub("\\First major", "", rawmit7$DegreeDiscipline)
rawmit7$DegreeDiscipline <- gsub("\\Second major", "", rawmit7$DegreeDiscipline)

rawmit7 <- rawmit7 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawmit <- left_join(rawmit1, rawmit2, by = "DegreeDiscipline") %>%
  left_join(rawmit3, by = "DegreeDiscipline") %>%
  left_join(rawmit4, by = "DegreeDiscipline") %>%
  left_join(rawmit5, by = "DegreeDiscipline") %>%
  left_join(rawmit6, by = "DegreeDiscipline") %>%
  left_join(rawmit7, by = "DegreeDiscipline")

colnames(rawmit) <- c("DegreeDiscipline", "Yr1", "Yr2", "Yr3", "Yr4", "Yr5", "Yr6", "Yr7")
rawmit <- rawmit %>%
  mutate(across(Yr1:Yr7, ~ parse_number(as.character(.x)))) %>%
  rowwise() %>%
  mutate(Total = sum(c_across(Yr1:Yr7), na.rm = TRUE)) %>%
  ungroup()
rawmit <- rawmit[-109,]

rm(rawmit1)
rm(rawmit2)
rm(rawmit3)
rm(rawmit4)
rm(rawmit5)
rm(rawmit6)
rm(rawmit7)

rawnorthwestern1 <- t(read_csv("RawNorthwestern1.csv"))
rawnorthwestern1 <- cbind(rownames(rawnorthwestern1), rawnorthwestern1)
rownames(rawnorthwestern1) <- NULL
rawnorthwestern1 <- data.frame(DegreeDiscipline = rawnorthwestern1)
colnames(rawnorthwestern1) <- c("DegreeDiscipline","Total")
rawnorthwestern1$DegreeDiscipline <- gsub("\\(C2009_A", "", rawnorthwestern1$DegreeDiscipline)
rawnorthwestern1$DegreeDiscipline <- gsub("\\First major", "", rawnorthwestern1$DegreeDiscipline)
rawnorthwestern1$DegreeDiscipline <- gsub("\\Second major", "", rawnorthwestern1$DegreeDiscipline)

rawnorthwestern1 <- rawnorthwestern1 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawnorthwestern2 <- t(read_csv("RawNorthwestern2.csv"))
rawnorthwestern2 <- cbind(rownames(rawnorthwestern2), rawnorthwestern2)
rownames(rawnorthwestern2) <- NULL
rawnorthwestern2 <- data.frame(DegreeDiscipline = rawnorthwestern2)
colnames(rawnorthwestern2) <- c("DegreeDiscipline","Total")
rawnorthwestern2$DegreeDiscipline <- gsub("\\(C2008_A", "", rawnorthwestern2$DegreeDiscipline)
rawnorthwestern2$DegreeDiscipline <- gsub("\\First major", "", rawnorthwestern2$DegreeDiscipline)
rawnorthwestern2$DegreeDiscipline <- gsub("\\Second major", "", rawnorthwestern2$DegreeDiscipline)

rawnorthwestern2 <- rawnorthwestern2 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawnorthwestern3 <- t(read_csv("RawNorthwestern3.csv"))
rawnorthwestern3 <- cbind(rownames(rawnorthwestern3), rawnorthwestern3)
rownames(rawnorthwestern3) <- NULL
rawnorthwestern3 <- data.frame(DegreeDiscipline = rawnorthwestern3)
colnames(rawnorthwestern3) <- c("DegreeDiscipline","Total")
rawnorthwestern3$DegreeDiscipline <- gsub("\\(C2007_A", "", rawnorthwestern3$DegreeDiscipline)
rawnorthwestern3$DegreeDiscipline <- gsub("\\First major", "", rawnorthwestern3$DegreeDiscipline)
rawnorthwestern3$DegreeDiscipline <- gsub("\\Second major", "", rawnorthwestern3$DegreeDiscipline)

rawnorthwestern3 <- rawnorthwestern3 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawnorthwestern4 <- t(read_csv("RawNorthwestern4.csv"))
rawnorthwestern4 <- cbind(rownames(rawnorthwestern4), rawnorthwestern4)
rownames(rawnorthwestern4) <- NULL
rawnorthwestern4 <- data.frame(DegreeDiscipline = rawnorthwestern4)
colnames(rawnorthwestern4) <- c("DegreeDiscipline","Total")
rawnorthwestern4$DegreeDiscipline <- gsub("\\(C2006_A", "", rawnorthwestern4$DegreeDiscipline)
rawnorthwestern4$DegreeDiscipline <- gsub("\\First major", "", rawnorthwestern4$DegreeDiscipline)
rawnorthwestern4$DegreeDiscipline <- gsub("\\Second major", "", rawnorthwestern4$DegreeDiscipline)

rawnorthwestern4 <- rawnorthwestern4 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawnorthwestern5 <- t(read_csv("RawNorthwestern5.csv"))
rawnorthwestern5 <- cbind(rownames(rawnorthwestern5), rawnorthwestern5)
rownames(rawnorthwestern5) <- NULL
rawnorthwestern5 <- data.frame(DegreeDiscipline = rawnorthwestern5)
colnames(rawnorthwestern5) <- c("DegreeDiscipline","Total")
rawnorthwestern5$DegreeDiscipline <- gsub("\\(C2005_A", "", rawnorthwestern5$DegreeDiscipline)
rawnorthwestern5$DegreeDiscipline <- gsub("\\First major", "", rawnorthwestern5$DegreeDiscipline)
rawnorthwestern5$DegreeDiscipline <- gsub("\\Second major", "", rawnorthwestern5$DegreeDiscipline)

rawnorthwestern5 <- rawnorthwestern5 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawnorthwestern6 <- t(read_csv("RawNorthwestern6.csv"))
rawnorthwestern6 <- cbind(rownames(rawnorthwestern6), rawnorthwestern6)
rownames(rawnorthwestern6) <- NULL
rawnorthwestern6 <- data.frame(DegreeDiscipline = rawnorthwestern6)
colnames(rawnorthwestern6) <- c("DegreeDiscipline","Total")
rawnorthwestern6$DegreeDiscipline <- gsub("\\(C2004_A", "", rawnorthwestern6$DegreeDiscipline)
rawnorthwestern6$DegreeDiscipline <- gsub("\\First major", "", rawnorthwestern6$DegreeDiscipline)
rawnorthwestern6$DegreeDiscipline <- gsub("\\Second major", "", rawnorthwestern6$DegreeDiscipline)

rawnorthwestern6 <- rawnorthwestern6 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawnorthwestern7 <- t(read_csv("RawNorthwestern7.csv"))
rawnorthwestern7 <- cbind(rownames(rawnorthwestern7), rawnorthwestern7)
rownames(rawnorthwestern7) <- NULL
rawnorthwestern7 <- data.frame(DegreeDiscipline = rawnorthwestern7)
colnames(rawnorthwestern7) <- c("DegreeDiscipline","Total")
rawnorthwestern7$DegreeDiscipline <- gsub("\\(C2003_A", "", rawnorthwestern7$DegreeDiscipline)
rawnorthwestern7$DegreeDiscipline <- gsub("\\First major", "", rawnorthwestern7$DegreeDiscipline)
rawnorthwestern7$DegreeDiscipline <- gsub("\\Second major", "", rawnorthwestern7$DegreeDiscipline)

rawnorthwestern7 <- rawnorthwestern7 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawnorthwestern <- left_join(rawnorthwestern1, rawnorthwestern2, by = "DegreeDiscipline") %>%
  left_join(rawnorthwestern3, by = "DegreeDiscipline") %>%
  left_join(rawnorthwestern4, by = "DegreeDiscipline") %>%
  left_join(rawnorthwestern5, by = "DegreeDiscipline") %>%
  left_join(rawnorthwestern6, by = "DegreeDiscipline") %>%
  left_join(rawnorthwestern7, by = "DegreeDiscipline")

colnames(rawnorthwestern) <- c("DegreeDiscipline", "Yr1", "Yr2", "Yr3", "Yr4", "Yr5", "Yr6", "Yr7")
rawnorthwestern <- rawnorthwestern %>%
  mutate(across(Yr1:Yr7, ~ parse_number(as.character(.x)))) %>%
  rowwise() %>%
  mutate(Total = sum(c_across(Yr1:Yr7), na.rm = TRUE)) %>%
  ungroup()
rawnorthwestern <- rawnorthwestern[-109,]

rm(rawnorthwestern1)
rm(rawnorthwestern2)
rm(rawnorthwestern3)
rm(rawnorthwestern4)
rm(rawnorthwestern5)
rm(rawnorthwestern6)
rm(rawnorthwestern7)

rawnyu1 <- t(read_csv("RawNyu1.csv"))
rawnyu1 <- cbind(rownames(rawnyu1), rawnyu1)
rownames(rawnyu1) <- NULL
rawnyu1 <- data.frame(DegreeDiscipline = rawnyu1)
colnames(rawnyu1) <- c("DegreeDiscipline","Total")
rawnyu1$DegreeDiscipline <- gsub("\\(C2009_A", "", rawnyu1$DegreeDiscipline)
rawnyu1$DegreeDiscipline <- gsub("\\First major", "", rawnyu1$DegreeDiscipline)
rawnyu1$DegreeDiscipline <- gsub("\\Second major", "", rawnyu1$DegreeDiscipline)

rawnyu1 <- rawnyu1 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawnyu2 <- t(read_csv("RawNyu2.csv"))
rawnyu2 <- cbind(rownames(rawnyu2), rawnyu2)
rownames(rawnyu2) <- NULL
rawnyu2 <- data.frame(DegreeDiscipline = rawnyu2)
colnames(rawnyu2) <- c("DegreeDiscipline","Total")
rawnyu2$DegreeDiscipline <- gsub("\\(C2008_A", "", rawnyu2$DegreeDiscipline)
rawnyu2$DegreeDiscipline <- gsub("\\First major", "", rawnyu2$DegreeDiscipline)
rawnyu2$DegreeDiscipline <- gsub("\\Second major", "", rawnyu2$DegreeDiscipline)

rawnyu2 <- rawnyu2 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawnyu3 <- t(read_csv("RawNyu3.csv"))
rawnyu3 <- cbind(rownames(rawnyu3), rawnyu3)
rownames(rawnyu3) <- NULL
rawnyu3 <- data.frame(DegreeDiscipline = rawnyu3)
colnames(rawnyu3) <- c("DegreeDiscipline","Total")
rawnyu3$DegreeDiscipline <- gsub("\\(C2007_A", "", rawnyu3$DegreeDiscipline)
rawnyu3$DegreeDiscipline <- gsub("\\First major", "", rawnyu3$DegreeDiscipline)
rawnyu3$DegreeDiscipline <- gsub("\\Second major", "", rawnyu3$DegreeDiscipline)

rawnyu3 <- rawnyu3 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawnyu4 <- t(read_csv("RawNyu4.csv"))
rawnyu4 <- cbind(rownames(rawnyu4), rawnyu4)
rownames(rawnyu4) <- NULL
rawnyu4 <- data.frame(DegreeDiscipline = rawnyu4)
colnames(rawnyu4) <- c("DegreeDiscipline","Total")
rawnyu4$DegreeDiscipline <- gsub("\\(C2006_A", "", rawnyu4$DegreeDiscipline)
rawnyu4$DegreeDiscipline <- gsub("\\First major", "", rawnyu4$DegreeDiscipline)
rawnyu4$DegreeDiscipline <- gsub("\\Second major", "", rawnyu4$DegreeDiscipline)

rawnyu4 <- rawnyu4 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawnyu5 <- t(read_csv("RawNyu5.csv"))
rawnyu5 <- cbind(rownames(rawnyu5), rawnyu5)
rownames(rawnyu5) <- NULL
rawnyu5 <- data.frame(DegreeDiscipline = rawnyu5)
colnames(rawnyu5) <- c("DegreeDiscipline","Total")
rawnyu5$DegreeDiscipline <- gsub("\\(C2005_A", "", rawnyu5$DegreeDiscipline)
rawnyu5$DegreeDiscipline <- gsub("\\First major", "", rawnyu5$DegreeDiscipline)
rawnyu5$DegreeDiscipline <- gsub("\\Second major", "", rawnyu5$DegreeDiscipline)

rawnyu5 <- rawnyu5 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawnyu6 <- t(read_csv("RawNyu6.csv"))
rawnyu6 <- cbind(rownames(rawnyu6), rawnyu6)
rownames(rawnyu6) <- NULL
rawnyu6 <- data.frame(DegreeDiscipline = rawnyu6)
colnames(rawnyu6) <- c("DegreeDiscipline","Total")
rawnyu6$DegreeDiscipline <- gsub("\\(C2004_A", "", rawnyu6$DegreeDiscipline)
rawnyu6$DegreeDiscipline <- gsub("\\First major", "", rawnyu6$DegreeDiscipline)
rawnyu6$DegreeDiscipline <- gsub("\\Second major", "", rawnyu6$DegreeDiscipline)

rawnyu6 <- rawnyu6 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawnyu7 <- t(read_csv("RawNyu7.csv"))
rawnyu7 <- cbind(rownames(rawnyu7), rawnyu7)
rownames(rawnyu7) <- NULL
rawnyu7 <- data.frame(DegreeDiscipline = rawnyu7)
colnames(rawnyu7) <- c("DegreeDiscipline","Total")
rawnyu7$DegreeDiscipline <- gsub("\\(C2003_A", "", rawnyu7$DegreeDiscipline)
rawnyu7$DegreeDiscipline <- gsub("\\First major", "", rawnyu7$DegreeDiscipline)
rawnyu7$DegreeDiscipline <- gsub("\\Second major", "", rawnyu7$DegreeDiscipline)

rawnyu7 <- rawnyu7 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawnyu <- left_join(rawnyu1, rawnyu2, by = "DegreeDiscipline") %>%
  left_join(rawnyu3, by = "DegreeDiscipline") %>%
  left_join(rawnyu4, by = "DegreeDiscipline") %>%
  left_join(rawnyu5, by = "DegreeDiscipline") %>%
  left_join(rawnyu6, by = "DegreeDiscipline") %>%
  left_join(rawnyu7, by = "DegreeDiscipline")

colnames(rawnyu) <- c("DegreeDiscipline", "Yr1", "Yr2", "Yr3", "Yr4", "Yr5", "Yr6", "Yr7")
rawnyu <- rawnyu %>%
  mutate(across(Yr1:Yr7, ~ parse_number(as.character(.x)))) %>%
  rowwise() %>%
  mutate(Total = sum(c_across(Yr1:Yr7), na.rm = TRUE)) %>%
  ungroup()
rawnyu <- rawnyu[-109,]

rm(rawnyu1)
rm(rawnyu2)
rm(rawnyu3)
rm(rawnyu4)
rm(rawnyu5)
rm(rawnyu6)
rm(rawnyu7)

rawPrinceton1 <- t(read_csv("RawPrinceton1.csv"))
rawPrinceton1 <- cbind(rownames(rawPrinceton1), rawPrinceton1)
rownames(rawPrinceton1) <- NULL
rawPrinceton1 <- data.frame(DegreeDiscipline = rawPrinceton1)
colnames(rawPrinceton1) <- c("DegreeDiscipline","Total")
rawPrinceton1$DegreeDiscipline <- gsub("\\(C2009_A", "", rawPrinceton1$DegreeDiscipline)
rawPrinceton1$DegreeDiscipline <- gsub("\\First major", "", rawPrinceton1$DegreeDiscipline)
rawPrinceton1$DegreeDiscipline <- gsub("\\Second major", "", rawPrinceton1$DegreeDiscipline)

rawPrinceton1 <- rawPrinceton1 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawPrinceton2 <- t(read_csv("RawPrinceton2.csv"))
rawPrinceton2 <- cbind(rownames(rawPrinceton2), rawPrinceton2)
rownames(rawPrinceton2) <- NULL
rawPrinceton2 <- data.frame(DegreeDiscipline = rawPrinceton2)
colnames(rawPrinceton2) <- c("DegreeDiscipline","Total")
rawPrinceton2$DegreeDiscipline <- gsub("\\(C2008_A", "", rawPrinceton2$DegreeDiscipline)
rawPrinceton2$DegreeDiscipline <- gsub("\\First major", "", rawPrinceton2$DegreeDiscipline)
rawPrinceton2$DegreeDiscipline <- gsub("\\Second major", "", rawPrinceton2$DegreeDiscipline)

rawPrinceton2 <- rawPrinceton2 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))


rawPrinceton3 <- t(read_csv("RawPrinceton3.csv"))
rawPrinceton3 <- cbind(rownames(rawPrinceton3), rawPrinceton3)
rownames(rawPrinceton3) <- NULL
rawPrinceton3 <- data.frame(DegreeDiscipline = rawPrinceton3)
colnames(rawPrinceton3) <- c("DegreeDiscipline","Total")
rawPrinceton3$DegreeDiscipline <- gsub("\\(C2007_A", "", rawPrinceton3$DegreeDiscipline)
rawPrinceton3$DegreeDiscipline <- gsub("\\First major", "", rawPrinceton3$DegreeDiscipline)
rawPrinceton3$DegreeDiscipline <- gsub("\\Second major", "", rawPrinceton3$DegreeDiscipline)

rawPrinceton3 <- rawPrinceton3 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))


rawPrinceton4 <- t(read_csv("RawPrinceton4.csv"))
rawPrinceton4 <- cbind(rownames(rawPrinceton4), rawPrinceton4)
rownames(rawPrinceton4) <- NULL
rawPrinceton4 <- data.frame(DegreeDiscipline = rawPrinceton4)
colnames(rawPrinceton4) <- c("DegreeDiscipline","Total")
rawPrinceton4$DegreeDiscipline <- gsub("\\(C2006_A", "", rawPrinceton4$DegreeDiscipline)
rawPrinceton4$DegreeDiscipline <- gsub("\\First major", "", rawPrinceton4$DegreeDiscipline)
rawPrinceton4$DegreeDiscipline <- gsub("\\Second major", "", rawPrinceton4$DegreeDiscipline)

rawPrinceton4 <- rawPrinceton4 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawPrinceton5 <- t(read_csv("RawPrinceton5.csv"))
rawPrinceton5 <- cbind(rownames(rawPrinceton5), rawPrinceton5)
rownames(rawPrinceton5) <- NULL
rawPrinceton5 <- data.frame(DegreeDiscipline = rawPrinceton5)
colnames(rawPrinceton5) <- c("DegreeDiscipline","Total")
rawPrinceton5$DegreeDiscipline <- gsub("\\(C2005_A", "", rawPrinceton5$DegreeDiscipline)
rawPrinceton5$DegreeDiscipline <- gsub("\\First major", "", rawPrinceton5$DegreeDiscipline)
rawPrinceton5$DegreeDiscipline <- gsub("\\Second major", "", rawPrinceton5$DegreeDiscipline)

rawPrinceton5 <- rawPrinceton5 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawPrinceton6 <- t(read_csv("RawPrinceton6.csv"))
rawPrinceton6 <- cbind(rownames(rawPrinceton6), rawPrinceton6)
rownames(rawPrinceton6) <- NULL
rawPrinceton6 <- data.frame(DegreeDiscipline = rawPrinceton6)
colnames(rawPrinceton6) <- c("DegreeDiscipline","Total")
rawPrinceton6$DegreeDiscipline <- gsub("\\(C2004_A", "", rawPrinceton6$DegreeDiscipline)
rawPrinceton6$DegreeDiscipline <- gsub("\\First major", "", rawPrinceton6$DegreeDiscipline)
rawPrinceton6$DegreeDiscipline <- gsub("\\Second major", "", rawPrinceton6$DegreeDiscipline)

rawPrinceton6 <- rawPrinceton6 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawPrinceton7 <- t(read_csv("RawPrinceton7.csv"))
rawPrinceton7 <- cbind(rownames(rawPrinceton7), rawPrinceton7)
rownames(rawPrinceton7) <- NULL
rawPrinceton7 <- data.frame(DegreeDiscipline = rawPrinceton7)
colnames(rawPrinceton7) <- c("DegreeDiscipline","Total")
rawPrinceton7$DegreeDiscipline <- gsub("\\(C2003_A", "", rawPrinceton7$DegreeDiscipline)
rawPrinceton7$DegreeDiscipline <- gsub("\\First major", "", rawPrinceton7$DegreeDiscipline)
rawPrinceton7$DegreeDiscipline <- gsub("\\Second major", "", rawPrinceton7$DegreeDiscipline)

rawPrinceton7 <- rawPrinceton7 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawPrinceton <- left_join(rawPrinceton1, rawPrinceton2, by = "DegreeDiscipline") %>%
  left_join(rawPrinceton3, by = "DegreeDiscipline") %>%
  left_join(rawPrinceton4, by = "DegreeDiscipline") %>%
  left_join(rawPrinceton5, by = "DegreeDiscipline") %>%
  left_join(rawPrinceton6, by = "DegreeDiscipline") %>%
  left_join(rawPrinceton7, by = "DegreeDiscipline")

colnames(rawPrinceton) <- c("DegreeDiscipline", "Yr1", "Yr2", "Yr3", "Yr4", "Yr5", "Yr6", "Yr7")
rawPrinceton <- rawPrinceton %>%
  mutate(across(Yr1:Yr7, ~ parse_number(as.character(.x)))) %>%
  rowwise() %>%
  mutate(Total = sum(c_across(Yr1:Yr7), na.rm = TRUE)) %>%
  ungroup()
rawPrinceton <- rawPrinceton[-109,]

rm(rawPrinceton1)
rm(rawPrinceton2)
rm(rawPrinceton3)
rm(rawPrinceton4)
rm(rawPrinceton5)
rm(rawPrinceton6)
rm(rawPrinceton7)

rawRice1 <- t(read_csv("RawRice1.csv"))
rawRice1 <- cbind(rownames(rawRice1), rawRice1)
rownames(rawRice1) <- NULL
rawRice1 <- data.frame(DegreeDiscipline = rawRice1)
colnames(rawRice1) <- c("DegreeDiscipline","Total")
rawRice1$DegreeDiscipline <- gsub("\\(C2009_A", "", rawRice1$DegreeDiscipline)
rawRice1$DegreeDiscipline <- gsub("\\First major", "", rawRice1$DegreeDiscipline)
rawRice1$DegreeDiscipline <- gsub("\\Second major", "", rawRice1$DegreeDiscipline)

rawRice1 <- rawRice1 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawRice2 <- t(read_csv("RawRice2.csv"))
rawRice2 <- cbind(rownames(rawRice2), rawRice2)
rownames(rawRice2) <- NULL
rawRice2 <- data.frame(DegreeDiscipline = rawRice2)
colnames(rawRice2) <- c("DegreeDiscipline","Total")
rawRice2$DegreeDiscipline <- gsub("\\(C2008_A", "", rawRice2$DegreeDiscipline)
rawRice2$DegreeDiscipline <- gsub("\\First major", "", rawRice2$DegreeDiscipline)
rawRice2$DegreeDiscipline <- gsub("\\Second major", "", rawRice2$DegreeDiscipline)

rawRice2 <- rawRice2 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawRice3 <- t(read_csv("RawRice3.csv"))
rawRice3 <- cbind(rownames(rawRice3), rawRice3)
rownames(rawRice3) <- NULL
rawRice3 <- data.frame(DegreeDiscipline = rawRice3)
colnames(rawRice3) <- c("DegreeDiscipline","Total")
rawRice3$DegreeDiscipline <- gsub("\\(C2007_A", "", rawRice3$DegreeDiscipline)
rawRice3$DegreeDiscipline <- gsub("\\First major", "", rawRice3$DegreeDiscipline)
rawRice3$DegreeDiscipline <- gsub("\\Second major", "", rawRice3$DegreeDiscipline)

rawRice3 <- rawRice3 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawRice4 <- t(read_csv("RawRice4.csv"))
rawRice4 <- cbind(rownames(rawRice4), rawRice4)
rownames(rawRice4) <- NULL
rawRice4 <- data.frame(DegreeDiscipline = rawRice4)
colnames(rawRice4) <- c("DegreeDiscipline","Total")
rawRice4$DegreeDiscipline <- gsub("\\(C2006_A", "", rawRice4$DegreeDiscipline)
rawRice4$DegreeDiscipline <- gsub("\\First major", "", rawRice4$DegreeDiscipline)
rawRice4$DegreeDiscipline <- gsub("\\Second major", "", rawRice4$DegreeDiscipline)

rawRice4 <- rawRice4 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawRice5 <- t(read_csv("RawRice5.csv"))
rawRice5 <- cbind(rownames(rawRice5), rawRice5)
rownames(rawRice5) <- NULL
rawRice5 <- data.frame(DegreeDiscipline = rawRice5)
colnames(rawRice5) <- c("DegreeDiscipline","Total")
rawRice5$DegreeDiscipline <- gsub("\\(C2005_A", "", rawRice5$DegreeDiscipline)
rawRice5$DegreeDiscipline <- gsub("\\First major", "", rawRice5$DegreeDiscipline)
rawRice5$DegreeDiscipline <- gsub("\\Second major", "", rawRice5$DegreeDiscipline)

rawRice5 <- rawRice5 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawRice6 <- t(read_csv("RawRice6.csv"))
rawRice6 <- cbind(rownames(rawRice6), rawRice6)
rownames(rawRice6) <- NULL
rawRice6 <- data.frame(DegreeDiscipline = rawRice6)
colnames(rawRice6) <- c("DegreeDiscipline","Total")
rawRice6$DegreeDiscipline <- gsub("\\(C2004_A", "", rawRice6$DegreeDiscipline)
rawRice6$DegreeDiscipline <- gsub("\\First major", "", rawRice6$DegreeDiscipline)
rawRice6$DegreeDiscipline <- gsub("\\Second major", "", rawRice6$DegreeDiscipline)

rawRice6 <- rawRice6 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawRice7 <- t(read_csv("RawRice7.csv"))
rawRice7 <- cbind(rownames(rawRice7), rawRice7)
rownames(rawRice7) <- NULL
rawRice7 <- data.frame(DegreeDiscipline = rawRice7)
colnames(rawRice7) <- c("DegreeDiscipline","Total")
rawRice7$DegreeDiscipline <- gsub("\\(C2003_A", "", rawRice7$DegreeDiscipline)
rawRice7$DegreeDiscipline <- gsub("\\First major", "", rawRice7$DegreeDiscipline)
rawRice7$DegreeDiscipline <- gsub("\\Second major", "", rawRice7$DegreeDiscipline)

rawRice7 <- rawRice7 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawRice <- left_join(rawRice1, rawRice2, by = "DegreeDiscipline") %>%
  left_join(rawRice3, by = "DegreeDiscipline") %>%
  left_join(rawRice4, by = "DegreeDiscipline") %>%
  left_join(rawRice5, by = "DegreeDiscipline") %>%
  left_join(rawRice6, by = "DegreeDiscipline") %>%
  left_join(rawRice7, by = "DegreeDiscipline")

colnames(rawRice) <- c("DegreeDiscipline", "Yr1", "Yr2", "Yr3", "Yr4", "Yr5", "Yr6", "Yr7")
rawRice <- rawRice %>%
  mutate(across(Yr1:Yr7, ~ parse_number(as.character(.x)))) %>%
  rowwise() %>%
  mutate(Total = sum(c_across(Yr1:Yr7), na.rm = TRUE)) %>%
  ungroup()
rawRice <- rawRice[-109,]

rm(rawRice1)
rm(rawRice2)
rm(rawRice3)
rm(rawRice4)
rm(rawRice5)
rm(rawRice6)
rm(rawRice7)

rawStanford1 <- t(read_csv("RawStanford1.csv"))
rawStanford1 <- cbind(rownames(rawStanford1), rawStanford1)
rownames(rawStanford1) <- NULL
rawStanford1 <- data.frame(DegreeDiscipline = rawStanford1)
colnames(rawStanford1) <- c("DegreeDiscipline","Total")
rawStanford1$DegreeDiscipline <- gsub("\\(C2009_A", "", rawStanford1$DegreeDiscipline)
rawStanford1$DegreeDiscipline <- gsub("\\First major", "", rawStanford1$DegreeDiscipline)
rawStanford1$DegreeDiscipline <- gsub("\\Second major", "", rawStanford1$DegreeDiscipline)

rawStanford1 <- rawStanford1 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawStanford2 <- t(read_csv("RawStanford2.csv"))
rawStanford2 <- cbind(rownames(rawStanford2), rawStanford2)
rownames(rawStanford2) <- NULL
rawStanford2 <- data.frame(DegreeDiscipline = rawStanford2)
colnames(rawStanford2) <- c("DegreeDiscipline","Total")
rawStanford2$DegreeDiscipline <- gsub("\\(C2008_A", "", rawStanford2$DegreeDiscipline)
rawStanford2$DegreeDiscipline <- gsub("\\First major", "", rawStanford2$DegreeDiscipline)
rawStanford2$DegreeDiscipline <- gsub("\\Second major", "", rawStanford2$DegreeDiscipline)

rawStanford2 <- rawStanford2 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawStanford3 <- t(read_csv("RawStanford3.csv"))
rawStanford3 <- cbind(rownames(rawStanford3), rawStanford3)
rownames(rawStanford3) <- NULL
rawStanford3 <- data.frame(DegreeDiscipline = rawStanford3)
colnames(rawStanford3) <- c("DegreeDiscipline","Total")
rawStanford3$DegreeDiscipline <- gsub("\\(C2007_A", "", rawStanford3$DegreeDiscipline)
rawStanford3$DegreeDiscipline <- gsub("\\First major", "", rawStanford3$DegreeDiscipline)
rawStanford3$DegreeDiscipline <- gsub("\\Second major", "", rawStanford3$DegreeDiscipline)

rawStanford3 <- rawStanford3 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawStanford4 <- t(read_csv("RawStanford4.csv"))
rawStanford4 <- cbind(rownames(rawStanford4), rawStanford4)
rownames(rawStanford4) <- NULL
rawStanford4 <- data.frame(DegreeDiscipline = rawStanford4)
colnames(rawStanford4) <- c("DegreeDiscipline","Total")
rawStanford4$DegreeDiscipline <- gsub("\\(C2006_A", "", rawStanford4$DegreeDiscipline)
rawStanford4$DegreeDiscipline <- gsub("\\First major", "", rawStanford4$DegreeDiscipline)
rawStanford4$DegreeDiscipline <- gsub("\\Second major", "", rawStanford4$DegreeDiscipline)

rawStanford4 <- rawStanford4 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawStanford5 <- t(read_csv("RawStanford5.csv"))
rawStanford5 <- cbind(rownames(rawStanford5), rawStanford5)
rownames(rawStanford5) <- NULL
rawStanford5 <- data.frame(DegreeDiscipline = rawStanford5)
colnames(rawStanford5) <- c("DegreeDiscipline","Total")
rawStanford5$DegreeDiscipline <- gsub("\\(C2005_A", "", rawStanford5$DegreeDiscipline)
rawStanford5$DegreeDiscipline <- gsub("\\First major", "", rawStanford5$DegreeDiscipline)
rawStanford5$DegreeDiscipline <- gsub("\\Second major", "", rawStanford5$DegreeDiscipline)

rawStanford5 <- rawStanford5 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawStanford6 <- t(read_csv("RawStanford6.csv"))
rawStanford6 <- cbind(rownames(rawStanford6), rawStanford6)
rownames(rawStanford6) <- NULL
rawStanford6 <- data.frame(DegreeDiscipline = rawStanford6)
colnames(rawStanford6) <- c("DegreeDiscipline","Total")
rawStanford6$DegreeDiscipline <- gsub("\\(C2004_A", "", rawStanford6$DegreeDiscipline)
rawStanford6$DegreeDiscipline <- gsub("\\First major", "", rawStanford6$DegreeDiscipline)
rawStanford6$DegreeDiscipline <- gsub("\\Second major", "", rawStanford6$DegreeDiscipline)

rawStanford6 <- rawStanford6 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawStanford7 <- t(read_csv("RawStanford7.csv"))
rawStanford7 <- cbind(rownames(rawStanford7), rawStanford7)
rownames(rawStanford7) <- NULL
rawStanford7 <- data.frame(DegreeDiscipline = rawStanford7)
colnames(rawStanford7) <- c("DegreeDiscipline","Total")
rawStanford7$DegreeDiscipline <- gsub("\\(C2003_A", "", rawStanford7$DegreeDiscipline)
rawStanford7$DegreeDiscipline <- gsub("\\First major", "", rawStanford7$DegreeDiscipline)
rawStanford7$DegreeDiscipline <- gsub("\\Second major", "", rawStanford7$DegreeDiscipline)

rawStanford7 <- rawStanford7 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawStanford <- left_join(rawStanford1, rawStanford2, by = "DegreeDiscipline") %>%
  left_join(rawStanford3, by = "DegreeDiscipline") %>%
  left_join(rawStanford4, by = "DegreeDiscipline") %>%
  left_join(rawStanford5, by = "DegreeDiscipline") %>%
  left_join(rawStanford6, by = "DegreeDiscipline") %>%
  left_join(rawStanford7, by = "DegreeDiscipline")

colnames(rawStanford) <- c("DegreeDiscipline", "Yr1", "Yr2", "Yr3", "Yr4", "Yr5", "Yr6", "Yr7")
rawStanford <- rawStanford %>%
  mutate(across(Yr1:Yr7, ~ parse_number(as.character(.x)))) %>%
  rowwise() %>%
  mutate(Total = sum(c_across(Yr1:Yr7), na.rm = TRUE)) %>%
  ungroup()
rawStanford <- rawStanford[-109,]

rm(rawStanford1)
rm(rawStanford2)
rm(rawStanford3)
rm(rawStanford4)
rm(rawStanford5)
rm(rawStanford6)
rm(rawStanford7)

rawUCB1 <- t(read_csv("RawUCB1.csv"))
rawUCB1 <- cbind(rownames(rawUCB1), rawUCB1)
rownames(rawUCB1) <- NULL
rawUCB1 <- data.frame(DegreeDiscipline = rawUCB1)
colnames(rawUCB1) <- c("DegreeDiscipline","Total")
rawUCB1$DegreeDiscipline <- gsub("\\(C2009_A", "", rawUCB1$DegreeDiscipline)
rawUCB1$DegreeDiscipline <- gsub("\\First major", "", rawUCB1$DegreeDiscipline)
rawUCB1$DegreeDiscipline <- gsub("\\Second major", "", rawUCB1$DegreeDiscipline)

rawUCB1 <- rawUCB1 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUCB2 <- t(read_csv("RawUCB2.csv"))
rawUCB2 <- cbind(rownames(rawUCB2), rawUCB2)
rownames(rawUCB2) <- NULL
rawUCB2 <- data.frame(DegreeDiscipline = rawUCB2)
colnames(rawUCB2) <- c("DegreeDiscipline","Total")
rawUCB2$DegreeDiscipline <- gsub("\\(C2008_A", "", rawUCB2$DegreeDiscipline)
rawUCB2$DegreeDiscipline <- gsub("\\First major", "", rawUCB2$DegreeDiscipline)
rawUCB2$DegreeDiscipline <- gsub("\\Second major", "", rawUCB2$DegreeDiscipline)

rawUCB2 <- rawUCB2 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUCB3 <- t(read_csv("RawUCB3.csv"))
rawUCB3 <- cbind(rownames(rawUCB3), rawUCB3)
rownames(rawUCB3) <- NULL
rawUCB3 <- data.frame(DegreeDiscipline = rawUCB3)
colnames(rawUCB3) <- c("DegreeDiscipline","Total")
rawUCB3$DegreeDiscipline <- gsub("\\(C2007_A", "", rawUCB3$DegreeDiscipline)
rawUCB3$DegreeDiscipline <- gsub("\\First major", "", rawUCB3$DegreeDiscipline)
rawUCB3$DegreeDiscipline <- gsub("\\Second major", "", rawUCB3$DegreeDiscipline)

rawUCB3 <- rawUCB3 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUCB4 <- t(read_csv("RawUCB4.csv"))
rawUCB4 <- cbind(rownames(rawUCB4), rawUCB4)
rownames(rawUCB4) <- NULL
rawUCB4 <- data.frame(DegreeDiscipline = rawUCB4)
colnames(rawUCB4) <- c("DegreeDiscipline","Total")
rawUCB4$DegreeDiscipline <- gsub("\\(C2006_A", "", rawUCB4$DegreeDiscipline)
rawUCB4$DegreeDiscipline <- gsub("\\First major", "", rawUCB4$DegreeDiscipline)
rawUCB4$DegreeDiscipline <- gsub("\\Second major", "", rawUCB4$DegreeDiscipline)

rawUCB4 <- rawUCB4 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUCB5 <- t(read_csv("RawUCB5.csv"))
rawUCB5 <- cbind(rownames(rawUCB5), rawUCB5)
rownames(rawUCB5) <- NULL
rawUCB5 <- data.frame(DegreeDiscipline = rawUCB5)
colnames(rawUCB5) <- c("DegreeDiscipline","Total")
rawUCB5$DegreeDiscipline <- gsub("\\(C2005_A", "", rawUCB5$DegreeDiscipline)
rawUCB5$DegreeDiscipline <- gsub("\\First major", "", rawUCB5$DegreeDiscipline)
rawUCB5$DegreeDiscipline <- gsub("\\Second major", "", rawUCB5$DegreeDiscipline)

rawUCB5 <- rawUCB5 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUCB6 <- t(read_csv("RawUCB6.csv"))
rawUCB6 <- cbind(rownames(rawUCB6), rawUCB6)
rownames(rawUCB6) <- NULL
rawUCB6 <- data.frame(DegreeDiscipline = rawUCB6)
colnames(rawUCB6) <- c("DegreeDiscipline","Total")
rawUCB6$DegreeDiscipline <- gsub("\\(C2004_A", "", rawUCB6$DegreeDiscipline)
rawUCB6$DegreeDiscipline <- gsub("\\First major", "", rawUCB6$DegreeDiscipline)
rawUCB6$DegreeDiscipline <- gsub("\\Second major", "", rawUCB6$DegreeDiscipline)

rawUCB6 <- rawUCB6 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUCB7 <- t(read_csv("RawUCB7.csv"))
rawUCB7 <- cbind(rownames(rawUCB7), rawUCB7)
rownames(rawUCB7) <- NULL
rawUCB7 <- data.frame(DegreeDiscipline = rawUCB7)
colnames(rawUCB7) <- c("DegreeDiscipline","Total")
rawUCB7$DegreeDiscipline <- gsub("\\(C2003_A", "", rawUCB7$DegreeDiscipline)
rawUCB7$DegreeDiscipline <- gsub("\\First major", "", rawUCB7$DegreeDiscipline)
rawUCB7$DegreeDiscipline <- gsub("\\Second major", "", rawUCB7$DegreeDiscipline)

rawUCB7 <- rawUCB7 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUCB <- left_join(rawUCB1, rawUCB2, by = "DegreeDiscipline") %>%
  left_join(rawUCB3, by = "DegreeDiscipline") %>%
  left_join(rawUCB4, by = "DegreeDiscipline") %>%
  left_join(rawUCB5, by = "DegreeDiscipline") %>%
  left_join(rawUCB6, by = "DegreeDiscipline") %>%
  left_join(rawUCB7, by = "DegreeDiscipline")

colnames(rawUCB) <- c("DegreeDiscipline", "Yr1", "Yr2", "Yr3", "Yr4", "Yr5", "Yr6", "Yr7")
rawUCB <- rawUCB %>%
  mutate(across(Yr1:Yr7, ~ parse_number(as.character(.x)))) %>%
  rowwise() %>%
  mutate(Total = sum(c_across(Yr1:Yr7), na.rm = TRUE)) %>%
  ungroup()
rawUCB <- rawUCB[-109,]

rm(rawUCB1)
rm(rawUCB2)
rm(rawUCB3)
rm(rawUCB4)
rm(rawUCB5)
rm(rawUCB6)
rm(rawUCB7)

rawUCLA1 <- t(read_csv("RawUCLA1.csv"))
rawUCLA1 <- cbind(rownames(rawUCLA1), rawUCLA1)
rownames(rawUCLA1) <- NULL
rawUCLA1 <- data.frame(DegreeDiscipline = rawUCLA1)
colnames(rawUCLA1) <- c("DegreeDiscipline","Total")
rawUCLA1$DegreeDiscipline <- gsub("\\(C2009_A", "", rawUCLA1$DegreeDiscipline)
rawUCLA1$DegreeDiscipline <- gsub("\\First major", "", rawUCLA1$DegreeDiscipline)
rawUCLA1$DegreeDiscipline <- gsub("\\Second major", "", rawUCLA1$DegreeDiscipline)

rawUCLA1 <- rawUCLA1 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUCLA2 <- t(read_csv("RawUCLA2.csv"))
rawUCLA2 <- cbind(rownames(rawUCLA2), rawUCLA2)
rownames(rawUCLA2) <- NULL
rawUCLA2 <- data.frame(DegreeDiscipline = rawUCLA2)
colnames(rawUCLA2) <- c("DegreeDiscipline","Total")
rawUCLA2$DegreeDiscipline <- gsub("\\(C2008_A", "", rawUCLA2$DegreeDiscipline)
rawUCLA2$DegreeDiscipline <- gsub("\\First major", "", rawUCLA2$DegreeDiscipline)
rawUCLA2$DegreeDiscipline <- gsub("\\Second major", "", rawUCLA2$DegreeDiscipline)

rawUCLA2 <- rawUCLA2 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))


rawUCLA3 <- t(read_csv("RawUCLA3.csv"))
rawUCLA3 <- cbind(rownames(rawUCLA3), rawUCLA3)
rownames(rawUCLA3) <- NULL
rawUCLA3 <- data.frame(DegreeDiscipline = rawUCLA3)
colnames(rawUCLA3) <- c("DegreeDiscipline","Total")
rawUCLA3$DegreeDiscipline <- gsub("\\(C2007_A", "", rawUCLA3$DegreeDiscipline)
rawUCLA3$DegreeDiscipline <- gsub("\\First major", "", rawUCLA3$DegreeDiscipline)
rawUCLA3$DegreeDiscipline <- gsub("\\Second major", "", rawUCLA3$DegreeDiscipline)

rawUCLA3 <- rawUCLA3 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUCLA4 <- t(read_csv("RawUCLA4.csv"))
rawUCLA4 <- cbind(rownames(rawUCLA4), rawUCLA4)
rownames(rawUCLA4) <- NULL
rawUCLA4 <- data.frame(DegreeDiscipline = rawUCLA4)
colnames(rawUCLA4) <- c("DegreeDiscipline","Total")
rawUCLA4$DegreeDiscipline <- gsub("\\(C2006_A", "", rawUCLA4$DegreeDiscipline)
rawUCLA4$DegreeDiscipline <- gsub("\\First major", "", rawUCLA4$DegreeDiscipline)
rawUCLA4$DegreeDiscipline <- gsub("\\Second major", "", rawUCLA4$DegreeDiscipline)

rawUCLA4 <- rawUCLA4 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUCLA5 <- t(read_csv("RawUCLA5.csv"))
rawUCLA5 <- cbind(rownames(rawUCLA5), rawUCLA5)
rownames(rawUCLA5) <- NULL
rawUCLA5 <- data.frame(DegreeDiscipline = rawUCLA5)
colnames(rawUCLA5) <- c("DegreeDiscipline","Total")
rawUCLA5$DegreeDiscipline <- gsub("\\(C2005_A", "", rawUCLA5$DegreeDiscipline)
rawUCLA5$DegreeDiscipline <- gsub("\\First major", "", rawUCLA5$DegreeDiscipline)
rawUCLA5$DegreeDiscipline <- gsub("\\Second major", "", rawUCLA5$DegreeDiscipline)

rawUCLA5 <- rawUCLA5 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUCLA6 <- t(read_csv("RawUCLA6.csv"))
rawUCLA6 <- cbind(rownames(rawUCLA6), rawUCLA6)
rownames(rawUCLA6) <- NULL
rawUCLA6 <- data.frame(DegreeDiscipline = rawUCLA6)
colnames(rawUCLA6) <- c("DegreeDiscipline","Total")
rawUCLA6$DegreeDiscipline <- gsub("\\(C2004_A", "", rawUCLA6$DegreeDiscipline)
rawUCLA6$DegreeDiscipline <- gsub("\\First major", "", rawUCLA6$DegreeDiscipline)
rawUCLA6$DegreeDiscipline <- gsub("\\Second major", "", rawUCLA6$DegreeDiscipline)

rawUCLA6 <- rawUCLA6 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUCLA7 <- t(read_csv("RawUCLA7.csv"))
rawUCLA7 <- cbind(rownames(rawUCLA7), rawUCLA7)
rownames(rawUCLA7) <- NULL
rawUCLA7 <- data.frame(DegreeDiscipline = rawUCLA7)
colnames(rawUCLA7) <- c("DegreeDiscipline","Total")
rawUCLA7$DegreeDiscipline <- gsub("\\(C2003_A", "", rawUCLA7$DegreeDiscipline)
rawUCLA7$DegreeDiscipline <- gsub("\\First major", "", rawUCLA7$DegreeDiscipline)
rawUCLA7$DegreeDiscipline <- gsub("\\Second major", "", rawUCLA7$DegreeDiscipline)

rawUCLA7 <- rawUCLA7 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUCLA <- left_join(rawUCLA1, rawUCLA2, by = "DegreeDiscipline") %>%
  left_join(rawUCLA3, by = "DegreeDiscipline") %>%
  left_join(rawUCLA4, by = "DegreeDiscipline") %>%
  left_join(rawUCLA5, by = "DegreeDiscipline") %>%
  left_join(rawUCLA6, by = "DegreeDiscipline") %>%
  left_join(rawUCLA7, by = "DegreeDiscipline")

colnames(rawUCLA) <- c("DegreeDiscipline", "Yr1", "Yr2", "Yr3", "Yr4", "Yr5", "Yr6", "Yr7")
rawUCLA <- rawUCLA %>%
  mutate(across(Yr1:Yr7, ~ parse_number(as.character(.x)))) %>%
  rowwise() %>%
  mutate(Total = sum(c_across(Yr1:Yr7), na.rm = TRUE)) %>%
  ungroup()
rawUCLA <- rawUCLA[-109,]

rm(rawUCLA1)
rm(rawUCLA2)
rm(rawUCLA3)
rm(rawUCLA4)
rm(rawUCLA5)
rm(rawUCLA6)
rm(rawUCLA7)

rawUCSD1 <- t(read_csv("RawUCSD1.csv"))
rawUCSD1 <- cbind(rownames(rawUCSD1), rawUCSD1)
rownames(rawUCSD1) <- NULL
rawUCSD1 <- data.frame(DegreeDiscipline = rawUCSD1)
colnames(rawUCSD1) <- c("DegreeDiscipline","Total")
rawUCSD1$DegreeDiscipline <- gsub("\\(C2009_A", "", rawUCSD1$DegreeDiscipline)
rawUCSD1$DegreeDiscipline <- gsub("\\First major", "", rawUCSD1$DegreeDiscipline)
rawUCSD1$DegreeDiscipline <- gsub("\\Second major", "", rawUCSD1$DegreeDiscipline)

rawUCSD1 <- rawUCSD1 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUCSD2 <- t(read_csv("RawUCSD2.csv"))
rawUCSD2 <- cbind(rownames(rawUCSD2), rawUCSD2)
rownames(rawUCSD2) <- NULL
rawUCSD2 <- data.frame(DegreeDiscipline = rawUCSD2)
colnames(rawUCSD2) <- c("DegreeDiscipline","Total")
rawUCSD2$DegreeDiscipline <- gsub("\\(C2008_A", "", rawUCSD2$DegreeDiscipline)
rawUCSD2$DegreeDiscipline <- gsub("\\First major", "", rawUCSD2$DegreeDiscipline)
rawUCSD2$DegreeDiscipline <- gsub("\\Second major", "", rawUCSD2$DegreeDiscipline)

rawUCSD2 <- rawUCSD2 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))


rawUCSD3 <- t(read_csv("RawUCSD3.csv"))
rawUCSD3 <- cbind(rownames(rawUCSD3), rawUCSD3)
rownames(rawUCSD3) <- NULL
rawUCSD3 <- data.frame(DegreeDiscipline = rawUCSD3)
colnames(rawUCSD3) <- c("DegreeDiscipline","Total")
rawUCSD3$DegreeDiscipline <- gsub("\\(C2007_A", "", rawUCSD3$DegreeDiscipline)
rawUCSD3$DegreeDiscipline <- gsub("\\First major", "", rawUCSD3$DegreeDiscipline)
rawUCSD3$DegreeDiscipline <- gsub("\\Second major", "", rawUCSD3$DegreeDiscipline)

rawUCSD3 <- rawUCSD3 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))


rawUCSD4 <- t(read_csv("RawUCSD4.csv"))
rawUCSD4 <- cbind(rownames(rawUCSD4), rawUCSD4)
rownames(rawUCSD4) <- NULL
rawUCSD4 <- data.frame(DegreeDiscipline = rawUCSD4)
colnames(rawUCSD4) <- c("DegreeDiscipline","Total")
rawUCSD4$DegreeDiscipline <- gsub("\\(C2006_A", "", rawUCSD4$DegreeDiscipline)
rawUCSD4$DegreeDiscipline <- gsub("\\First major", "", rawUCSD4$DegreeDiscipline)
rawUCSD4$DegreeDiscipline <- gsub("\\Second major", "", rawUCSD4$DegreeDiscipline)

rawUCSD4 <- rawUCSD4 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUCSD5 <- t(read_csv("RawUCSD5.csv"))
rawUCSD5 <- cbind(rownames(rawUCSD5), rawUCSD5)
rownames(rawUCSD5) <- NULL
rawUCSD5 <- data.frame(DegreeDiscipline = rawUCSD5)
colnames(rawUCSD5) <- c("DegreeDiscipline","Total")
rawUCSD5$DegreeDiscipline <- gsub("\\(C2005_A", "", rawUCSD5$DegreeDiscipline)
rawUCSD5$DegreeDiscipline <- gsub("\\First major", "", rawUCSD5$DegreeDiscipline)
rawUCSD5$DegreeDiscipline <- gsub("\\Second major", "", rawUCSD5$DegreeDiscipline)

rawUCSD5 <- rawUCSD5 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUCSD6 <- t(read_csv("RawUCSD6.csv"))
rawUCSD6 <- cbind(rownames(rawUCSD6), rawUCSD6)
rownames(rawUCSD6) <- NULL
rawUCSD6 <- data.frame(DegreeDiscipline = rawUCSD6)
colnames(rawUCSD6) <- c("DegreeDiscipline","Total")
rawUCSD6$DegreeDiscipline <- gsub("\\(C2004_A", "", rawUCSD6$DegreeDiscipline)
rawUCSD6$DegreeDiscipline <- gsub("\\First major", "", rawUCSD6$DegreeDiscipline)
rawUCSD6$DegreeDiscipline <- gsub("\\Second major", "", rawUCSD6$DegreeDiscipline)

rawUCSD6 <- rawUCSD6 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUCSD7 <- t(read_csv("RawUCSD7.csv"))
rawUCSD7 <- cbind(rownames(rawUCSD7), rawUCSD7)
rownames(rawUCSD7) <- NULL
rawUCSD7 <- data.frame(DegreeDiscipline = rawUCSD7)
colnames(rawUCSD7) <- c("DegreeDiscipline","Total")
rawUCSD7$DegreeDiscipline <- gsub("\\(C2003_A", "", rawUCSD7$DegreeDiscipline)
rawUCSD7$DegreeDiscipline <- gsub("\\First major", "", rawUCSD7$DegreeDiscipline)
rawUCSD7$DegreeDiscipline <- gsub("\\Second major", "", rawUCSD7$DegreeDiscipline)

rawUCSD7 <- rawUCSD7 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUCSD <- left_join(rawUCSD1, rawUCSD2, by = "DegreeDiscipline") %>%
  left_join(rawUCSD3, by = "DegreeDiscipline") %>%
  left_join(rawUCSD4, by = "DegreeDiscipline") %>%
  left_join(rawUCSD5, by = "DegreeDiscipline") %>%
  left_join(rawUCSD6, by = "DegreeDiscipline") %>%
  left_join(rawUCSD7, by = "DegreeDiscipline")

colnames(rawUCSD) <- c("DegreeDiscipline", "Yr1", "Yr2", "Yr3", "Yr4", "Yr5", "Yr6", "Yr7")
rawUCSD <- rawUCSD %>%
  mutate(across(Yr1:Yr7, ~ parse_number(as.character(.x)))) %>%
  rowwise() %>%
  mutate(Total = sum(c_across(Yr1:Yr7), na.rm = TRUE)) %>%
  ungroup()
rawUCSD <- rawUCSD[-109,]

rm(rawUCSD1)
rm(rawUCSD2)
rm(rawUCSD3)
rm(rawUCSD4)
rm(rawUCSD5)
rm(rawUCSD6)
rm(rawUCSD7)

rawUCHICAGO1 <- t(read_csv("RawUCHICAGO1.csv"))
rawUCHICAGO1 <- cbind(rownames(rawUCHICAGO1), rawUCHICAGO1)
rownames(rawUCHICAGO1) <- NULL
rawUCHICAGO1 <- data.frame(DegreeDiscipline = rawUCHICAGO1)
colnames(rawUCHICAGO1) <- c("DegreeDiscipline","Total")
rawUCHICAGO1$DegreeDiscipline <- gsub("\\(C2009_A", "", rawUCHICAGO1$DegreeDiscipline)
rawUCHICAGO1$DegreeDiscipline <- gsub("\\First major", "", rawUCHICAGO1$DegreeDiscipline)
rawUCHICAGO1$DegreeDiscipline <- gsub("\\Second major", "", rawUCHICAGO1$DegreeDiscipline)

rawUCHICAGO1 <- rawUCHICAGO1 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUCHICAGO2 <- t(read_csv("RawUCHICAGO2.csv"))
rawUCHICAGO2 <- cbind(rownames(rawUCHICAGO2), rawUCHICAGO2)
rownames(rawUCHICAGO2) <- NULL
rawUCHICAGO2 <- data.frame(DegreeDiscipline = rawUCHICAGO2)
colnames(rawUCHICAGO2) <- c("DegreeDiscipline","Total")
rawUCHICAGO2$DegreeDiscipline <- gsub("\\(C2008_A", "", rawUCHICAGO2$DegreeDiscipline)
rawUCHICAGO2$DegreeDiscipline <- gsub("\\First major", "", rawUCHICAGO2$DegreeDiscipline)
rawUCHICAGO2$DegreeDiscipline <- gsub("\\Second major", "", rawUCHICAGO2$DegreeDiscipline)

rawUCHICAGO2 <- rawUCHICAGO2 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUCHICAGO3 <- t(read_csv("RawUCHICAGO3.csv"))
rawUCHICAGO3 <- cbind(rownames(rawUCHICAGO3), rawUCHICAGO3)
rownames(rawUCHICAGO3) <- NULL
rawUCHICAGO3 <- data.frame(DegreeDiscipline = rawUCHICAGO3)
colnames(rawUCHICAGO3) <- c("DegreeDiscipline","Total")
rawUCHICAGO3$DegreeDiscipline <- gsub("\\(C2007_A", "", rawUCHICAGO3$DegreeDiscipline)
rawUCHICAGO3$DegreeDiscipline <- gsub("\\First major", "", rawUCHICAGO3$DegreeDiscipline)
rawUCHICAGO3$DegreeDiscipline <- gsub("\\Second major", "", rawUCHICAGO3$DegreeDiscipline)

rawUCHICAGO3 <- rawUCHICAGO3 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUCHICAGO4 <- t(read_csv("RawUCHICAGO4.csv"))
rawUCHICAGO4 <- cbind(rownames(rawUCHICAGO4), rawUCHICAGO4)
rownames(rawUCHICAGO4) <- NULL
rawUCHICAGO4 <- data.frame(DegreeDiscipline = rawUCHICAGO4)
colnames(rawUCHICAGO4) <- c("DegreeDiscipline","Total")
rawUCHICAGO4$DegreeDiscipline <- gsub("\\(C2006_A", "", rawUCHICAGO4$DegreeDiscipline)
rawUCHICAGO4$DegreeDiscipline <- gsub("\\First major", "", rawUCHICAGO4$DegreeDiscipline)
rawUCHICAGO4$DegreeDiscipline <- gsub("\\Second major", "", rawUCHICAGO4$DegreeDiscipline)

rawUCHICAGO4 <- rawUCHICAGO4 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUCHICAGO5 <- t(read_csv("RawUCHICAGO5.csv"))
rawUCHICAGO5 <- cbind(rownames(rawUCHICAGO5), rawUCHICAGO5)
rownames(rawUCHICAGO5) <- NULL
rawUCHICAGO5 <- data.frame(DegreeDiscipline = rawUCHICAGO5)
colnames(rawUCHICAGO5) <- c("DegreeDiscipline","Total")
rawUCHICAGO5$DegreeDiscipline <- gsub("\\(C2005_A", "", rawUCHICAGO5$DegreeDiscipline)
rawUCHICAGO5$DegreeDiscipline <- gsub("\\First major", "", rawUCHICAGO5$DegreeDiscipline)
rawUCHICAGO5$DegreeDiscipline <- gsub("\\Second major", "", rawUCHICAGO5$DegreeDiscipline)

rawUCHICAGO5 <- rawUCHICAGO5 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUCHICAGO6 <- t(read_csv("RawUCHICAGO6.csv"))
rawUCHICAGO6 <- cbind(rownames(rawUCHICAGO6), rawUCHICAGO6)
rownames(rawUCHICAGO6) <- NULL
rawUCHICAGO6 <- data.frame(DegreeDiscipline = rawUCHICAGO6)
colnames(rawUCHICAGO6) <- c("DegreeDiscipline","Total")
rawUCHICAGO6$DegreeDiscipline <- gsub("\\(C2004_A", "", rawUCHICAGO6$DegreeDiscipline)
rawUCHICAGO6$DegreeDiscipline <- gsub("\\First major", "", rawUCHICAGO6$DegreeDiscipline)
rawUCHICAGO6$DegreeDiscipline <- gsub("\\Second major", "", rawUCHICAGO6$DegreeDiscipline)

rawUCHICAGO6 <- rawUCHICAGO6 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUCHICAGO7 <- t(read_csv("RawUCHICAGO7.csv"))
rawUCHICAGO7 <- cbind(rownames(rawUCHICAGO7), rawUCHICAGO7)
rownames(rawUCHICAGO7) <- NULL
rawUCHICAGO7 <- data.frame(DegreeDiscipline = rawUCHICAGO7)
colnames(rawUCHICAGO7) <- c("DegreeDiscipline","Total")
rawUCHICAGO7$DegreeDiscipline <- gsub("\\(C2003_A", "", rawUCHICAGO7$DegreeDiscipline)
rawUCHICAGO7$DegreeDiscipline <- gsub("\\First major", "", rawUCHICAGO7$DegreeDiscipline)
rawUCHICAGO7$DegreeDiscipline <- gsub("\\Second major", "", rawUCHICAGO7$DegreeDiscipline)

rawUCHICAGO7 <- rawUCHICAGO7 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUCHICAGO <- left_join(rawUCHICAGO1, rawUCHICAGO2, by = "DegreeDiscipline") %>%
  left_join(rawUCHICAGO3, by = "DegreeDiscipline") %>%
  left_join(rawUCHICAGO4, by = "DegreeDiscipline") %>%
  left_join(rawUCHICAGO5, by = "DegreeDiscipline") %>%
  left_join(rawUCHICAGO6, by = "DegreeDiscipline") %>%
  left_join(rawUCHICAGO7, by = "DegreeDiscipline")

colnames(rawUCHICAGO) <- c("DegreeDiscipline", "Yr1", "Yr2", "Yr3", "Yr4", "Yr5", "Yr6", "Yr7")
rawUCHICAGO <- rawUCHICAGO %>%
  mutate(across(Yr1:Yr7, ~ parse_number(as.character(.x)))) %>%
  rowwise() %>%
  mutate(Total = sum(c_across(Yr1:Yr7), na.rm = TRUE)) %>%
  ungroup()
rawUCHICAGO <- rawUCHICAGO[-109,]

rm(rawUCHICAGO1)
rm(rawUCHICAGO2)
rm(rawUCHICAGO3)
rm(rawUCHICAGO4)
rm(rawUCHICAGO5)
rm(rawUCHICAGO6)
rm(rawUCHICAGO7)

rawUMANNARBOR1 <- t(read_csv("RawUMANNARBOR1.csv"))
rawUMANNARBOR1 <- cbind(rownames(rawUMANNARBOR1), rawUMANNARBOR1)
rownames(rawUMANNARBOR1) <- NULL
rawUMANNARBOR1 <- data.frame(DegreeDiscipline = rawUMANNARBOR1)
colnames(rawUMANNARBOR1) <- c("DegreeDiscipline","Total")
rawUMANNARBOR1$DegreeDiscipline <- gsub("\\(C2008_A", "", rawUMANNARBOR1$DegreeDiscipline)
rawUMANNARBOR1$DegreeDiscipline <- gsub("\\First major", "", rawUMANNARBOR1$DegreeDiscipline)
rawUMANNARBOR1$DegreeDiscipline <- gsub("\\Second major", "", rawUMANNARBOR1$DegreeDiscipline)

rawUMANNARBOR1 <- rawUMANNARBOR1 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUMANNARBOR2 <- t(read_csv("RawUMANNARBOR2.csv"))
rawUMANNARBOR2 <- cbind(rownames(rawUMANNARBOR2), rawUMANNARBOR2)
rownames(rawUMANNARBOR2) <- NULL
rawUMANNARBOR2 <- data.frame(DegreeDiscipline = rawUMANNARBOR2)
colnames(rawUMANNARBOR2) <- c("DegreeDiscipline","Total")
rawUMANNARBOR2$DegreeDiscipline <- gsub("\\(C2007_A", "", rawUMANNARBOR2$DegreeDiscipline)
rawUMANNARBOR2$DegreeDiscipline <- gsub("\\First major", "", rawUMANNARBOR2$DegreeDiscipline)
rawUMANNARBOR2$DegreeDiscipline <- gsub("\\Second major", "", rawUMANNARBOR2$DegreeDiscipline)

rawUMANNARBOR2 <- rawUMANNARBOR2 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUMANNARBOR3 <- t(read_csv("RawUMANNARBOR3.csv"))
rawUMANNARBOR3 <- cbind(rownames(rawUMANNARBOR3), rawUMANNARBOR3)
rownames(rawUMANNARBOR3) <- NULL
rawUMANNARBOR3 <- data.frame(DegreeDiscipline = rawUMANNARBOR3)
colnames(rawUMANNARBOR3) <- c("DegreeDiscipline","Total")
rawUMANNARBOR3$DegreeDiscipline <- gsub("\\(C2006_A", "", rawUMANNARBOR3$DegreeDiscipline)
rawUMANNARBOR3$DegreeDiscipline <- gsub("\\First major", "", rawUMANNARBOR3$DegreeDiscipline)
rawUMANNARBOR3$DegreeDiscipline <- gsub("\\Second major", "", rawUMANNARBOR3$DegreeDiscipline)

rawUMANNARBOR3 <- rawUMANNARBOR3 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUMANNARBOR4 <- t(read_csv("RawUMANNARBOR4.csv"))
rawUMANNARBOR4 <- cbind(rownames(rawUMANNARBOR4), rawUMANNARBOR4)
rownames(rawUMANNARBOR4) <- NULL
rawUMANNARBOR4 <- data.frame(DegreeDiscipline = rawUMANNARBOR4)
colnames(rawUMANNARBOR4) <- c("DegreeDiscipline","Total")
rawUMANNARBOR4$DegreeDiscipline <- gsub("\\(C2005_A", "", rawUMANNARBOR4$DegreeDiscipline)
rawUMANNARBOR4$DegreeDiscipline <- gsub("\\First major", "", rawUMANNARBOR4$DegreeDiscipline)
rawUMANNARBOR4$DegreeDiscipline <- gsub("\\Second major", "", rawUMANNARBOR4$DegreeDiscipline)

rawUMANNARBOR4 <- rawUMANNARBOR4 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUMANNARBOR5 <- t(read_csv("RawUMANNARBOR5.csv"))
rawUMANNARBOR5 <- cbind(rownames(rawUMANNARBOR5), rawUMANNARBOR5)
rownames(rawUMANNARBOR5) <- NULL
rawUMANNARBOR5 <- data.frame(DegreeDiscipline = rawUMANNARBOR5)
colnames(rawUMANNARBOR5) <- c("DegreeDiscipline","Total")
rawUMANNARBOR5$DegreeDiscipline <- gsub("\\(C2004_A", "", rawUMANNARBOR5$DegreeDiscipline)
rawUMANNARBOR5$DegreeDiscipline <- gsub("\\First major", "", rawUMANNARBOR5$DegreeDiscipline)
rawUMANNARBOR5$DegreeDiscipline <- gsub("\\Second major", "", rawUMANNARBOR5$DegreeDiscipline)

rawUMANNARBOR5 <- rawUMANNARBOR5 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUMANNARBOR6 <- t(read_csv("RawUMANNARBOR6.csv"))
rawUMANNARBOR6 <- cbind(rownames(rawUMANNARBOR6), rawUMANNARBOR6)
rownames(rawUMANNARBOR6) <- NULL
rawUMANNARBOR6 <- data.frame(DegreeDiscipline = rawUMANNARBOR6)
colnames(rawUMANNARBOR6) <- c("DegreeDiscipline","Total")
rawUMANNARBOR6$DegreeDiscipline <- gsub("\\(C2003_A", "", rawUMANNARBOR6$DegreeDiscipline)
rawUMANNARBOR6$DegreeDiscipline <- gsub("\\First major", "", rawUMANNARBOR6$DegreeDiscipline)
rawUMANNARBOR6$DegreeDiscipline <- gsub("\\Second major", "", rawUMANNARBOR6$DegreeDiscipline)

rawUMANNARBOR6 <- rawUMANNARBOR6 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUMANNARBOR7 <- t(read_csv("RawUMANNARBOR7.csv"))
rawUMANNARBOR7 <- cbind(rownames(rawUMANNARBOR7), rawUMANNARBOR7)
rownames(rawUMANNARBOR7) <- NULL
rawUMANNARBOR7 <- data.frame(DegreeDiscipline = rawUMANNARBOR7)
colnames(rawUMANNARBOR7) <- c("DegreeDiscipline","Total")
rawUMANNARBOR7$DegreeDiscipline <- gsub("\\(C2009_A", "", rawUMANNARBOR7$DegreeDiscipline)
rawUMANNARBOR7$DegreeDiscipline <- gsub("\\First major", "", rawUMANNARBOR7$DegreeDiscipline)
rawUMANNARBOR7$DegreeDiscipline <- gsub("\\Second major", "", rawUMANNARBOR7$DegreeDiscipline)

rawUMANNARBOR7 <- rawUMANNARBOR7 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUMANNARBOR <- left_join(rawUMANNARBOR1, rawUMANNARBOR2, by = "DegreeDiscipline") %>%
  left_join(rawUMANNARBOR3, by = "DegreeDiscipline") %>%
  left_join(rawUMANNARBOR4, by = "DegreeDiscipline") %>%
  left_join(rawUMANNARBOR5, by = "DegreeDiscipline") %>%
  left_join(rawUMANNARBOR6, by = "DegreeDiscipline") %>%
  left_join(rawUMANNARBOR7, by = "DegreeDiscipline")

colnames(rawUMANNARBOR) <- c("DegreeDiscipline", "Yr1", "Yr2", "Yr3", "Yr4", "Yr5", "Yr6", "Yr7")
rawUMANNARBOR <- rawUMANNARBOR %>%
  mutate(across(Yr1:Yr7, ~ parse_number(as.character(.x)))) %>%
  rowwise() %>%
  mutate(Total = sum(c_across(Yr1:Yr7), na.rm = TRUE)) %>%
  ungroup()
rawUMANNARBOR <- rawUMANNARBOR[-109,]

rm(rawUMANNARBOR1)
rm(rawUMANNARBOR2)
rm(rawUMANNARBOR3)
rm(rawUMANNARBOR4)
rm(rawUMANNARBOR5)
rm(rawUMANNARBOR6)
rm(rawUMANNARBOR7)

rawUNOTREDAME1 <- t(read_csv("RawUNOTREDAME1.csv"))
rawUNOTREDAME1 <- cbind(rownames(rawUNOTREDAME1), rawUNOTREDAME1)
rownames(rawUNOTREDAME1) <- NULL
rawUNOTREDAME1 <- data.frame(DegreeDiscipline = rawUNOTREDAME1)
colnames(rawUNOTREDAME1) <- c("DegreeDiscipline","Total")
rawUNOTREDAME1$DegreeDiscipline <- gsub("\\(C2009_A", "", rawUNOTREDAME1$DegreeDiscipline)
rawUNOTREDAME1$DegreeDiscipline <- gsub("\\First major", "", rawUNOTREDAME1$DegreeDiscipline)
rawUNOTREDAME1$DegreeDiscipline <- gsub("\\Second major", "", rawUNOTREDAME1$DegreeDiscipline)

rawUNOTREDAME1 <- rawUNOTREDAME1 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUNOTREDAME2 <- t(read_csv("RawUNOTREDAME2.csv"))
rawUNOTREDAME2 <- cbind(rownames(rawUNOTREDAME2), rawUNOTREDAME2)
rownames(rawUNOTREDAME2) <- NULL
rawUNOTREDAME2 <- data.frame(DegreeDiscipline = rawUNOTREDAME2)
colnames(rawUNOTREDAME2) <- c("DegreeDiscipline","Total")
rawUNOTREDAME2$DegreeDiscipline <- gsub("\\(C2008_A", "", rawUNOTREDAME2$DegreeDiscipline)
rawUNOTREDAME2$DegreeDiscipline <- gsub("\\First major", "", rawUNOTREDAME2$DegreeDiscipline)
rawUNOTREDAME2$DegreeDiscipline <- gsub("\\Second major", "", rawUNOTREDAME2$DegreeDiscipline)

rawUNOTREDAME2 <- rawUNOTREDAME2 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))


rawUNOTREDAME3 <- t(read_csv("RawUNOTREDAME3.csv"))
rawUNOTREDAME3 <- cbind(rownames(rawUNOTREDAME3), rawUNOTREDAME3)
rownames(rawUNOTREDAME3) <- NULL
rawUNOTREDAME3 <- data.frame(DegreeDiscipline = rawUNOTREDAME3)
colnames(rawUNOTREDAME3) <- c("DegreeDiscipline","Total")
rawUNOTREDAME3$DegreeDiscipline <- gsub("\\(C2007_A", "", rawUNOTREDAME3$DegreeDiscipline)
rawUNOTREDAME3$DegreeDiscipline <- gsub("\\First major", "", rawUNOTREDAME3$DegreeDiscipline)
rawUNOTREDAME3$DegreeDiscipline <- gsub("\\Second major", "", rawUNOTREDAME3$DegreeDiscipline)

rawUNOTREDAME3 <- rawUNOTREDAME3 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))


rawUNOTREDAME4 <- t(read_csv("RawUNOTREDAME4.csv"))
rawUNOTREDAME4 <- cbind(rownames(rawUNOTREDAME4), rawUNOTREDAME4)
rownames(rawUNOTREDAME4) <- NULL
rawUNOTREDAME4 <- data.frame(DegreeDiscipline = rawUNOTREDAME4)
colnames(rawUNOTREDAME4) <- c("DegreeDiscipline","Total")
rawUNOTREDAME4$DegreeDiscipline <- gsub("\\(C2006_A", "", rawUNOTREDAME4$DegreeDiscipline)
rawUNOTREDAME4$DegreeDiscipline <- gsub("\\First major", "", rawUNOTREDAME4$DegreeDiscipline)
rawUNOTREDAME4$DegreeDiscipline <- gsub("\\Second major", "", rawUNOTREDAME4$DegreeDiscipline)

rawUNOTREDAME4 <- rawUNOTREDAME4 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUNOTREDAME5 <- t(read_csv("RawUNOTREDAME5.csv"))
rawUNOTREDAME5 <- cbind(rownames(rawUNOTREDAME5), rawUNOTREDAME5)
rownames(rawUNOTREDAME5) <- NULL
rawUNOTREDAME5 <- data.frame(DegreeDiscipline = rawUNOTREDAME5)
colnames(rawUNOTREDAME5) <- c("DegreeDiscipline","Total")
rawUNOTREDAME5$DegreeDiscipline <- gsub("\\(C2005_A", "", rawUNOTREDAME5$DegreeDiscipline)
rawUNOTREDAME5$DegreeDiscipline <- gsub("\\First major", "", rawUNOTREDAME5$DegreeDiscipline)
rawUNOTREDAME5$DegreeDiscipline <- gsub("\\Second major", "", rawUNOTREDAME5$DegreeDiscipline)

rawUNOTREDAME5 <- rawUNOTREDAME5 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUNOTREDAME6 <- t(read_csv("RawUNOTREDAME6.csv"))
rawUNOTREDAME6 <- cbind(rownames(rawUNOTREDAME6), rawUNOTREDAME6)
rownames(rawUNOTREDAME6) <- NULL
rawUNOTREDAME6 <- data.frame(DegreeDiscipline = rawUNOTREDAME6)
colnames(rawUNOTREDAME6) <- c("DegreeDiscipline","Total")
rawUNOTREDAME6$DegreeDiscipline <- gsub("\\(C2004_A", "", rawUNOTREDAME6$DegreeDiscipline)
rawUNOTREDAME6$DegreeDiscipline <- gsub("\\First major", "", rawUNOTREDAME6$DegreeDiscipline)
rawUNOTREDAME6$DegreeDiscipline <- gsub("\\Second major", "", rawUNOTREDAME6$DegreeDiscipline)

rawUNOTREDAME6 <- rawUNOTREDAME6 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUNOTREDAME7 <- t(read_csv("RawUNOTREDAME7.csv"))
rawUNOTREDAME7 <- cbind(rownames(rawUNOTREDAME7), rawUNOTREDAME7)
rownames(rawUNOTREDAME7) <- NULL
rawUNOTREDAME7 <- data.frame(DegreeDiscipline = rawUNOTREDAME7)
colnames(rawUNOTREDAME7) <- c("DegreeDiscipline","Total")
rawUNOTREDAME7$DegreeDiscipline <- gsub("\\(C2003_A", "", rawUNOTREDAME7$DegreeDiscipline)
rawUNOTREDAME7$DegreeDiscipline <- gsub("\\First major", "", rawUNOTREDAME7$DegreeDiscipline)
rawUNOTREDAME7$DegreeDiscipline <- gsub("\\Second major", "", rawUNOTREDAME7$DegreeDiscipline)

rawUNOTREDAME7 <- rawUNOTREDAME7 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUNOTREDAME <- left_join(rawUNOTREDAME1, rawUNOTREDAME2, by = "DegreeDiscipline") %>%
  left_join(rawUNOTREDAME3, by = "DegreeDiscipline") %>%
  left_join(rawUNOTREDAME4, by = "DegreeDiscipline") %>%
  left_join(rawUNOTREDAME5, by = "DegreeDiscipline") %>%
  left_join(rawUNOTREDAME6, by = "DegreeDiscipline") %>%
  left_join(rawUNOTREDAME7, by = "DegreeDiscipline")

colnames(rawUNOTREDAME) <- c("DegreeDiscipline", "Yr1", "Yr2", "Yr3", "Yr4", "Yr5", "Yr6", "Yr7")
rawUNOTREDAME <- rawUNOTREDAME %>%
  mutate(across(Yr1:Yr7, ~ parse_number(as.character(.x)))) %>%
  rowwise() %>%
  mutate(Total = sum(c_across(Yr1:Yr7), na.rm = TRUE)) %>%
  ungroup()
rawUNOTREDAME <- rawUNOTREDAME[-109,]

rm(rawUNOTREDAME1)
rm(rawUNOTREDAME2)
rm(rawUNOTREDAME3)
rm(rawUNOTREDAME4)
rm(rawUNOTREDAME5)
rm(rawUNOTREDAME6)
rm(rawUNOTREDAME7)

rawUPENN1 <- t(read_csv("RawUPENN1.csv"))
rawUPENN1 <- cbind(rownames(rawUPENN1), rawUPENN1)
rownames(rawUPENN1) <- NULL
rawUPENN1 <- data.frame(DegreeDiscipline = rawUPENN1)
colnames(rawUPENN1) <- c("DegreeDiscipline","Total")
rawUPENN1$DegreeDiscipline <- gsub("\\(C2009_A", "", rawUPENN1$DegreeDiscipline)
rawUPENN1$DegreeDiscipline <- gsub("\\First major", "", rawUPENN1$DegreeDiscipline)
rawUPENN1$DegreeDiscipline <- gsub("\\Second major", "", rawUPENN1$DegreeDiscipline)

rawUPENN1 <- rawUPENN1 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUPENN2 <- t(read_csv("RawUPENN2.csv"))
rawUPENN2 <- cbind(rownames(rawUPENN2), rawUPENN2)
rownames(rawUPENN2) <- NULL
rawUPENN2 <- data.frame(DegreeDiscipline = rawUPENN2)
colnames(rawUPENN2) <- c("DegreeDiscipline","Total")
rawUPENN2$DegreeDiscipline <- gsub("\\(C2008_A", "", rawUPENN2$DegreeDiscipline)
rawUPENN2$DegreeDiscipline <- gsub("\\First major", "", rawUPENN2$DegreeDiscipline)
rawUPENN2$DegreeDiscipline <- gsub("\\Second major", "", rawUPENN2$DegreeDiscipline)

rawUPENN2 <- rawUPENN2 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUPENN3 <- t(read_csv("RawUPENN3.csv"))
rawUPENN3 <- cbind(rownames(rawUPENN3), rawUPENN3)
rownames(rawUPENN3) <- NULL
rawUPENN3 <- data.frame(DegreeDiscipline = rawUPENN3)
colnames(rawUPENN3) <- c("DegreeDiscipline","Total")
rawUPENN3$DegreeDiscipline <- gsub("\\(C2007_A", "", rawUPENN3$DegreeDiscipline)
rawUPENN3$DegreeDiscipline <- gsub("\\First major", "", rawUPENN3$DegreeDiscipline)
rawUPENN3$DegreeDiscipline <- gsub("\\Second major", "", rawUPENN3$DegreeDiscipline)

rawUPENN3 <- rawUPENN3 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUPENN4 <- t(read_csv("RawUPENN4.csv"))
rawUPENN4 <- cbind(rownames(rawUPENN4), rawUPENN4)
rownames(rawUPENN4) <- NULL
rawUPENN4 <- data.frame(DegreeDiscipline = rawUPENN4)
colnames(rawUPENN4) <- c("DegreeDiscipline","Total")
rawUPENN4$DegreeDiscipline <- gsub("\\(C2006_A", "", rawUPENN4$DegreeDiscipline)
rawUPENN4$DegreeDiscipline <- gsub("\\First major", "", rawUPENN4$DegreeDiscipline)
rawUPENN4$DegreeDiscipline <- gsub("\\Second major", "", rawUPENN4$DegreeDiscipline)

rawUPENN4 <- rawUPENN4 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUPENN5 <- t(read_csv("RawUPENN5.csv"))
rawUPENN5 <- cbind(rownames(rawUPENN5), rawUPENN5)
rownames(rawUPENN5) <- NULL
rawUPENN5 <- data.frame(DegreeDiscipline = rawUPENN5)
colnames(rawUPENN5) <- c("DegreeDiscipline","Total")
rawUPENN5$DegreeDiscipline <- gsub("\\(C2005_A", "", rawUPENN5$DegreeDiscipline)
rawUPENN5$DegreeDiscipline <- gsub("\\First major", "", rawUPENN5$DegreeDiscipline)
rawUPENN5$DegreeDiscipline <- gsub("\\Second major", "", rawUPENN5$DegreeDiscipline)

rawUPENN5 <- rawUPENN5 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUPENN6 <- t(read_csv("RawUPENN6.csv"))
rawUPENN6 <- cbind(rownames(rawUPENN6), rawUPENN6)
rownames(rawUPENN6) <- NULL
rawUPENN6 <- data.frame(DegreeDiscipline = rawUPENN6)
colnames(rawUPENN6) <- c("DegreeDiscipline","Total")
rawUPENN6$DegreeDiscipline <- gsub("\\(C2004_A", "", rawUPENN6$DegreeDiscipline)
rawUPENN6$DegreeDiscipline <- gsub("\\First major", "", rawUPENN6$DegreeDiscipline)
rawUPENN6$DegreeDiscipline <- gsub("\\Second major", "", rawUPENN6$DegreeDiscipline)

rawUPENN6 <- rawUPENN6 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUPENN7 <- t(read_csv("RawUPENN7.csv"))
rawUPENN7 <- cbind(rownames(rawUPENN7), rawUPENN7)
rownames(rawUPENN7) <- NULL
rawUPENN7 <- data.frame(DegreeDiscipline = rawUPENN7)
colnames(rawUPENN7) <- c("DegreeDiscipline","Total")
rawUPENN7$DegreeDiscipline <- gsub("\\(C2003_A", "", rawUPENN7$DegreeDiscipline)
rawUPENN7$DegreeDiscipline <- gsub("\\First major", "", rawUPENN7$DegreeDiscipline)
rawUPENN7$DegreeDiscipline <- gsub("\\Second major", "", rawUPENN7$DegreeDiscipline)

rawUPENN7 <- rawUPENN7 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawUPENN <- left_join(rawUPENN1, rawUPENN2, by = "DegreeDiscipline") %>%
  left_join(rawUPENN3, by = "DegreeDiscipline") %>%
  left_join(rawUPENN4, by = "DegreeDiscipline") %>%
  left_join(rawUPENN5, by = "DegreeDiscipline") %>%
  left_join(rawUPENN6, by = "DegreeDiscipline") %>%
  left_join(rawUPENN7, by = "DegreeDiscipline")

colnames(rawUPENN) <- c("DegreeDiscipline", "Yr1", "Yr2", "Yr3", "Yr4", "Yr5", "Yr6", "Yr7")
rawUPENN <- rawUPENN %>%
  mutate(across(Yr1:Yr7, ~ parse_number(as.character(.x)))) %>%
  rowwise() %>%
  mutate(Total = sum(c_across(Yr1:Yr7), na.rm = TRUE)) %>%
  ungroup()
rawUPENN <- rawUPENN[-109,]

rm(rawUPENN1)
rm(rawUPENN2)
rm(rawUPENN3)
rm(rawUPENN4)
rm(rawUPENN5)
rm(rawUPENN6)
rm(rawUPENN7)

rawVANDERBILT1 <- t(read_csv("RawVANDERBILT1.csv"))
rawVANDERBILT1 <- cbind(rownames(rawVANDERBILT1), rawVANDERBILT1)
rownames(rawVANDERBILT1) <- NULL
rawVANDERBILT1 <- data.frame(DegreeDiscipline = rawVANDERBILT1)
colnames(rawVANDERBILT1) <- c("DegreeDiscipline","Total")
rawVANDERBILT1$DegreeDiscipline <- gsub("\\(C2009_A", "", rawVANDERBILT1$DegreeDiscipline)
rawVANDERBILT1$DegreeDiscipline <- gsub("\\First major", "", rawVANDERBILT1$DegreeDiscipline)
rawVANDERBILT1$DegreeDiscipline <- gsub("\\Second major", "", rawVANDERBILT1$DegreeDiscipline)

rawVANDERBILT1 <- rawVANDERBILT1 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawVANDERBILT2 <- t(read_csv("RawVANDERBILT2.csv"))
rawVANDERBILT2 <- cbind(rownames(rawVANDERBILT2), rawVANDERBILT2)
rownames(rawVANDERBILT2) <- NULL
rawVANDERBILT2 <- data.frame(DegreeDiscipline = rawVANDERBILT2)
colnames(rawVANDERBILT2) <- c("DegreeDiscipline","Total")
rawVANDERBILT2$DegreeDiscipline <- gsub("\\(C2008_A", "", rawVANDERBILT2$DegreeDiscipline)
rawVANDERBILT2$DegreeDiscipline <- gsub("\\First major", "", rawVANDERBILT2$DegreeDiscipline)
rawVANDERBILT2$DegreeDiscipline <- gsub("\\Second major", "", rawVANDERBILT2$DegreeDiscipline)

rawVANDERBILT2 <- rawVANDERBILT2 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawVANDERBILT3 <- t(read_csv("RawVANDERBILT3.csv"))
rawVANDERBILT3 <- cbind(rownames(rawVANDERBILT3), rawVANDERBILT3)
rownames(rawVANDERBILT3) <- NULL
rawVANDERBILT3 <- data.frame(DegreeDiscipline = rawVANDERBILT3)
colnames(rawVANDERBILT3) <- c("DegreeDiscipline","Total")
rawVANDERBILT3$DegreeDiscipline <- gsub("\\(C2007_A", "", rawVANDERBILT3$DegreeDiscipline)
rawVANDERBILT3$DegreeDiscipline <- gsub("\\First major", "", rawVANDERBILT3$DegreeDiscipline)
rawVANDERBILT3$DegreeDiscipline <- gsub("\\Second major", "", rawVANDERBILT3$DegreeDiscipline)

rawVANDERBILT3 <- rawVANDERBILT3 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawVANDERBILT4 <- t(read_csv("RawVANDERBILT4.csv"))
rawVANDERBILT4 <- cbind(rownames(rawVANDERBILT4), rawVANDERBILT4)
rownames(rawVANDERBILT4) <- NULL
rawVANDERBILT4 <- data.frame(DegreeDiscipline = rawVANDERBILT4)
colnames(rawVANDERBILT4) <- c("DegreeDiscipline","Total")
rawVANDERBILT4$DegreeDiscipline <- gsub("\\(C2006_A", "", rawVANDERBILT4$DegreeDiscipline)
rawVANDERBILT4$DegreeDiscipline <- gsub("\\First major", "", rawVANDERBILT4$DegreeDiscipline)
rawVANDERBILT4$DegreeDiscipline <- gsub("\\Second major", "", rawVANDERBILT4$DegreeDiscipline)

rawVANDERBILT4 <- rawVANDERBILT4 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawVANDERBILT5 <- t(read_csv("RawVANDERBILT5.csv"))
rawVANDERBILT5 <- cbind(rownames(rawVANDERBILT5), rawVANDERBILT5)
rownames(rawVANDERBILT5) <- NULL
rawVANDERBILT5 <- data.frame(DegreeDiscipline = rawVANDERBILT5)
colnames(rawVANDERBILT5) <- c("DegreeDiscipline","Total")
rawVANDERBILT5$DegreeDiscipline <- gsub("\\(C2005_A", "", rawVANDERBILT5$DegreeDiscipline)
rawVANDERBILT5$DegreeDiscipline <- gsub("\\First major", "", rawVANDERBILT5$DegreeDiscipline)
rawVANDERBILT5$DegreeDiscipline <- gsub("\\Second major", "", rawVANDERBILT5$DegreeDiscipline)

rawVANDERBILT5 <- rawVANDERBILT5 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawVANDERBILT6 <- t(read_csv("RawVANDERBILT6.csv"))
rawVANDERBILT6 <- cbind(rownames(rawVANDERBILT6), rawVANDERBILT6)
rownames(rawVANDERBILT6) <- NULL
rawVANDERBILT6 <- data.frame(DegreeDiscipline = rawVANDERBILT6)
colnames(rawVANDERBILT6) <- c("DegreeDiscipline","Total")
rawVANDERBILT6$DegreeDiscipline <- gsub("\\(C2004_A", "", rawVANDERBILT6$DegreeDiscipline)
rawVANDERBILT6$DegreeDiscipline <- gsub("\\First major", "", rawVANDERBILT6$DegreeDiscipline)
rawVANDERBILT6$DegreeDiscipline <- gsub("\\Second major", "", rawVANDERBILT6$DegreeDiscipline)

rawVANDERBILT6 <- rawVANDERBILT6 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawVANDERBILT7 <- t(read_csv("RawVANDERBILT7.csv"))
rawVANDERBILT7 <- cbind(rownames(rawVANDERBILT7), rawVANDERBILT7)
rownames(rawVANDERBILT7) <- NULL
rawVANDERBILT7 <- data.frame(DegreeDiscipline = rawVANDERBILT7)
colnames(rawVANDERBILT7) <- c("DegreeDiscipline","Total")
rawVANDERBILT7$DegreeDiscipline <- gsub("\\(C2003_A", "", rawVANDERBILT7$DegreeDiscipline)
rawVANDERBILT7$DegreeDiscipline <- gsub("\\First major", "", rawVANDERBILT7$DegreeDiscipline)
rawVANDERBILT7$DegreeDiscipline <- gsub("\\Second major", "", rawVANDERBILT7$DegreeDiscipline)

rawVANDERBILT7 <- rawVANDERBILT7 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawVANDERBILT <- left_join(rawVANDERBILT1, rawVANDERBILT2, by = "DegreeDiscipline") %>%
  left_join(rawVANDERBILT3, by = "DegreeDiscipline") %>%
  left_join(rawVANDERBILT4, by = "DegreeDiscipline") %>%
  left_join(rawVANDERBILT5, by = "DegreeDiscipline") %>%
  left_join(rawVANDERBILT6, by = "DegreeDiscipline") %>%
  left_join(rawVANDERBILT7, by = "DegreeDiscipline")

colnames(rawVANDERBILT) <- c("DegreeDiscipline", "Yr1", "Yr2", "Yr3", "Yr4", "Yr5", "Yr6", "Yr7")
rawVANDERBILT <- rawVANDERBILT %>%
  mutate(across(Yr1:Yr7, ~ parse_number(as.character(.x)))) %>%
  rowwise() %>%
  mutate(Total = sum(c_across(Yr1:Yr7), na.rm = TRUE)) %>%
  ungroup()
rawVANDERBILT <- rawVANDERBILT[-109,]

rm(rawVANDERBILT1)
rm(rawVANDERBILT2)
rm(rawVANDERBILT3)
rm(rawVANDERBILT4)
rm(rawVANDERBILT5)
rm(rawVANDERBILT6)
rm(rawVANDERBILT7)

rawWUSTLOUIS1 <- t(read_csv("RawWUSTLOUIS1.csv"))
rawWUSTLOUIS1 <- cbind(rownames(rawWUSTLOUIS1), rawWUSTLOUIS1)
rownames(rawWUSTLOUIS1) <- NULL
rawWUSTLOUIS1 <- data.frame(DegreeDiscipline = rawWUSTLOUIS1)
colnames(rawWUSTLOUIS1) <- c("DegreeDiscipline","Total")
rawWUSTLOUIS1$DegreeDiscipline <- gsub("\\(C2009_A", "", rawWUSTLOUIS1$DegreeDiscipline)
rawWUSTLOUIS1$DegreeDiscipline <- gsub("\\First major", "", rawWUSTLOUIS1$DegreeDiscipline)
rawWUSTLOUIS1$DegreeDiscipline <- gsub("\\Second major", "", rawWUSTLOUIS1$DegreeDiscipline)

rawWUSTLOUIS1 <- rawWUSTLOUIS1 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawWUSTLOUIS2 <- t(read_csv("RawWUSTLOUIS2.csv"))
rawWUSTLOUIS2 <- cbind(rownames(rawWUSTLOUIS2), rawWUSTLOUIS2)
rownames(rawWUSTLOUIS2) <- NULL
rawWUSTLOUIS2 <- data.frame(DegreeDiscipline = rawWUSTLOUIS2)
colnames(rawWUSTLOUIS2) <- c("DegreeDiscipline","Total")
rawWUSTLOUIS2$DegreeDiscipline <- gsub("\\(C2008_A", "", rawWUSTLOUIS2$DegreeDiscipline)
rawWUSTLOUIS2$DegreeDiscipline <- gsub("\\First major", "", rawWUSTLOUIS2$DegreeDiscipline)
rawWUSTLOUIS2$DegreeDiscipline <- gsub("\\Second major", "", rawWUSTLOUIS2$DegreeDiscipline)

rawWUSTLOUIS2 <- rawWUSTLOUIS2 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawWUSTLOUIS3 <- t(read_csv("RawWUSTLOUIS3.csv"))
rawWUSTLOUIS3 <- cbind(rownames(rawWUSTLOUIS3), rawWUSTLOUIS3)
rownames(rawWUSTLOUIS3) <- NULL
rawWUSTLOUIS3 <- data.frame(DegreeDiscipline = rawWUSTLOUIS3)
colnames(rawWUSTLOUIS3) <- c("DegreeDiscipline","Total")
rawWUSTLOUIS3$DegreeDiscipline <- gsub("\\(C2007_A", "", rawWUSTLOUIS3$DegreeDiscipline)
rawWUSTLOUIS3$DegreeDiscipline <- gsub("\\First major", "", rawWUSTLOUIS3$DegreeDiscipline)
rawWUSTLOUIS3$DegreeDiscipline <- gsub("\\Second major", "", rawWUSTLOUIS3$DegreeDiscipline)

rawWUSTLOUIS3 <- rawWUSTLOUIS3 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawWUSTLOUIS4 <- t(read_csv("RawWUSTLOUIS4.csv"))
rawWUSTLOUIS4 <- cbind(rownames(rawWUSTLOUIS4), rawWUSTLOUIS4)
rownames(rawWUSTLOUIS4) <- NULL
rawWUSTLOUIS4 <- data.frame(DegreeDiscipline = rawWUSTLOUIS4)
colnames(rawWUSTLOUIS4) <- c("DegreeDiscipline","Total")
rawWUSTLOUIS4$DegreeDiscipline <- gsub("\\(C2006_A", "", rawWUSTLOUIS4$DegreeDiscipline)
rawWUSTLOUIS4$DegreeDiscipline <- gsub("\\First major", "", rawWUSTLOUIS4$DegreeDiscipline)
rawWUSTLOUIS4$DegreeDiscipline <- gsub("\\Second major", "", rawWUSTLOUIS4$DegreeDiscipline)

rawWUSTLOUIS4 <- rawWUSTLOUIS4 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawWUSTLOUIS5 <- t(read_csv("RawWUSTLOUIS5.csv"))
rawWUSTLOUIS5 <- cbind(rownames(rawWUSTLOUIS5), rawWUSTLOUIS5)
rownames(rawWUSTLOUIS5) <- NULL
rawWUSTLOUIS5 <- data.frame(DegreeDiscipline = rawWUSTLOUIS5)
colnames(rawWUSTLOUIS5) <- c("DegreeDiscipline","Total")
rawWUSTLOUIS5$DegreeDiscipline <- gsub("\\(C2005_A", "", rawWUSTLOUIS5$DegreeDiscipline)
rawWUSTLOUIS5$DegreeDiscipline <- gsub("\\First major", "", rawWUSTLOUIS5$DegreeDiscipline)
rawWUSTLOUIS5$DegreeDiscipline <- gsub("\\Second major", "", rawWUSTLOUIS5$DegreeDiscipline)

rawWUSTLOUIS5 <- rawWUSTLOUIS5 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawWUSTLOUIS6 <- t(read_csv("RawWUSTLOUIS6.csv"))
rawWUSTLOUIS6 <- cbind(rownames(rawWUSTLOUIS6), rawWUSTLOUIS6)
rownames(rawWUSTLOUIS6) <- NULL
rawWUSTLOUIS6 <- data.frame(DegreeDiscipline = rawWUSTLOUIS6)
colnames(rawWUSTLOUIS6) <- c("DegreeDiscipline","Total")
rawWUSTLOUIS6$DegreeDiscipline <- gsub("\\(C2004_A", "", rawWUSTLOUIS6$DegreeDiscipline)
rawWUSTLOUIS6$DegreeDiscipline <- gsub("\\First major", "", rawWUSTLOUIS6$DegreeDiscipline)
rawWUSTLOUIS6$DegreeDiscipline <- gsub("\\Second major", "", rawWUSTLOUIS6$DegreeDiscipline)

rawWUSTLOUIS6 <- rawWUSTLOUIS6 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawWUSTLOUIS7 <- t(read_csv("RawWUSTLOUIS7.csv"))
rawWUSTLOUIS7 <- cbind(rownames(rawWUSTLOUIS7), rawWUSTLOUIS7)
rownames(rawWUSTLOUIS7) <- NULL
rawWUSTLOUIS7 <- data.frame(DegreeDiscipline = rawWUSTLOUIS7)
colnames(rawWUSTLOUIS7) <- c("DegreeDiscipline","Total")
rawWUSTLOUIS7$DegreeDiscipline <- gsub("\\(C2003_A", "", rawWUSTLOUIS7$DegreeDiscipline)
rawWUSTLOUIS7$DegreeDiscipline <- gsub("\\First major", "", rawWUSTLOUIS7$DegreeDiscipline)
rawWUSTLOUIS7$DegreeDiscipline <- gsub("\\Second major", "", rawWUSTLOUIS7$DegreeDiscipline)

rawWUSTLOUIS7 <- rawWUSTLOUIS7 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawWUSTLOUIS <- left_join(rawWUSTLOUIS1, rawWUSTLOUIS2, by = "DegreeDiscipline") %>%
  left_join(rawWUSTLOUIS3, by = "DegreeDiscipline") %>%
  left_join(rawWUSTLOUIS4, by = "DegreeDiscipline") %>%
  left_join(rawWUSTLOUIS5, by = "DegreeDiscipline") %>%
  left_join(rawWUSTLOUIS6, by = "DegreeDiscipline") %>%
  left_join(rawWUSTLOUIS7, by = "DegreeDiscipline")

colnames(rawWUSTLOUIS) <- c("DegreeDiscipline", "Yr1", "Yr2", "Yr3", "Yr4", "Yr5", "Yr6", "Yr7")
rawWUSTLOUIS <- rawWUSTLOUIS %>%
  mutate(across(Yr1:Yr7, ~ parse_number(as.character(.x)))) %>%
  rowwise() %>%
  mutate(Total = sum(c_across(Yr1:Yr7), na.rm = TRUE)) %>%
  ungroup()
rawWUSTLOUIS <- rawWUSTLOUIS[-109,]

rm(rawWUSTLOUIS1)
rm(rawWUSTLOUIS2)
rm(rawWUSTLOUIS3)
rm(rawWUSTLOUIS4)
rm(rawWUSTLOUIS5)
rm(rawWUSTLOUIS6)
rm(rawWUSTLOUIS7)

rawYALE1 <- t(read_csv("RawYALE1.csv"))
rawYALE1 <- cbind(rownames(rawYALE1), rawYALE1)
rownames(rawYALE1) <- NULL
rawYALE1 <- data.frame(DegreeDiscipline = rawYALE1)
colnames(rawYALE1) <- c("DegreeDiscipline","Total")
rawYALE1$DegreeDiscipline <- gsub("\\(C2009_A", "", rawYALE1$DegreeDiscipline)
rawYALE1$DegreeDiscipline <- gsub("\\First major", "", rawYALE1$DegreeDiscipline)
rawYALE1$DegreeDiscipline <- gsub("\\Second major", "", rawYALE1$DegreeDiscipline)

rawYALE1 <- rawYALE1 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawYALE2 <- t(read_csv("RawYALE2.csv"))
rawYALE2 <- cbind(rownames(rawYALE2), rawYALE2)
rownames(rawYALE2) <- NULL
rawYALE2 <- data.frame(DegreeDiscipline = rawYALE2)
colnames(rawYALE2) <- c("DegreeDiscipline","Total")
rawYALE2$DegreeDiscipline <- gsub("\\(C2008_A", "", rawYALE2$DegreeDiscipline)
rawYALE2$DegreeDiscipline <- gsub("\\First major", "", rawYALE2$DegreeDiscipline)
rawYALE2$DegreeDiscipline <- gsub("\\Second major", "", rawYALE2$DegreeDiscipline)

rawYALE2 <- rawYALE2 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawYALE3 <- t(read_csv("RawYALE3.csv"))
rawYALE3 <- cbind(rownames(rawYALE3), rawYALE3)
rownames(rawYALE3) <- NULL
rawYALE3 <- data.frame(DegreeDiscipline = rawYALE3)
colnames(rawYALE3) <- c("DegreeDiscipline","Total")
rawYALE3$DegreeDiscipline <- gsub("\\(C2007_A", "", rawYALE3$DegreeDiscipline)
rawYALE3$DegreeDiscipline <- gsub("\\First major", "", rawYALE3$DegreeDiscipline)
rawYALE3$DegreeDiscipline <- gsub("\\Second major", "", rawYALE3$DegreeDiscipline)

rawYALE3 <- rawYALE3 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawYALE4 <- t(read_csv("RawYALE4.csv"))
rawYALE4 <- cbind(rownames(rawYALE4), rawYALE4)
rownames(rawYALE4) <- NULL
rawYALE4 <- data.frame(DegreeDiscipline = rawYALE4)
colnames(rawYALE4) <- c("DegreeDiscipline","Total")
rawYALE4$DegreeDiscipline <- gsub("\\(C2006_A", "", rawYALE4$DegreeDiscipline)
rawYALE4$DegreeDiscipline <- gsub("\\First major", "", rawYALE4$DegreeDiscipline)
rawYALE4$DegreeDiscipline <- gsub("\\Second major", "", rawYALE4$DegreeDiscipline)

rawYALE4 <- rawYALE4 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawYALE5 <- t(read_csv("RawYALE5.csv"))
rawYALE5 <- cbind(rownames(rawYALE5), rawYALE5)
rownames(rawYALE5) <- NULL
rawYALE5 <- data.frame(DegreeDiscipline = rawYALE5)
colnames(rawYALE5) <- c("DegreeDiscipline","Total")
rawYALE5$DegreeDiscipline <- gsub("\\(C2005_A", "", rawYALE5$DegreeDiscipline)
rawYALE5$DegreeDiscipline <- gsub("\\First major", "", rawYALE5$DegreeDiscipline)
rawYALE5$DegreeDiscipline <- gsub("\\Second major", "", rawYALE5$DegreeDiscipline)

rawYALE5 <- rawYALE5 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawYALE6 <- t(read_csv("RawYALE6.csv"))
rawYALE6 <- cbind(rownames(rawYALE6), rawYALE6)
rownames(rawYALE6) <- NULL
rawYALE6 <- data.frame(DegreeDiscipline = rawYALE6)
colnames(rawYALE6) <- c("DegreeDiscipline","Total")
rawYALE6$DegreeDiscipline <- gsub("\\(C2004_A", "", rawYALE6$DegreeDiscipline)
rawYALE6$DegreeDiscipline <- gsub("\\First major", "", rawYALE6$DegreeDiscipline)
rawYALE6$DegreeDiscipline <- gsub("\\Second major", "", rawYALE6$DegreeDiscipline)

rawYALE6 <- rawYALE6 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawYALE7 <- t(read_csv("RawYALE7.csv"))
rawYALE7 <- cbind(rownames(rawYALE7), rawYALE7)
rownames(rawYALE7) <- NULL
rawYALE7 <- data.frame(DegreeDiscipline = rawYALE7)
colnames(rawYALE7) <- c("DegreeDiscipline","Total")
rawYALE7$DegreeDiscipline <- gsub("\\(C2003_A", "", rawYALE7$DegreeDiscipline)
rawYALE7$DegreeDiscipline <- gsub("\\First major", "", rawYALE7$DegreeDiscipline)
rawYALE7$DegreeDiscipline <- gsub("\\Second major", "", rawYALE7$DegreeDiscipline)

rawYALE7 <- rawYALE7 %>%
  mutate(Total = as.numeric(Total)) %>% 
  group_by(DegreeDiscipline) %>%
  summarize(TotalSum = sum(Total, na.rm = TRUE))

rawYALE <- left_join(rawYALE1, rawYALE2, by = "DegreeDiscipline") %>%
  left_join(rawYALE3, by = "DegreeDiscipline") %>%
  left_join(rawYALE4, by = "DegreeDiscipline") %>%
  left_join(rawYALE5, by = "DegreeDiscipline") %>%
  left_join(rawYALE6, by = "DegreeDiscipline") %>%
  left_join(rawYALE7, by = "DegreeDiscipline")

colnames(rawYALE) <- c("DegreeDiscipline", "Yr1", "Yr2", "Yr3", "Yr4", "Yr5", "Yr6", "Yr7")
rawYALE <- rawYALE %>%
  mutate(across(Yr1:Yr7, ~ parse_number(as.character(.x)))) %>%
  rowwise() %>%
  mutate(Total = sum(c_across(Yr1:Yr7), na.rm = TRUE)) %>%
  ungroup()
rawYALE <- rawYALE[-109,]

rm(rawYALE1)
rm(rawYALE2)
rm(rawYALE3)
rm(rawYALE4)
rm(rawYALE5)
rm(rawYALE6)
rm(rawYALE7)

# Select only the first and ninth columns from each university data frame and overwrite the original dataframe.
rawbrown <- rawbrown[,c(1, 9)]
rawcaltech <- rawcaltech[,c(1, 9)]
rawcarnegiemellon <- rawcarnegiemellon[,c(1, 9)]
rawcolumbia <- rawcolumbia[,c(1, 9)]
rawcornell <- rawcornell[,c(1, 9)]
rawdartmouth <- rawdartmouth[,c(1, 9)]
rawduke <- rawduke[,c(1, 9)]
rawharvard <- rawharvard[,c(1, 9)]
rawjohnshopkins <- rawjohnshopkins[,c(1, 9)]
rawmit <- rawmit[,c(1, 9)]
rawnorthwestern <- rawnorthwestern[,c(1, 9)]
rawnyu <- rawnyu[,c(1, 9)]
rawPrinceton <- rawPrinceton[,c(1, 9)]
rawRice <- rawRice[,c(1, 9)]
rawStanford <- rawStanford[,c(1, 9)]
rawUCB <- rawUCB[,c(1, 9)]
rawUCSD <- rawUCSD[,c(1, 9)]
rawUMANNARBOR <- rawUMANNARBOR[,c(1, 9)]
rawUNOTREDAME <- rawUNOTREDAME[,c(1, 9)]
rawUPENN <- rawUPENN[,c(1, 9)]
rawVANDERBILT <- rawVANDERBILT[,c(1, 9)]
rawWUSTLOUIS <- rawWUSTLOUIS[,c(1, 9)]
rawYALE <- rawYALE[,c(1, 9)]
rawUCHICAGO <- rawUCHICAGO[,c(1, 9)]
rawUCLA <- rawUCLA[,c(1, 9)]

# Add a new column with the name of the university to each data frame (e.g., "Brown", "Caltech", etc.).
rawbrown <- cbind("Brown", rawbrown)
rawcaltech <- cbind("Caltech", rawcaltech)
rawcarnegiemellon <- cbind("CarnegieMellon", rawcarnegiemellon)
rawcolumbia <- cbind("Columbia", rawcolumbia)
rawcornell <- cbind("Cornell", rawcornell)
rawdartmouth <- cbind("Dartmouth", rawdartmouth)
rawduke <- cbind("Duke", rawduke)
rawharvard <- cbind("Harvard", rawharvard)
rawjohnshopkins <- cbind("JohnsHopkins", rawjohnshopkins)
rawmit <- cbind("MIT", rawmit)
rawnorthwestern <- cbind("Northwestern", rawnorthwestern)
rawnyu <- cbind("NYU", rawnyu)
rawPrinceton <- cbind("Princeton", rawPrinceton)
rawRice <- cbind("Rice", rawRice)
rawStanford <- cbind("Stanford", rawStanford)
rawUCB <- cbind("UC-Berkeley", rawUCB)
rawUCSD <- cbind("UC-SanDiego", rawUCSD)
rawUMANNARBOR <- cbind("UM-AnnArbor", rawUMANNARBOR)
rawUNOTREDAME <- cbind("UNotreDame", rawUNOTREDAME)
rawUPENN <- cbind("UPenn", rawUPENN)
rawVANDERBILT <- cbind("Vanderbilt", rawVANDERBILT)
rawWUSTLOUIS <- cbind("WU-St.Louis", rawWUSTLOUIS)
rawYALE <- cbind("Yale", rawYALE)
rawUCHICAGO <- cbind("UChicago", rawUCHICAGO)
rawUCLA <- cbind("UC-LosAngeles", rawUCLA)

# Consolidate everything into one file.
# Create a list of dataframes to join and store the correct column_names
data_frames <- list(rawbrown, rawcaltech, rawcarnegiemellon, rawcolumbia, rawcornell, rawdartmouth, rawduke,
                    rawharvard, rawjohnshopkins, rawmit, rawnorthwestern, rawnyu, rawPrinceton, rawRice,
                    rawStanford, rawUCB, rawUCHICAGO, rawUCLA, rawUCSD, rawUMANNARBOR, rawUNOTREDAME, rawUPENN,
                    rawVANDERBILT, rawWUSTLOUIS, rawYALE)
column_names <- colnames(data_frames[[1]])

# Loop through the list of data frames and set column names
for (i in 1:length(data_frames)) {
  colnames(data_frames[[i]]) <- column_names
}

# Combine the data frames vertically
degrees0209 <- bind_rows(data_frames)

# Modify the DegreeDiscipline column for consistency
degrees0209$DegreeDiscipline <- gsub("\\(C2009_A", "", degrees0209$DegreeDiscipline)

# Create a sample data frame for DegreeDiscipline
sample <- data.frame(degrees <- degrees0209$DegreeDiscipline)
colnames(sample) <- "DegreeDiscipline"

# Separate DegreeDiscipline into Gender and DegreeDisciplineName
temp <- separate(sample, DegreeDiscipline, into = c("Gender", "DegreeDisciplineName"), sep = "     ")
rm(sample)

# Combine temp with degrees0209 and remove an unneeded column
degrees0209 <- cbind(temp,degrees0209)
rm(temp)
degrees0209 <- degrees0209[,-4]

# Update its column names and reorder
colnames(degrees0209) <- c("Gender", "DegreeDisciplineName", "Institution", "Total")
degrees0209 <- select(degrees0209, Institution, DegreeDisciplineName, Gender, Total)

# Calculate TotalFemale for each Institution and DegreeDisciplineName
test <- degrees0209 %>%
  group_by(Institution, DegreeDisciplineName) %>%
  summarise(TotalFemale = sum(Total[Gender == "Grand total women"]))

# Left join test with degrees0209 to add TotalFemale and remove an unneeded column
testdegrees0209 <- degrees0209 %>%
  left_join(test, by = c("Institution", "DegreeDisciplineName")) %>%
  distinct(Institution, DegreeDisciplineName, .keep_all = TRUE)
degrees0209 <- testdegrees0209[,-3]
colnames(degrees0209) <- c("Institution", "DegreeDisciplineName", "Total", "TotalFemale")
rm(test)
rm(testdegrees0209)

# Calculate PercentFemale and PercentMale
degrees0209 <- degrees0209 %>% group_by(Institution,DegreeDisciplineName) %>%
  mutate(PercentFemale = round((TotalFemale/Total)*100,0)) %>%
  mutate(PercentMale = 100-PercentFemale)

# Add the AcademicYear column
degrees0209 <- cbind(degrees0209,"2002-2009")
colnames(degrees0209) <- c("Institution", "DegreeDiscipline", "Total", "TotalFemale", "PercentFemale", "PercentMale", "AcademicYear")

# For this output to be used in STEM_Analysis.R, it MUST be moved to the "Code" folder.
write.csv(degrees0209, file = "0209degrees.csv")